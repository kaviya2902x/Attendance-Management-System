package com.attendance.service;

import com.attendance.entity.LeaveApplication;
import com.attendance.entity.User;
import com.attendance.repository.LeaveRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@Transactional
public class LeaveService {

    private final LeaveRepository leaveRepository;
    private final UserService userService;
    private final NotificationService notificationService;

    public LeaveService(LeaveRepository leaveRepository,
                        UserService userService,
                        NotificationService notificationService) {
        this.leaveRepository = leaveRepository;
        this.userService = userService;
        this.notificationService = notificationService;
    }

    public LeaveApplication applyLeave(Long userId, LeaveApplication leaveApplication) {
        User user = userService.getUserById(userId);

        // Calculate total days
        long days = ChronoUnit.DAYS.between(leaveApplication.getStartDate(),
                leaveApplication.getEndDate()) + 1;
        leaveApplication.setTotalDays((int) days);

        // Check for overlapping leaves
        List<LeaveApplication> overlappingLeaves = leaveRepository.findOverlappingLeaves(
                userId, leaveApplication.getStartDate(), leaveApplication.getEndDate());

        if (!overlappingLeaves.isEmpty()) {
            throw new RuntimeException("Leave application overlaps with existing leave");
        }

        // Check leave balance (assuming 30 days per year)
        int approvedLeavesThisYear = leaveRepository
                .getTotalApprovedLeaveDays(userId, LocalDate.now().getYear());

        if (approvedLeavesThisYear + leaveApplication.getTotalDays() > 30) {
            throw new RuntimeException("Insufficient leave balance");
        }

        leaveApplication.setUser(user);
        leaveApplication.setStatus("PENDING");
        leaveApplication.setAppliedDate(LocalDate.now());

        LeaveApplication saved = leaveRepository.save(leaveApplication);

        // Notify reporting manager
        if (user.getReportingManager() != null) {
            notificationService.createLeaveNotification(user, saved);
        }

        return saved;
    }

    public LeaveApplication approveLeave(Long leaveId, String approvedBy) {
        LeaveApplication leave = getLeaveById(leaveId);

        leave.setStatus("APPROVED");
        leave.setApprovedBy(approvedBy);
        leave.setApprovalDate(LocalDate.now());

        // Update corresponding attendance records
        updateAttendanceForLeave(leave);

        // Notify employee
        notificationService.createLeaveApprovalNotification(leave);

        return leaveRepository.save(leave);
    }

    public LeaveApplication rejectLeave(Long leaveId, String rejectedBy, String reason) {
        LeaveApplication leave = getLeaveById(leaveId);

        leave.setStatus("REJECTED");
        leave.setApprovedBy(rejectedBy);
        leave.setApprovalDate(LocalDate.now());
        leave.setRejectionReason(reason);

        // Notify employee
        notificationService.createLeaveRejectionNotification(leave);

        return leaveRepository.save(leave);
    }

    public LeaveApplication getLeaveById(Long id) {
        return leaveRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Leave not found with id: " + id));
    }

    public List<LeaveApplication> getUserLeaves(Long userId) {
        return leaveRepository.findByUserId(userId);
    }

    public List<LeaveApplication> getPendingLeaves() {
        return leaveRepository.findByStatus("PENDING");
    }

    public List<LeaveApplication> getPendingLeavesByManager(String managerEmail) {
        return leaveRepository.findPendingByManager(managerEmail);
    }

    public void cancelLeave(Long leaveId) {
        LeaveApplication leave = getLeaveById(leaveId);

        if (!"PENDING".equals(leave.getStatus())) {
            throw new RuntimeException("Only pending leaves can be cancelled");
        }

        leave.setStatus("CANCELLED");
        leaveRepository.save(leave);
    }

    private void updateAttendanceForLeave(LeaveApplication leave) {
        // This method would update attendance records for the leave period
        // Implementation depends on how you want to handle leave in attendance records
    }
}