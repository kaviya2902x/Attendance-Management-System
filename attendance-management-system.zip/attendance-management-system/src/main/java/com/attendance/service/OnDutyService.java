package com.attendance.service;

import com.attendance.entity.OnDutyApplication;
import com.attendance.entity.User;
import com.attendance.repository.OnDutyRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
@Transactional
public class OnDutyService {

    private final OnDutyRepository onDutyRepository;
    private final UserService userService;

    public OnDutyService(OnDutyRepository onDutyRepository, UserService userService) {
        this.onDutyRepository = onDutyRepository;
        this.userService = userService;
    }

    public OnDutyApplication applyOnDuty(Long userId, OnDutyApplication application) {
        User user = userService.getUserById(userId);

        // Check for overlapping on-duty applications
        List<OnDutyApplication> overlapping = onDutyRepository
                .findByUserIdAndStatusAndDateRange(
                        userId,
                        "APPROVED",
                        application.getStartDate(),
                        application.getEndDate()
                );

        if (!overlapping.isEmpty()) {
            throw new RuntimeException("On-duty application overlaps with existing approved on-duty");
        }

        // Calculate total days
        long days = ChronoUnit.DAYS.between(application.getStartDate(),
                application.getEndDate()) + 1;
        application.setTotalDays((int) days);

        application.setUser(user);
        application.setStatus("PENDING");
        application.setAppliedDate(LocalDate.now());

        return onDutyRepository.save(application);
    }

    public OnDutyApplication approveOnDuty(Long applicationId, String approvedBy) {
        OnDutyApplication application = getOnDutyById(applicationId);

        application.setStatus("APPROVED");
        application.setApprovedBy(approvedBy);
        application.setApprovalDate(LocalDate.now());

        return onDutyRepository.save(application);
    }

    public OnDutyApplication rejectOnDuty(Long applicationId, String rejectedBy, String reason) {
        OnDutyApplication application = getOnDutyById(applicationId);

        application.setStatus("REJECTED");
        application.setApprovedBy(rejectedBy);
        application.setApprovalDate(LocalDate.now());
        application.setRejectionReason(reason);

        return onDutyRepository.save(application);
    }

    public OnDutyApplication getOnDutyById(Long id) {
        return onDutyRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("On-duty application not found with id: " + id));
    }

    public List<OnDutyApplication> getUserOnDutyApplications(Long userId) {
        return onDutyRepository.findByUserId(userId);
    }

    public List<OnDutyApplication> getPendingApplications() {
        return onDutyRepository.findByStatus("PENDING");
    }
}