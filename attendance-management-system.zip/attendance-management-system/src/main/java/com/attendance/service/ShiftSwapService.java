package com.attendance.service;

import com.attendance.entity.ShiftSwapRequest;
import com.attendance.entity.User;
import com.attendance.repository.ShiftSwapRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ShiftSwapService {

    private final ShiftSwapRepository shiftSwapRepository;
    private final UserService userService;

    public ShiftSwapService(ShiftSwapRepository shiftSwapRepository,
                            UserService userService) {
        this.shiftSwapRepository = shiftSwapRepository;
        this.userService = userService;
    }

    public ShiftSwapRequest createSwapRequest(Long requestorId, Long requestedToId,
                                              ShiftSwapRequest request) {
        User requestor = userService.getUserById(requestorId);
        User requestedTo = userService.getUserById(requestedToId);

        // Check if swap already exists for this date
        Optional<ShiftSwapRequest> existingSwap = shiftSwapRepository
                .findByRequestorIdAndRequestedToIdAndSwapDateAndStatus(
                        requestorId, requestedToId, request.getSwapDate(), "PENDING"
                );

        if (existingSwap.isPresent()) {
            throw new RuntimeException("A swap request already exists for this date");
        }

        // Cannot swap with yourself
        if (requestorId.equals(requestedToId)) {
            throw new RuntimeException("Cannot swap shift with yourself");
        }

        // Check if swap date is in the past
        if (request.getSwapDate().isBefore(java.time.LocalDate.now())) {
            throw new RuntimeException("Cannot swap shifts for past dates");
        }

        // Set request details
        request.setRequestor(requestor);
        request.setRequestedTo(requestedTo);
        request.setRequestorShift(requestor.getShift());
        request.setRequestedShift(requestedTo.getShift());
        request.setStatus("PENDING");
        request.setRequestedDate(java.time.LocalDate.now());

        return shiftSwapRepository.save(request);
    }

    public ShiftSwapRequest approveSwapRequest(Long requestId) {
        ShiftSwapRequest request = getSwapRequestById(requestId);

        // Check if already approved or rejected
        if (!"PENDING".equals(request.getStatus())) {
            throw new RuntimeException("Request is already " + request.getStatus());
        }

        // Update status
        request.setStatus("APPROVED");
        request.setApprovedDate(java.time.LocalDate.now());

        // Swap the shifts temporarily
        swapShifts(request);

        return shiftSwapRepository.save(request);
    }

    public ShiftSwapRequest rejectSwapRequest(Long requestId, String reason) {
        ShiftSwapRequest request = getSwapRequestById(requestId);

        if (!"PENDING".equals(request.getStatus())) {
            throw new RuntimeException("Request is already " + request.getStatus());
        }

        request.setStatus("REJECTED");
        request.setRejectionReason(reason);

        return shiftSwapRepository.save(request);
    }

    public ShiftSwapRequest getSwapRequestById(Long id) {
        return shiftSwapRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Shift swap request not found with id: " + id));
    }

    public List<ShiftSwapRequest> getSwapRequestsByRequestorId(Long requestorId) {
        return shiftSwapRepository.findByRequestorId(requestorId);
    }

    public List<ShiftSwapRequest> getPendingRequestsForUser(Long userId) {
        return shiftSwapRepository.findByRequestedToIdAndStatus(userId, "PENDING");
    }

    public List<ShiftSwapRequest> getPendingSwapRequests() {
        return shiftSwapRepository.findByStatus("PENDING");
    }

    public ShiftSwapRequest updateSwapRequest(ShiftSwapRequest request) {
        return shiftSwapRepository.save(request);
    }

    public void deleteSwapRequest(Long id) {
        shiftSwapRepository.deleteById(id);
    }

    public List<ShiftSwapRequest> getSwapHistory(Long userId) {
        return shiftSwapRepository.findByRequestorIdOrRequestedToId(userId, userId);
    }

    private void swapShifts(ShiftSwapRequest request) {
        // Implementation to temporarily swap shifts
        // This would typically update attendance records or create temporary shift assignments
        // For now, we'll just update the users' shifts for the specific date

        // Note: In a real application, you might want to:
        // 1. Create temporary shift assignments
        // 2. Update attendance records for the swap date
        // 3. Send notifications to both users

        User requestor = request.getRequestor();
        User requestedTo = request.getRequestedTo();

        // Store original shifts
        var requestorOriginalShift = requestor.getShift();
        var requestedToOriginalShift = requestedTo.getShift();

        // Swap shifts temporarily (you might want to store this in a separate table)
        // For this example, we're just updating the shift references
        // In reality, you'd want to maintain original shifts and track the swap

        System.out.println("Shift swap approved: " +
                requestor.getFirstName() + " ↔ " +
                requestedTo.getFirstName() +
                " on " + request.getSwapDate());

        // Here you would implement the actual shift swapping logic
        // For example, create temporary shift assignments in a separate table
    }
}