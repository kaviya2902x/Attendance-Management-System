package com.attendance.service;

import com.attendance.entity.*;
import com.attendance.repository.NotificationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    public Notification createNotification(User user, String title, String message, String type) {
        Notification notification = new Notification();
        notification.setUser(user);
        notification.setTitle(title);
        notification.setMessage(message);
        notification.setType(type);
        notification.setIsRead(false);
        notification.setCreatedAt(LocalDateTime.now());

        return notificationRepository.save(notification);
    }

    public void createLeaveNotification(User user, LeaveApplication leave) {
        String title = "New Leave Application";
        String message = String.format("%s %s has applied for %s leave from %s to %s",
                user.getFirstName(), user.getLastName(),
                leave.getLeaveType(), leave.getStartDate(), leave.getEndDate());

        createNotification(user, title, message, "INFO");
    }

    public void createLeaveApprovalNotification(LeaveApplication leave) {
        String title = "Leave Application Approved";
        String message = String.format("Your %s leave from %s to %s has been approved",
                leave.getLeaveType(), leave.getStartDate(), leave.getEndDate());

        createNotification(leave.getUser(), title, message, "SUCCESS");
    }

    public void createLeaveRejectionNotification(LeaveApplication leave) {
        String title = "Leave Application Rejected";
        String message = String.format("Your %s leave from %s to %s has been rejected. Reason: %s",
                leave.getLeaveType(), leave.getStartDate(), leave.getEndDate(),
                leave.getRejectionReason());

        createNotification(leave.getUser(), title, message, "ERROR");
    }

    public void markAsRead(Long notificationId) {
        Notification notification = getNotificationById(notificationId);
        notification.setIsRead(true);
        notificationRepository.save(notification);
    }

    public void markAllAsRead(Long userId) {
        List<Notification> unreadNotifications = notificationRepository
                .findByUserIdAndIsRead(userId, false);

        unreadNotifications.forEach(notification -> {
            notification.setIsRead(true);
            notificationRepository.save(notification);
        });
    }

    public Notification getNotificationById(Long id) {
        return notificationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Notification not found with id: " + id));
    }

    public List<Notification> getUserNotifications(Long userId) {
        return notificationRepository.findByUserId(userId);
    }

    public List<Notification> getUnreadNotifications(Long userId) {
        return notificationRepository.findByUserIdAndIsRead(userId, false);
    }

    public Long getUnreadNotificationCount(Long userId) {
        return notificationRepository.countByUserIdAndIsRead(userId, false);
    }

    public void deleteNotification(Long id) {
        notificationRepository.deleteById(id);
    }
}