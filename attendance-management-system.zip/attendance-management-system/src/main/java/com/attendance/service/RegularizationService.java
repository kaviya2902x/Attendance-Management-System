package com.attendance.service;

import com.attendance.entity.RegularizationRequest;
import com.attendance.entity.User;
import com.attendance.repository.RegularizationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class RegularizationService {

    private final RegularizationRepository regularizationRepository;
    private final UserService userService;
    private final AttendanceService attendanceService;

    public RegularizationService(RegularizationRepository regularizationRepository,
                                 UserService userService,
                                 AttendanceService attendanceService) {
        this.regularizationRepository = regularizationRepository;
        this.userService = userService;
        this.attendanceService = attendanceService;
    }

    public RegularizationRequest createRequest(Long userId, RegularizationRequest request) {
        User user = userService.getUserById(userId);

        // Check if request already exists for this date
        List<RegularizationRequest> existingRequests = regularizationRepository
                .findByUserIdAndStatus(userId, "PENDING");

        boolean alreadyExists = existingRequests.stream()
                .anyMatch(r -> r.getAttendanceDate().equals(request.getAttendanceDate()));

        if (alreadyExists) {
            throw new RuntimeException("Regularization request already exists for this date");
        }

        request.setUser(user);
        request.setStatus("PENDING");
        request.setRequestedDate(java.time.LocalDate.now());

        return regularizationRepository.save(request);
    }

    public RegularizationRequest approveRequest(Long requestId, String approvedBy) {
        RegularizationRequest request = getRequestById(requestId);

        request.setStatus("APPROVED");
        request.setApprovedBy(approvedBy);
        request.setApprovalDate(java.time.LocalDate.now());

        // Update attendance record
        updateAttendanceFromRegularization(request);

        return regularizationRepository.save(request);
    }

    public RegularizationRequest rejectRequest(Long requestId, String rejectedBy, String reason) {
        RegularizationRequest request = getRequestById(requestId);

        request.setStatus("REJECTED");
        request.setApprovedBy(rejectedBy);
        request.setApprovalDate(java.time.LocalDate.now());
        request.setRejectionReason(reason);

        return regularizationRepository.save(request);
    }

    public RegularizationRequest getRequestById(Long id) {
        return regularizationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Request not found with id: " + id));
    }

    public List<RegularizationRequest> getUserRequests(Long userId) {
        return regularizationRepository.findByUserId(userId);
    }

    public List<RegularizationRequest> getPendingRequests() {
        return regularizationRepository.findByStatus("PENDING");
    }

    private void updateAttendanceFromRegularization(RegularizationRequest request) {
        // This method would update the attendance record based on the regularization
        // Implementation would depend on your attendance structure
    }
}