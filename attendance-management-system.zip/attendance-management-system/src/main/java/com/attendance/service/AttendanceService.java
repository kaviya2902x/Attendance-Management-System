package com.attendance.service;

import com.attendance.dto.AttendanceDTO;
import com.attendance.entity.Attendance;
import com.attendance.entity.Holiday;
import com.attendance.entity.User;
import com.attendance.repository.AttendanceRepository;
import com.attendance.repository.HolidayRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final HolidayRepository holidayRepository;
    private final UserService userService;

    public AttendanceService(AttendanceRepository attendanceRepository,
                             HolidayRepository holidayRepository,
                             UserService userService) {
        this.attendanceRepository = attendanceRepository;
        this.holidayRepository = holidayRepository;
        this.userService = userService;
    }

    public Attendance clockIn(Long userId, String location) {
        User user = userService.getUserById(userId);
        LocalDate today = LocalDate.now();

        // Check if already clocked in today
        Optional<Attendance> existing = attendanceRepository
                .findByUserIdAndAttendanceDate(userId, today);

        if (existing.isPresent()) {
            Attendance attendance = existing.get();
            if (attendance.getClockInTime() != null) {
                throw new RuntimeException("Already clocked in today");
            }
            attendance.setClockInTime(LocalTime.now());
            attendance.setClockInLocation(location);
            attendance.setStatus(calculateStatus(attendance));
            return attendanceRepository.save(attendance);
        }

        // Create new attendance record
        Attendance attendance = new Attendance();
        attendance.setUser(user);
        attendance.setAttendanceDate(today);
        attendance.setClockInTime(LocalTime.now());
        attendance.setClockInLocation(location);
        attendance.setStatus(calculateStatus(attendance));

        return attendanceRepository.save(attendance);
    }

    public Attendance clockOut(Long userId, String location) {
        LocalDate today = LocalDate.now();
        Attendance attendance = attendanceRepository
                .findByUserIdAndAttendanceDate(userId, today)
                .orElseThrow(() -> new RuntimeException("No clock-in record found for today"));

        if (attendance.getClockOutTime() != null) {
            throw new RuntimeException("Already clocked out today");
        }

        attendance.setClockOutTime(LocalTime.now());
        attendance.setClockOutLocation(location);
        attendance.setTotalHours(attendance.calculateTotalHours());
        attendance.setStatus(calculateStatus(attendance));

        // Calculate overtime
        calculateOvertime(attendance);

        return attendanceRepository.save(attendance);
    }

    public Attendance markAttendance(Long userId, LocalDate date,
                                     LocalTime clockIn, LocalTime clockOut) {
        User user = userService.getUserById(userId);

        Optional<Attendance> existing = attendanceRepository
                .findByUserIdAndAttendanceDate(userId, date);

        Attendance attendance;
        if (existing.isPresent()) {
            attendance = existing.get();
        } else {
            attendance = new Attendance();
            attendance.setUser(user);
            attendance.setAttendanceDate(date);
        }

        attendance.setClockInTime(clockIn);
        attendance.setClockOutTime(clockOut);
        attendance.setTotalHours(attendance.calculateTotalHours());
        attendance.setStatus(calculateStatus(attendance));

        calculateLateAndEarlyDeparture(attendance);
        calculateOvertime(attendance);

        return attendanceRepository.save(attendance);
    }

    public List<Attendance> getUserAttendance(Long userId) {
        return attendanceRepository.findByUserId(userId);
    }

    public List<Attendance> getUserAttendanceByMonth(Long userId, int year, int month) {
        return attendanceRepository.findByUserIdAndMonth(userId, year, month);
    }

    public List<Attendance> getAttendanceByDate(LocalDate date) {
        return attendanceRepository.findByAttendanceDate(date);
    }

    public List<Attendance> getAttendanceByDateRange(LocalDate startDate, LocalDate endDate) {
        return attendanceRepository.findByAttendanceDateBetween(startDate, endDate);
    }

    public Attendance getTodayAttendance(Long userId) {
        LocalDate today = LocalDate.now();
        return attendanceRepository.findByUserIdAndAttendanceDate(userId, today)
                .orElse(null);
    }

    public AttendanceDTO convertToDTO(Attendance attendance) {
        User user = attendance.getUser();
        return new AttendanceDTO(
                attendance.getId(),
                user.getId(),
                user.getFirstName() + " " + user.getLastName(),
                user.getEmployeeId(),
                attendance.getAttendanceDate(),
                attendance.getClockInTime(),
                attendance.getClockOutTime(),
                attendance.getTotalHours(),
                attendance.getStatus(),
                attendance.getLateMinutes(),
                attendance.getEarlyDepartureMinutes(),
                attendance.getOvertimeHours(),
                attendance.getNotes(),
                attendance.getClockInLocation(),
                attendance.getClockOutLocation()
        );
    }

    public List<AttendanceDTO> convertToDTOList(List<Attendance> attendances) {
        return attendances.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    private String calculateStatus(Attendance attendance) {
        LocalDate date = attendance.getAttendanceDate();

        // Check if holiday
        List<Holiday> holidays = holidayRepository.findByDate(date);
        if (!holidays.isEmpty()) {
            return "HOLIDAY";
        }

        // Check if weekend (Saturday or Sunday)
        DayOfWeek dayOfWeek = date.getDayOfWeek();
        if (dayOfWeek == DayOfWeek.SATURDAY || dayOfWeek == DayOfWeek.SUNDAY) {
            return "WEEKEND";
        }

        // Check if present (both clock-in and clock-out recorded)
        if (attendance.getClockInTime() != null && attendance.getClockOutTime() != null) {
            return "PRESENT";
        }

        // Check if half day (only clock-in or only clock-out)
        if (attendance.getClockInTime() != null || attendance.getClockOutTime() != null) {
            return "HALF_DAY";
        }

        // Default to absent
        return "ABSENT";
    }

    private void calculateLateAndEarlyDeparture(Attendance attendance) {
        // Assuming standard shift 9:00 AM to 6:00 PM with 1 hour break
        LocalTime standardStart = LocalTime.of(9, 0);
        LocalTime standardEnd = LocalTime.of(18, 0);

        if (attendance.getClockInTime() != null && attendance.getClockInTime().isAfter(standardStart)) {
            long lateMinutes = java.time.Duration.between(standardStart, attendance.getClockInTime()).toMinutes();
            attendance.setLateMinutes((int) lateMinutes);
        }

        if (attendance.getClockOutTime() != null && attendance.getClockOutTime().isBefore(standardEnd)) {
            long earlyMinutes = java.time.Duration.between(attendance.getClockOutTime(), standardEnd).toMinutes();
            attendance.setEarlyDepartureMinutes((int) earlyMinutes);
        }
    }

    private void calculateOvertime(Attendance attendance) {
        if (attendance.getClockInTime() != null && attendance.getClockOutTime() != null) {
            double totalHours = attendance.calculateTotalHours();
            double standardHours = 8.0; // 8 working hours per day

            if (totalHours > standardHours) {
                attendance.setOvertimeHours(totalHours - standardHours);
            }
        }
    }

    public AttendanceSummary getAttendanceSummary(Long userId, int year, int month) {
        List<Attendance> monthlyAttendance = getUserAttendanceByMonth(userId, year, month);
        YearMonth yearMonth = YearMonth.of(year, month);
        int totalDays = yearMonth.lengthOfMonth();

        long presentDays = monthlyAttendance.stream()
                .filter(a -> "PRESENT".equals(a.getStatus()))
                .count();

        long absentDays = monthlyAttendance.stream()
                .filter(a -> "ABSENT".equals(a.getStatus()))
                .count();

        long leaveDays = monthlyAttendance.stream()
                .filter(a -> "LEAVE".equals(a.getStatus()))
                .count();

        long holidayDays = monthlyAttendance.stream()
                .filter(a -> "HOLIDAY".equals(a.getStatus()))
                .count();

        double totalHours = monthlyAttendance.stream()
                .mapToDouble(a -> a.getTotalHours() != null ? a.getTotalHours() : 0.0)
                .sum();

        double overtimeHours = monthlyAttendance.stream()
                .mapToDouble(a -> a.getOvertimeHours() != null ? a.getOvertimeHours() : 0.0)
                .sum();

        return new AttendanceSummary(presentDays, absentDays, leaveDays, holidayDays,
                totalDays, totalHours, overtimeHours);
    }

    public static class AttendanceSummary {
        private final long presentDays;
        private final long absentDays;
        private final long leaveDays;
        private final long holidayDays;
        private final int totalDays;
        private final double totalHours;
        private final double overtimeHours;

        public AttendanceSummary(long presentDays, long absentDays, long leaveDays,
                                 long holidayDays, int totalDays, double totalHours,
                                 double overtimeHours) {
            this.presentDays = presentDays;
            this.absentDays = absentDays;
            this.leaveDays = leaveDays;
            this.holidayDays = holidayDays;
            this.totalDays = totalDays;
            this.totalHours = totalHours;
            this.overtimeHours = overtimeHours;
        }

        // Getters
        public long getPresentDays() { return presentDays; }
        public long getAbsentDays() { return absentDays; }
        public long getLeaveDays() { return leaveDays; }
        public long getHolidayDays() { return holidayDays; }
        public int getTotalDays() { return totalDays; }
        public double getTotalHours() { return totalHours; }
        public double getOvertimeHours() { return overtimeHours; }
    }
}