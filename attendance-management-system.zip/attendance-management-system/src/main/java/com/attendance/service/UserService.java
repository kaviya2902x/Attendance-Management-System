package com.attendance.service;

import com.attendance.dto.UserDTO;
import com.attendance.entity.User;
import com.attendance.repository.UserRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class UserService implements UserDetailsService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Optional<User> userOptional = userRepository.findByEmail(email);

        if (userOptional.isEmpty()) {
            throw new UsernameNotFoundException("User not found with email: " + email);
        }

        User user = userOptional.get();

        // Check if user is active
        if (!"ACTIVE".equals(user.getStatus())) {
            throw new UsernameNotFoundException("User account is inactive");
        }

        List<SimpleGrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority(user.getRole()));

        return new org.springframework.security.core.userdetails.User(
                user.getEmail(),
                user.getPassword(), // Plain text from database
                true,               // enabled
                true,               // account non-expired
                true,               // credentials non-expired
                true,               // account non-locked
                authorities
        );
    }

    public User createUser(User user) {
        // Check if email already exists
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new RuntimeException("Email already exists: " + user.getEmail());
        }

        // Generate employee ID if not provided
        if (user.getEmployeeId() == null || user.getEmployeeId().isEmpty()) {
            String timestamp = String.valueOf(System.currentTimeMillis());
            user.setEmployeeId("EMP" + timestamp.substring(timestamp.length() - 6));
        } else {
            // Check if employee ID already exists
            if (userRepository.findByEmployeeId(user.getEmployeeId()).isPresent()) {
                throw new RuntimeException("Employee ID already exists: " + user.getEmployeeId());
            }
        }

        // Set joining date if not provided
        if (user.getJoiningDate() == null) {
            user.setJoiningDate(LocalDate.now());
        }

        // Set default values if not provided
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("ROLE_EMPLOYEE");
        }

        if (user.getStatus() == null || user.getStatus().isEmpty()) {
            user.setStatus("ACTIVE");
        }

        // Set timestamps
        user.setCreatedAt(LocalDate.now());
        user.setUpdatedAt(LocalDate.now());

        return userRepository.save(user);
    }

    public User updateUser(Long id, User userDetails) {
        User user = getUserById(id);

        // Check if email is being changed and if new email already exists
        if (!user.getEmail().equals(userDetails.getEmail())) {
            if (userRepository.findByEmail(userDetails.getEmail()).isPresent()) {
                throw new RuntimeException("Email already exists: " + userDetails.getEmail());
            }
        }

        // Update fields
        user.setFirstName(userDetails.getFirstName());
        user.setLastName(userDetails.getLastName());
        user.setEmail(userDetails.getEmail());
        user.setPhoneNumber(userDetails.getPhoneNumber());
        user.setDateOfBirth(userDetails.getDateOfBirth());
        user.setDepartment(userDetails.getDepartment());
        user.setPosition(userDetails.getPosition());
        user.setReportingManager(userDetails.getReportingManager());
        user.setEmergencyContact(userDetails.getEmergencyContact());
        user.setEmergencyPhone(userDetails.getEmergencyPhone());
        user.setCurrentAddress(userDetails.getCurrentAddress());
        user.setPermanentAddress(userDetails.getPermanentAddress());
        user.setProfileImage(userDetails.getProfileImage());
        user.setStatus(userDetails.getStatus());
        user.setRole(userDetails.getRole());
        user.setUpdatedAt(LocalDate.now());

        // Only update password if provided and not empty
        if (userDetails.getPassword() != null && !userDetails.getPassword().isEmpty()) {
            // Store plain text - no encoding
            user.setPassword(userDetails.getPassword());
        }

        return userRepository.save(user);
    }

    public void deleteUser(Long id) {
        User user = getUserById(id);
        user.setStatus("INACTIVE");
        user.setUpdatedAt(LocalDate.now());
        userRepository.save(user);
    }

    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
    }

    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public List<User> getUsersByDepartment(String department) {
        return userRepository.findByDepartment(department);
    }

    public List<User> getActiveUsers() {
        return userRepository.findByStatus("ACTIVE");
    }

    public Long getActiveUsersCount() {
        return userRepository.countByStatus("ACTIVE");
    }

    public List<User> searchUsers(String keyword) {
        return userRepository.findByNameContaining(keyword);
    }

    public List<User> getUsersByRole(String role) {
        return userRepository.findByRole(role);
    }

    public List<User> getUsersByReportingManager(String managerEmail) {
        return userRepository.findByReportingManager(managerEmail);
    }

    public UserDTO convertToDTO(User user) {
        return new UserDTO(
                user.getId(),
                user.getEmployeeId(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                user.getPhoneNumber(),
                user.getDateOfBirth(),
                user.getRole(),
                user.getDepartment(),
                user.getPosition(),
                user.getJoiningDate(),
                user.getReportingManager(),
                user.getEmergencyContact(),
                user.getEmergencyPhone(),
                user.getCurrentAddress(),
                user.getPermanentAddress(),
                user.getProfileImage(),
                user.getStatus(),
                user.getCreatedAt(),
                user.getUpdatedAt()
        );
    }

    public List<UserDTO> convertToDTOList(List<User> users) {
        return users.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // Additional utility methods
    public boolean emailExists(String email) {
        return userRepository.findByEmail(email).isPresent();
    }

    public boolean employeeIdExists(String employeeId) {
        return userRepository.findByEmployeeId(employeeId).isPresent();
    }

    public List<User> getActiveUsersByDepartment(String department) {
        return userRepository.findByDepartmentAndStatus(department, "ACTIVE");
    }
}