package com.attendance.controller;

import com.attendance.dto.ApiResponse;
import com.attendance.entity.*;
import com.attendance.service.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final UserService userService;
    private final AttendanceService attendanceService;
    private final LeaveService leaveService;
    private final HolidayService holidayService;
    private final ShiftService shiftService;

    public AdminController(UserService userService,
                           AttendanceService attendanceService,
                           LeaveService leaveService,
                           HolidayService holidayService,
                           ShiftService shiftService) {
        this.userService = userService;
        this.attendanceService = attendanceService;
        this.leaveService = leaveService;
        this.holidayService = holidayService;
        this.shiftService = shiftService;
    }

    @GetMapping("/dashboard")
    public String adminDashboard(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());

            // Check if user has admin role
            if (user.getRole() == null || !user.getRole().equals("ROLE_ADMIN")) {
                return "redirect:/error/403";
            }

            Long totalUsers = userService.getActiveUsersCount();
            List<Attendance> todayAttendance = attendanceService.getAttendanceByDate(LocalDate.now());
            List<LeaveApplication> pendingLeaves = leaveService.getPendingLeaves();

            model.addAttribute("totalUsers", totalUsers);
            model.addAttribute("todayAttendance", todayAttendance.size());
            model.addAttribute("pendingLeaves", pendingLeaves.size());
            model.addAttribute("user", user);

            return "admin/dashboard";

        } catch (Exception e) {
            model.addAttribute("error", "Error loading dashboard: " + e.getMessage());
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/users")
    public String manageUsers(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            if (!user.getRole().equals("ROLE_ADMIN")) {
                return "redirect:/error/403";
            }

            List<User> users = userService.getAllUsers();
            model.addAttribute("users", users);
            model.addAttribute("user", user);
            return "admin/users";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/users/{id}")
    public String viewUser(@PathVariable Long id, @AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            if (!user.getRole().equals("ROLE_ADMIN")) {
                return "redirect:/error/403";
            }

            User targetUser = userService.getUserById(id);
            List<Attendance> recentAttendance = attendanceService.getUserAttendance(id);
            List<LeaveApplication> userLeaves = leaveService.getUserLeaves(id);

            model.addAttribute("targetUser", targetUser);
            model.addAttribute("recentAttendance", recentAttendance);
            model.addAttribute("userLeaves", userLeaves);
            model.addAttribute("user", user);

            return "admin/user-details";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @PostMapping("/users")
    @ResponseBody
    public ApiResponse createUser(@RequestBody User newUser) {
        try {
            User user = userService.createUser(newUser);
            return ApiResponse.success("User created successfully", user);
        } catch (Exception e) {
            return ApiResponse.error("Error creating user: " + e.getMessage());
        }
    }

    @PutMapping("/users/{id}")
    @ResponseBody
    public ApiResponse updateUser(@PathVariable Long id, @RequestBody User userDetails) {
        try {
            User user = userService.updateUser(id, userDetails);
            return ApiResponse.success("User updated successfully", user);
        } catch (Exception e) {
            return ApiResponse.error("Error updating user: " + e.getMessage());
        }
    }

    @DeleteMapping("/users/{id}")
    @ResponseBody
    public ApiResponse deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUser(id);
            return ApiResponse.success("User deleted successfully");
        } catch (Exception e) {
            return ApiResponse.error("Error deleting user: " + e.getMessage());
        }
    }

    @GetMapping("/attendance")
    public String viewAllAttendance(@AuthenticationPrincipal UserDetails securityUser,
                                    @RequestParam(required = false) LocalDate date,
                                    Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            if (!user.getRole().equals("ROLE_ADMIN")) {
                return "redirect:/error/403";
            }

            if (date == null) {
                date = LocalDate.now();
            }

            List<Attendance> attendanceList = attendanceService.getAttendanceByDate(date);

            model.addAttribute("attendanceList", attendanceService.convertToDTOList(attendanceList));
            model.addAttribute("date", date);
            model.addAttribute("user", user);

            return "admin/attendance-view";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/leaves")
    public String viewAllLeaves(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            if (!user.getRole().equals("ROLE_ADMIN")) {
                return "redirect:/error/403";
            }

            List<LeaveApplication> leaves = leaveService.getPendingLeaves();
            model.addAttribute("leaves", leaves);
            model.addAttribute("user", user);
            return "admin/leave-approvals";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/holidays")
    public String manageHolidays(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            if (!user.getRole().equals("ROLE_ADMIN")) {
                return "redirect:/error/403";
            }

            List<Holiday> holidays = holidayService.getAllHolidays();
            model.addAttribute("holidays", holidays);
            model.addAttribute("user", user);
            return "admin/holidays";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @PostMapping("/holidays")
    @ResponseBody
    public ApiResponse createHoliday(@RequestBody Holiday holiday) {
        try {
            Holiday created = holidayService.createHoliday(holiday);
            return ApiResponse.success("Holiday created successfully", created);
        } catch (Exception e) {
            return ApiResponse.error("Error creating holiday: " + e.getMessage());
        }
    }

    @GetMapping("/shifts")
    public String manageShifts(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            if (!user.getRole().equals("ROLE_ADMIN")) {
                return "redirect:/error/403";
            }

            List<Shift> shifts = shiftService.getAllShifts();
            model.addAttribute("shifts", shifts);
            model.addAttribute("user", user);
            return "admin/shifts";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/reports")
    public String viewReports(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            if (!user.getRole().equals("ROLE_ADMIN")) {
                return "redirect:/error/403";
            }

            model.addAttribute("user", user);
            return "admin/reports";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/reports/attendance")
    @ResponseBody
    public ApiResponse generateAttendanceReport(@RequestParam LocalDate startDate,
                                                @RequestParam LocalDate endDate) {
        try {
            List<Attendance> attendance = attendanceService
                    .getAttendanceByDateRange(startDate, endDate);
            return ApiResponse.success("Report generated", attendanceService.convertToDTOList(attendance));
        } catch (Exception e) {
            return ApiResponse.error("Error generating report: " + e.getMessage());
        }
    }
}