package com.attendance.controller;

import com.attendance.dto.ApiResponse;
import com.attendance.entity.Shift;
import com.attendance.service.ShiftService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shifts")
public class ShiftController {

    private final ShiftService shiftService;

    public ShiftController(ShiftService shiftService) {
        this.shiftService = shiftService;
    }

    @GetMapping("")
    public ApiResponse getAllShifts() {
        List<Shift> shifts = shiftService.getAllShifts();
        return ApiResponse.success("Shifts retrieved", shifts);
    }

    @GetMapping("/active")
    public ApiResponse getActiveShifts() {
        List<Shift> shifts = shiftService.getActiveShifts();
        return ApiResponse.success("Active shifts retrieved", shifts);
    }

    @PostMapping("")
    public ApiResponse createShift(@RequestBody Shift shift) {
        Shift created = shiftService.createShift(shift);
        return ApiResponse.success("Shift created", created);
    }

    @PutMapping("/{id}")
    public ApiResponse updateShift(@PathVariable Long id, @RequestBody Shift shift) {
        Shift updated = shiftService.updateShift(id, shift);
        return ApiResponse.success("Shift updated", updated);
    }

    @DeleteMapping("/{id}")
    public ApiResponse deleteShift(@PathVariable Long id) {
        shiftService.deleteShift(id);
        return ApiResponse.success("Shift deleted");
    }
}