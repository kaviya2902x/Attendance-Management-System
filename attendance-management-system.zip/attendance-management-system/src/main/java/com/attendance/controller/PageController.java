package com.attendance.controller;

import com.attendance.entity.User;
import com.attendance.service.UserService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {

    private final UserService userService;

    public PageController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails securityUser,
                            Model model) {

        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            // Get user details from database using email (username)
            User user = userService.getUserByEmail(securityUser.getUsername());
            model.addAttribute("user", user);

            // Redirect based on role
            if (user.getRole().equals("ROLE_ADMIN")) {
                return "redirect:/admin/dashboard";
            } else if (user.getRole().equals("ROLE_MANAGER")) {
                // If you have a manager dashboard, redirect there
                // For now, redirect to employee dashboard
                return "redirect:/employee/dashboard";
            } else {
                return "redirect:/employee/dashboard";
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/employee/dashboard")
    public String employeeDashboard(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            model.addAttribute("user", user);
            return "employee/dashboard";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/employee/profile")
    public String employeeProfile(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            model.addAttribute("user", user);
            return "employee/profile";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/employee/settings")
    public String employeeSettings(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            model.addAttribute("user", user);
            return "employee/settings";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/employee/reports")
    public String employeeReports(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            model.addAttribute("user", user);
            return "employee/reports";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/employee/onduty")
    public String employeeOnDuty(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            model.addAttribute("user", user);
            return "employee/on-duty";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/employee/shift-swap")
    public String employeeShiftSwap(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            model.addAttribute("user", user);
            return "employee/shift-swap";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/employee/regularization")
    public String employeeRegularization(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            model.addAttribute("user", user);
            return "employee/regularization";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    // ========== MISSING ENDPOINTS - ADD THESE ==========

    @GetMapping("/employee/attendance")
    public String employeeAttendance(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            model.addAttribute("user", user);
            return "employee/attendance";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/employee/leave")
    public String employeeLeave(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            model.addAttribute("user", user);
            return "employee/leave";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/employee/history")
    public String employeeHistory(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            model.addAttribute("user", user);
            return "employee/history";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/error/403")
    public String accessDenied() {
        return "error/403";
    }

    @GetMapping("/error/404")
    public String notFound() {
        return "error/404";
    }

    @GetMapping("/error/500")
    public String serverError() {
        return "error/500";
    }
}