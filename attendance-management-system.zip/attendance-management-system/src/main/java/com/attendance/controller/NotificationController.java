package com.attendance.controller;

import com.attendance.dto.ApiResponse;
import com.attendance.entity.Notification;
import com.attendance.entity.User;
import com.attendance.service.NotificationService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @GetMapping("")
    public ApiResponse getUserNotifications(@AuthenticationPrincipal User user) {
        List<Notification> notifications = notificationService.getUserNotifications(user.getId());
        return ApiResponse.success("Notifications retrieved", notifications);
    }

    @GetMapping("/unread")
    public ApiResponse getUnreadNotifications(@AuthenticationPrincipal User user) {
        List<Notification> notifications = notificationService.getUnreadNotifications(user.getId());
        return ApiResponse.success("Unread notifications retrieved", notifications);
    }

    @GetMapping("/count")
    public ApiResponse getUnreadCount(@AuthenticationPrincipal User user) {
        Long count = notificationService.getUnreadNotificationCount(user.getId());
        return ApiResponse.success("Unread count retrieved", count);
    }

    @PostMapping("/{id}/read")
    public ApiResponse markAsRead(@PathVariable Long id) {
        notificationService.markAsRead(id);
        return ApiResponse.success("Notification marked as read");
    }

    @PostMapping("/mark-all-read")
    public ApiResponse markAllAsRead(@AuthenticationPrincipal User user) {
        notificationService.markAllAsRead(user.getId());
        return ApiResponse.success("All notifications marked as read");
    }

    @DeleteMapping("/{id}")
    public ApiResponse deleteNotification(@PathVariable Long id) {
        notificationService.deleteNotification(id);
        return ApiResponse.success("Notification deleted");
    }
}