package com.attendance.controller;

import com.attendance.dto.ApiResponse;
import com.attendance.dto.RegularizationRequestDTO;
import com.attendance.entity.RegularizationRequest;
import com.attendance.entity.User;
import com.attendance.service.RegularizationService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/regularization")
public class RegularizationController {

    private final RegularizationService regularizationService;

    public RegularizationController(RegularizationService regularizationService) {
        this.regularizationService = regularizationService;
    }

    @GetMapping("")
    public String regularizationPage(@AuthenticationPrincipal User user, Model model) {
        List<RegularizationRequest> requests = regularizationService.getUserRequests(user.getId());
        model.addAttribute("requests", requests);
        model.addAttribute("user", user);
        return "employee/regularization";
    }

    @PostMapping("/apply")
    @ResponseBody
    public ApiResponse applyRegularization(@AuthenticationPrincipal User user,
                                           @RequestBody RegularizationRequestDTO requestDTO) {
        try {
            RegularizationRequest request = new RegularizationRequest();
            request.setAttendanceDate(requestDTO.getAttendanceDate());
            request.setRequestedClockIn(requestDTO.getRequestedClockIn());
            request.setRequestedClockOut(requestDTO.getRequestedClockOut());
            request.setReason(requestDTO.getReason());

            RegularizationRequest created = regularizationService.createRequest(user.getId(), request);
            return ApiResponse.success("Regularization request submitted", created);
        } catch (Exception e) {
            return ApiResponse.error("Error submitting request: " + e.getMessage());
        }
    }

    @GetMapping("/pending")
    public String pendingRequests(@AuthenticationPrincipal User user, Model model) {
        List<RegularizationRequest> pendingRequests = regularizationService.getPendingRequests();
        model.addAttribute("pendingRequests", pendingRequests);
        model.addAttribute("user", user);
        return "admin/regularization-approvals";
    }

    @PostMapping("/{id}/approve")
    @ResponseBody
    public ApiResponse approveRequest(@PathVariable Long id,
                                      @AuthenticationPrincipal User user) {
        try {
            RegularizationRequest request = regularizationService.approveRequest(id, user.getEmail());
            return ApiResponse.success("Request approved", request);
        } catch (Exception e) {
            return ApiResponse.error("Error approving request: " + e.getMessage());
        }
    }

    @PostMapping("/{id}/reject")
    @ResponseBody
    public ApiResponse rejectRequest(@PathVariable Long id,
                                     @RequestParam String reason,
                                     @AuthenticationPrincipal User user) {
        try {
            RegularizationRequest request = regularizationService.rejectRequest(id, user.getEmail(), reason);
            return ApiResponse.success("Request rejected", request);
        } catch (Exception e) {
            return ApiResponse.error("Error rejecting request: " + e.getMessage());
        }
    }
}