package com.attendance.controller;

import com.attendance.dto.ApiResponse;
import com.attendance.entity.OnDutyApplication;
import com.attendance.entity.User;
import com.attendance.service.OnDutyService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/onduty")
public class OnDutyController {

    private final OnDutyService onDutyService;

    public OnDutyController(OnDutyService onDutyService) {
        this.onDutyService = onDutyService;
    }

    @PostMapping("/apply")
    public ApiResponse applyOnDuty(@AuthenticationPrincipal User user,
                                   @RequestBody OnDutyApplication application) {
        try {
            OnDutyApplication created = onDutyService.applyOnDuty(user.getId(), application);
            return ApiResponse.success("On-duty application submitted", created);
        } catch (Exception e) {
            return ApiResponse.error("Error submitting application: " + e.getMessage());
        }
    }

    @GetMapping("")
    public ApiResponse getUserApplications(@AuthenticationPrincipal User user) {
        List<OnDutyApplication> applications = onDutyService.getUserOnDutyApplications(user.getId());
        return ApiResponse.success("On-duty applications retrieved", applications);
    }

    @GetMapping("/pending")
    public ApiResponse getPendingApplications() {
        List<OnDutyApplication> applications = onDutyService.getPendingApplications();
        return ApiResponse.success("Pending applications retrieved", applications);
    }

    @PostMapping("/{id}/approve")
    public ApiResponse approveApplication(@PathVariable Long id,
                                          @AuthenticationPrincipal User user) {
        try {
            OnDutyApplication application = onDutyService.approveOnDuty(id, user.getEmail());
            return ApiResponse.success("Application approved", application);
        } catch (Exception e) {
            return ApiResponse.error("Error approving application: " + e.getMessage());
        }
    }

    @PostMapping("/{id}/reject")
    public ApiResponse rejectApplication(@PathVariable Long id,
                                         @RequestParam String reason,
                                         @AuthenticationPrincipal User user) {
        try {
            OnDutyApplication application = onDutyService.rejectOnDuty(id, user.getEmail(), reason);
            return ApiResponse.success("Application rejected", application);
        } catch (Exception e) {
            return ApiResponse.error("Error rejecting application: " + e.getMessage());
        }
    }
}