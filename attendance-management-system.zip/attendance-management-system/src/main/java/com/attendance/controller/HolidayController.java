package com.attendance.controller;

import com.attendance.dto.ApiResponse;
import com.attendance.entity.Holiday;
import com.attendance.service.HolidayService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/holidays")
public class HolidayController {

    private final HolidayService holidayService;

    public HolidayController(HolidayService holidayService) {
        this.holidayService = holidayService;
    }

    @GetMapping("")
    public ApiResponse getAllHolidays() {
        List<Holiday> holidays = holidayService.getAllHolidays();
        return ApiResponse.success("Holidays retrieved", holidays);
    }

    @GetMapping("/upcoming")
    public ApiResponse getUpcomingHolidays() {
        List<Holiday> holidays = holidayService.getUpcomingHolidays();
        return ApiResponse.success("Upcoming holidays retrieved", holidays);
    }

    @GetMapping("/{year}")
    public ApiResponse getHolidaysByYear(@PathVariable int year) {
        List<Holiday> holidays = holidayService.getHolidaysByYear(year);
        return ApiResponse.success("Holidays for year retrieved", holidays);
    }

    @PostMapping("")
    public ApiResponse createHoliday(@RequestBody Holiday holiday) {
        Holiday created = holidayService.createHoliday(holiday);
        return ApiResponse.success("Holiday created", created);
    }

    @PutMapping("/{id}")
    public ApiResponse updateHoliday(@PathVariable Long id, @RequestBody Holiday holiday) {
        Holiday updated = holidayService.updateHoliday(id, holiday);
        return ApiResponse.success("Holiday updated", updated);
    }

    @DeleteMapping("/{id}")
    public ApiResponse deleteHoliday(@PathVariable Long id) {
        holidayService.deleteHoliday(id);
        return ApiResponse.success("Holiday deleted");
    }
}