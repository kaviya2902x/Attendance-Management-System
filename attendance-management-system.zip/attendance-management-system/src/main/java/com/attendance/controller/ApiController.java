package com.attendance.controller;

import com.attendance.dto.ApiResponse;
import com.attendance.entity.User;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ApiController {

    @GetMapping("/health")
    public ApiResponse healthCheck() {
        return ApiResponse.success("Application is running");
    }

    @GetMapping("/user/profile")
    public ApiResponse getUserProfile(@AuthenticationPrincipal User user) {
        return ApiResponse.success("User profile retrieved", user);
    }

    @GetMapping("/system/info")
    public ApiResponse getSystemInfo() {
        return ApiResponse.success("System information",
                new Object() {
                    public String appName = "Attendance Management System";
                    public String version = "1.0.0";
                    public String status = "Active";
                }
        );
    }
}