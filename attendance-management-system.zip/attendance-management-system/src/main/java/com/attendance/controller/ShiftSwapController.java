package com.attendance.controller;

import com.attendance.dto.ApiResponse;
import com.attendance.entity.ShiftSwapRequest;
import com.attendance.entity.User;
import com.attendance.service.ShiftSwapService;
import com.attendance.service.UserService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/shift-swap")
public class ShiftSwapController {

    private final ShiftSwapService shiftSwapService;
    private final UserService userService;

    public ShiftSwapController(ShiftSwapService shiftSwapService, UserService userService) {
        this.shiftSwapService = shiftSwapService;
        this.userService = userService;
    }

    @GetMapping("")
    public String shiftSwapPage(@AuthenticationPrincipal User user, Model model) {
        List<ShiftSwapRequest> myRequests = shiftSwapService.getSwapRequestsByRequestorId(user.getId());
        List<ShiftSwapRequest> pendingRequests = shiftSwapService.getPendingRequestsForUser(user.getId());
        List<User> allUsers = userService.getAllUsers();

        model.addAttribute("myRequests", myRequests);
        model.addAttribute("pendingRequests", pendingRequests);
        model.addAttribute("allUsers", allUsers);
        model.addAttribute("user", user);

        return "employee/shift-swap";
    }

    @PostMapping("/request")
    @ResponseBody
    public ApiResponse requestShiftSwap(@AuthenticationPrincipal User user,
                                        @RequestParam Long requestedToId,
                                        @RequestParam LocalDate swapDate,
                                        @RequestParam(required = false) String reason) {
        try {
            ShiftSwapRequest request = new ShiftSwapRequest();
            request.setSwapDate(swapDate);
            request.setReason(reason);

            ShiftSwapRequest created = shiftSwapService.createSwapRequest(
                    user.getId(),
                    requestedToId,
                    request
            );
            return ApiResponse.success("Shift swap request sent", created);
        } catch (Exception e) {
            return ApiResponse.error("Error sending request: " + e.getMessage());
        }
    }

    @GetMapping("/requests")
    @ResponseBody
    public ApiResponse getUserRequests(@AuthenticationPrincipal User user) {
        try {
            List<ShiftSwapRequest> requests = shiftSwapService.getSwapRequestsByRequestorId(user.getId());
            return ApiResponse.success("Shift swap requests retrieved", requests);
        } catch (Exception e) {
            return ApiResponse.error("Error retrieving requests: " + e.getMessage());
        }
    }

    @GetMapping("/pending")
    @ResponseBody
    public ApiResponse getPendingRequests(@AuthenticationPrincipal User user) {
        try {
            List<ShiftSwapRequest> requests = shiftSwapService.getPendingRequestsForUser(user.getId());
            return ApiResponse.success("Pending requests retrieved", requests);
        } catch (Exception e) {
            return ApiResponse.error("Error retrieving pending requests: " + e.getMessage());
        }
    }

    @PostMapping("/{id}/approve")
    @ResponseBody
    public ApiResponse approveShiftSwap(@PathVariable Long id,
                                        @AuthenticationPrincipal User user) {
        try {
            ShiftSwapRequest request = shiftSwapService.approveSwapRequest(id);
            return ApiResponse.success("Shift swap approved", request);
        } catch (Exception e) {
            return ApiResponse.error("Error approving request: " + e.getMessage());
        }
    }

    @PostMapping("/{id}/reject")
    @ResponseBody
    public ApiResponse rejectShiftSwap(@PathVariable Long id,
                                       @RequestParam(required = false) String reason,
                                       @AuthenticationPrincipal User user) {
        try {
            ShiftSwapRequest request = shiftSwapService.rejectSwapRequest(id, reason);
            return ApiResponse.success("Shift swap rejected", request);
        } catch (Exception e) {
            return ApiResponse.error("Error rejecting request: " + e.getMessage());
        }
    }

    @PostMapping("/{id}/cancel")
    @ResponseBody
    public ApiResponse cancelShiftSwap(@PathVariable Long id,
                                       @AuthenticationPrincipal User user) {
        try {
            ShiftSwapRequest request = shiftSwapService.getSwapRequestById(id);

            // Check if user is the requestor
            if (!request.getRequestor().getId().equals(user.getId())) {
                return ApiResponse.error("Only the requestor can cancel the swap");
            }

            // Update status to CANCELLED
            request.setStatus("CANCELLED");
            shiftSwapService.updateSwapRequest(request);

            return ApiResponse.success("Shift swap cancelled");
        } catch (Exception e) {
            return ApiResponse.error("Error cancelling request: " + e.getMessage());
        }
    }

    @GetMapping("/admin/pending")
    public String adminPendingSwaps(@AuthenticationPrincipal User user, Model model) {
        List<ShiftSwapRequest> pendingSwaps = shiftSwapService.getPendingSwapRequests();
        model.addAttribute("pendingSwaps", pendingSwaps);
        model.addAttribute("user", user);
        return "admin/shift-swap-approvals";
    }
}