package com.attendance.controller;

import com.attendance.dto.LoginRequest;
import com.attendance.entity.User;
import com.attendance.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@Controller
@RequestMapping("/auth")
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String showLoginForm(Model model,
                                @RequestParam(value = "error", required = false) String error,
                                @RequestParam(value = "logout", required = false) String logout,
                                @RequestParam(value = "expired", required = false) String expired) {

        if (error != null) {
            model.addAttribute("error", "Invalid email or password!");
        }
        if (logout != null) {
            model.addAttribute("message", "You have been logged out successfully.");
        }
        if (expired != null) {
            model.addAttribute("error", "Your session has expired. Please login again.");
        }

        model.addAttribute("loginRequest", new LoginRequest());
        return "auth/login";
    }

    @PostMapping("/login")
    public String processLogin(@ModelAttribute LoginRequest loginRequest, Model model) {
        // This method won't be called directly due to Spring Security
        // It's here just for reference
        return "redirect:/dashboard";
    }

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new User());
        return "auth/register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("user") User user,
                           BindingResult result,
                           Model model) {

        if (result.hasErrors()) {
            return "auth/register";
        }

        try {
            // Check if email already exists using UserService
            if (userService.emailExists(user.getEmail())) {
                model.addAttribute("error", "Email already registered");
                return "auth/register";
            }

            // Set required fields
            user.setRole("ROLE_EMPLOYEE");
            user.setStatus("ACTIVE");

            // Set joining date if not provided
            if (user.getJoiningDate() == null) {
                user.setJoiningDate(LocalDate.now());
            }

            // Set department and position if not provided (default values)
            if (user.getDepartment() == null || user.getDepartment().isEmpty()) {
                user.setDepartment("General");
            }
            if (user.getPosition() == null || user.getPosition().isEmpty()) {
                user.setPosition("Employee");
            }

            // Create user (password stored as plain text)
            userService.createUser(user);

            model.addAttribute("success", "Registration successful! Please login.");
            model.addAttribute("loginRequest", new LoginRequest());
            return "auth/login";

        } catch (Exception e) {
            model.addAttribute("error", "Registration failed: " + e.getMessage());
            return "auth/register";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        SecurityContextHolder.clearContext();
        return "redirect:/auth/login?logout=true";
    }

    @GetMapping("/forgot-password")
    public String showForgotPasswordForm() {
        return "auth/forgot-password";
    }

    @PostMapping("/forgot-password")
    public String forgotPassword(@RequestParam String email, Model model) {
        try {
            // Check if email exists
            userService.getUserByEmail(email);
            model.addAttribute("success", "Password reset instructions sent to your email");
        } catch (Exception e) {
            model.addAttribute("error", "Email not found in our system");
        }
        return "auth/forgot-password";
    }
}