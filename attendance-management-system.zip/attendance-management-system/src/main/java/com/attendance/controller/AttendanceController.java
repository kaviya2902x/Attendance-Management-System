package com.attendance.controller;

import com.attendance.dto.ApiResponse;
import com.attendance.dto.AttendanceDTO;
import com.attendance.entity.Attendance;
import com.attendance.entity.User;
import com.attendance.service.AttendanceService;
import com.attendance.service.UserService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;

@Controller
@RequestMapping("/attendance")
public class AttendanceController {

    private final AttendanceService attendanceService;
    private final UserService userService;

    public AttendanceController(AttendanceService attendanceService, UserService userService) {
        this.attendanceService = attendanceService;
        this.userService = userService;
    }

    @GetMapping("/mark")
    public String showAttendancePage(@AuthenticationPrincipal UserDetails securityUser, Model model) {
        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            Attendance todayAttendance = attendanceService.getTodayAttendance(user.getId());
            model.addAttribute("todayAttendance", todayAttendance);
            model.addAttribute("user", user);
            return "employee/attendance";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @PostMapping("/clock-in")
    @ResponseBody
    public ApiResponse clockIn(@AuthenticationPrincipal UserDetails securityUser,
                               @RequestParam(required = false) String location) {
        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            Attendance attendance = attendanceService.clockIn(user.getId(), location);
            return ApiResponse.success("Clocked in successfully", attendance);
        } catch (Exception e) {
            return ApiResponse.error("Clock-in failed: " + e.getMessage());
        }
    }

    @PostMapping("/clock-out")
    @ResponseBody
    public ApiResponse clockOut(@AuthenticationPrincipal UserDetails securityUser,
                                @RequestParam(required = false) String location) {
        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            Attendance attendance = attendanceService.clockOut(user.getId(), location);
            return ApiResponse.success("Clocked out successfully", attendance);
        } catch (Exception e) {
            return ApiResponse.error("Clock-out failed: " + e.getMessage());
        }
    }

    @GetMapping("/history")
    public String getAttendanceHistory(@AuthenticationPrincipal UserDetails securityUser,
                                       @RequestParam(required = false) Integer year,
                                       @RequestParam(required = false) Integer month,
                                       Model model) {

        if (securityUser == null) {
            return "redirect:/auth/login";
        }

        if (year == null) year = LocalDate.now().getYear();
        if (month == null) month = LocalDate.now().getMonthValue();

        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            List<Attendance> attendanceList = attendanceService
                    .getUserAttendanceByMonth(user.getId(), year, month);

            AttendanceService.AttendanceSummary summary = attendanceService
                    .getAttendanceSummary(user.getId(), year, month);

            model.addAttribute("attendanceList", attendanceService.convertToDTOList(attendanceList));
            model.addAttribute("summary", summary);
            model.addAttribute("year", year);
            model.addAttribute("month", month);
            model.addAttribute("yearMonth", YearMonth.of(year, month));
            model.addAttribute("user", user);

            return "employee/attendance-history";
        } catch (Exception e) {
            return "redirect:/auth/login?error=true";
        }
    }

    @GetMapping("/api/today")
    @ResponseBody
    public ApiResponse getTodayAttendance(@AuthenticationPrincipal UserDetails securityUser) {
        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            Attendance attendance = attendanceService.getTodayAttendance(user.getId());
            return ApiResponse.success("Today's attendance retrieved", attendance);
        } catch (Exception e) {
            return ApiResponse.error("Error retrieving attendance: " + e.getMessage());
        }
    }

    @GetMapping("/api/monthly/{year}/{month}")
    @ResponseBody
    public ApiResponse getMonthlyAttendance(@AuthenticationPrincipal UserDetails securityUser,
                                            @PathVariable int year,
                                            @PathVariable int month) {
        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            List<Attendance> attendanceList = attendanceService
                    .getUserAttendanceByMonth(user.getId(), year, month);

            AttendanceService.AttendanceSummary summary = attendanceService
                    .getAttendanceSummary(user.getId(), year, month);

            return ApiResponse.success("Monthly attendance retrieved",
                    new Object[]{attendanceList, summary});
        } catch (Exception e) {
            return ApiResponse.error("Error retrieving monthly attendance: " + e.getMessage());
        }
    }

    @PostMapping("/api/manual")
    @ResponseBody
    public ApiResponse markManualAttendance(@AuthenticationPrincipal UserDetails securityUser,
                                            @RequestParam LocalDate date,
                                            @RequestParam String clockIn,
                                            @RequestParam String clockOut) {
        try {
            User user = userService.getUserByEmail(securityUser.getUsername());
            Attendance attendance = attendanceService.markAttendance(
                    user.getId(),
                    date,
                    java.time.LocalTime.parse(clockIn),
                    java.time.LocalTime.parse(clockOut)
            );
            return ApiResponse.success("Attendance marked successfully", attendance);
        } catch (Exception e) {
            return ApiResponse.error("Error marking attendance: " + e.getMessage());
        }
    }
}