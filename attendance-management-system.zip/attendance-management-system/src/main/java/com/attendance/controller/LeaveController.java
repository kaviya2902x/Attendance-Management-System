package com.attendance.controller;

import com.attendance.dto.ApiResponse;
import com.attendance.entity.LeaveApplication;
import com.attendance.entity.User;
import com.attendance.service.LeaveService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/leave")
public class LeaveController {

    private final LeaveService leaveService;

    public LeaveController(LeaveService leaveService) {
        this.leaveService = leaveService;
    }

    @GetMapping("/apply")
    public String showLeaveApplicationForm(@AuthenticationPrincipal User user, Model model) {
        model.addAttribute("leaveApplication", new LeaveApplication());
        model.addAttribute("user", user);
        return "employee/leave-apply";
    }

    @PostMapping("/apply")
    public String applyLeave(@AuthenticationPrincipal User user,
                             @ModelAttribute LeaveApplication leaveApplication,
                             Model model) {
        try {
            leaveService.applyLeave(user.getId(), leaveApplication);
            model.addAttribute("success", "Leave application submitted successfully");
        } catch (Exception e) {
            model.addAttribute("error", "Error applying leave: " + e.getMessage());
        }
        return "employee/leave-apply";
    }

    @GetMapping("/history")
    public String getLeaveHistory(@AuthenticationPrincipal User user, Model model) {
        List<LeaveApplication> leaves = leaveService.getUserLeaves(user.getId());
        model.addAttribute("leaves", leaves);
        model.addAttribute("user", user);
        return "employee/leave-history";
    }

    @GetMapping("/pending")
    public String getPendingLeaves(@AuthenticationPrincipal User user, Model model) {
        List<LeaveApplication> pendingLeaves = leaveService
                .getPendingLeavesByManager(user.getEmail());
        model.addAttribute("pendingLeaves", pendingLeaves);
        model.addAttribute("user", user);
        return "manager/leave-approvals";
    }

    @PostMapping("/{id}/approve")
    @ResponseBody
    public ApiResponse approveLeave(@PathVariable Long id,
                                    @AuthenticationPrincipal User user) {
        try {
            LeaveApplication leave = leaveService.approveLeave(id, user.getEmail());
            return ApiResponse.success("Leave approved successfully", leave);
        } catch (Exception e) {
            return ApiResponse.error("Error approving leave: " + e.getMessage());
        }
    }

    @PostMapping("/{id}/reject")
    @ResponseBody
    public ApiResponse rejectLeave(@PathVariable Long id,
                                   @RequestParam String reason,
                                   @AuthenticationPrincipal User user) {
        try {
            LeaveApplication leave = leaveService.rejectLeave(id, user.getEmail(), reason);
            return ApiResponse.success("Leave rejected successfully", leave);
        } catch (Exception e) {
            return ApiResponse.error("Error rejecting leave: " + e.getMessage());
        }
    }

    @PostMapping("/{id}/cancel")
    @ResponseBody
    public ApiResponse cancelLeave(@PathVariable Long id) {
        try {
            leaveService.cancelLeave(id);
            return ApiResponse.success("Leave cancelled successfully");
        } catch (Exception e) {
            return ApiResponse.error("Error cancelling leave: " + e.getMessage());
        }
    }
}