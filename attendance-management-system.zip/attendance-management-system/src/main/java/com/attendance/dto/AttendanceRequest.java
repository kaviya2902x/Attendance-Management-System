package com.attendance.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceRequest {

    @NotNull(message = "Date is required")
    private LocalDate date;

    private LocalTime clockInTime;

    private LocalTime clockOutTime;

    private String clockInLocation;

    private String clockOutLocation;

    private String notes;
}