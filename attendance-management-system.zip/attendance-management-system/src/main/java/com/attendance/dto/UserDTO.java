package com.attendance.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {

    private Long id;
    private String employeeId;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private LocalDate dateOfBirth;
    private String role;
    private String department;
    private String position;
    private LocalDate joiningDate;
    private String reportingManager;
    private String emergencyContact;
    private String emergencyPhone;
    private String currentAddress;
    private String permanentAddress;
    private String profileImage;
    private String status;
    private LocalDate createdAt;
    private LocalDate updatedAt;
}