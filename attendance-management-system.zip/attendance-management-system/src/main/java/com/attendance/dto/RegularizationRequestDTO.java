package com.attendance.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegularizationRequestDTO {

    @NotNull(message = "Attendance date is required")
    private LocalDate attendanceDate;

    @NotBlank(message = "Requested clock-in time is required")
    private String requestedClockIn;

    @NotBlank(message = "Requested clock-out time is required")
    private String requestedClockOut;

    @NotBlank(message = "Reason is required")
    private String reason;
}