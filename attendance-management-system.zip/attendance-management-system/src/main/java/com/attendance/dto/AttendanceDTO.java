package com.attendance.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceDTO {

    private Long id;
    private Long userId;
    private String employeeName;
    private String employeeId;
    private LocalDate attendanceDate;
    private LocalTime clockInTime;
    private LocalTime clockOutTime;
    private Double totalHours;
    private String status;
    private Integer lateMinutes;
    private Integer earlyDepartureMinutes;
    private Double overtimeHours;
    private String notes;
    private String clockInLocation;
    private String clockOutLocation;
}