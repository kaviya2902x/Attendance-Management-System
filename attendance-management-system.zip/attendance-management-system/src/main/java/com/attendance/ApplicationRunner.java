package com.attendance;

import com.attendance.entity.*;
import com.attendance.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;

@Component
public class ApplicationRunner implements CommandLineRunner {

    private final UserRepository userRepository;
    private final ShiftRepository shiftRepository;
    private final HolidayRepository holidayRepository;

    public ApplicationRunner(UserRepository userRepository,
                             ShiftRepository shiftRepository,
                             HolidayRepository holidayRepository) {
        this.userRepository = userRepository;
        this.shiftRepository = shiftRepository;
        this.holidayRepository = holidayRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("=== Initializing Application with Default Data ===");

        // Create default shifts
        if (shiftRepository.count() == 0) {
            Shift morningShift = new Shift();
            morningShift.setName("Morning Shift");
            morningShift.setStartTime(LocalTime.of(9, 0));
            morningShift.setEndTime(LocalTime.of(17, 0));
            morningShift.setDescription("Regular 9-5 shift");
            // REMOVED: morningShift.setActive(true); - Field doesn't exist

            Shift nightShift = new Shift();
            nightShift.setName("Night Shift");
            nightShift.setStartTime(LocalTime.of(22, 0));
            nightShift.setEndTime(LocalTime.of(6, 0));
            nightShift.setDescription("Night shift");
            // REMOVED: nightShift.setActive(true); - Field doesn't exist

            shiftRepository.saveAll(Arrays.asList(morningShift, nightShift));
            System.out.println("✓ Created default shifts");
        }

        // Create admin user
        if (userRepository.findByEmail("admin@techcorp.com").isEmpty()) {
            User admin = new User();
            admin.setEmployeeId("ADMIN001");
            admin.setFirstName("Admin");
            admin.setLastName("System");
            admin.setEmail("admin@techcorp.com");
            admin.setPassword("admin123"); // Plain text password
            admin.setRole("ROLE_ADMIN");
            admin.setDepartment("Administration");
            admin.setPosition("System Administrator");
            admin.setJoiningDate(LocalDate.now());
            admin.setStatus("ACTIVE");
            admin.setPhoneNumber("+1234567890");
            admin.setCreatedAt(LocalDate.now());
            admin.setUpdatedAt(LocalDate.now());

            userRepository.save(admin);
            System.out.println("✓ Created admin user: admin@techcorp.com / admin123");
        }

        // Create sample employee
        if (userRepository.findByEmail("john.doe@techcorp.com").isEmpty()) {
            User employee = new User();
            employee.setEmployeeId("EMP002");
            employee.setFirstName("John");
            employee.setLastName("Doe");
            employee.setEmail("john.doe@techcorp.com");
            employee.setPassword("password123"); // Plain text password
            employee.setRole("ROLE_EMPLOYEE");
            employee.setDepartment("IT");
            employee.setPosition("Software Developer");
            employee.setJoiningDate(LocalDate.now().minusMonths(6));
            employee.setStatus("ACTIVE");
            employee.setPhoneNumber("+1234567891");
            employee.setCreatedAt(LocalDate.now());
            employee.setUpdatedAt(LocalDate.now());

            userRepository.save(employee);
            System.out.println("✓ Created employee user: john.doe@techcorp.com / password123");
        }

        // Create sample manager
        if (userRepository.findByEmail("jane.smith@techcorp.com").isEmpty()) {
            User manager = new User();
            manager.setEmployeeId("MGR001");
            manager.setFirstName("Jane");
            manager.setLastName("Smith");
            manager.setEmail("jane.smith@techcorp.com");
            manager.setPassword("manager123"); // Plain text password
            manager.setRole("ROLE_MANAGER");
            manager.setDepartment("Management");
            manager.setPosition("Project Manager");
            manager.setJoiningDate(LocalDate.now().minusMonths(12));
            manager.setStatus("ACTIVE");
            manager.setPhoneNumber("+1234567892");
            manager.setCreatedAt(LocalDate.now());
            manager.setUpdatedAt(LocalDate.now());

            userRepository.save(manager);
            System.out.println("✓ Created manager user: jane.smith@techcorp.com / manager123");
        }

        // Add sample holidays
        if (holidayRepository.count() == 0) {
            Holiday newYear = new Holiday();
            newYear.setName("New Year's Day");
            newYear.setDate(LocalDate.of(LocalDate.now().getYear(), 1, 1));
            newYear.setDescription("Public Holiday");
            newYear.setType("NATIONAL");
            newYear.setRecurring(true);
            newYear.setCreatedAt(LocalDate.now());

            Holiday christmas = new Holiday();
            christmas.setName("Christmas Day");
            christmas.setDate(LocalDate.of(LocalDate.now().getYear(), 12, 25));
            christmas.setDescription("Public Holiday");
            christmas.setType("NATIONAL");
            christmas.setRecurring(true);
            christmas.setCreatedAt(LocalDate.now());

            holidayRepository.saveAll(Arrays.asList(newYear, christmas));
            System.out.println("✓ Created sample holidays");
        }

        System.out.println("\n=== APPLICATION READY ===");
        System.out.println("Test Login Credentials:");
        System.out.println("1. Admin: admin@techcorp.com / admin123");
        System.out.println("2. Employee: john.doe@techcorp.com / password123");
        System.out.println("3. Manager: jane.smith@techcorp.com / manager123");
        System.out.println("\nApplication initialized successfully!");
    }
}