package com.attendance.repository;

import com.attendance.entity.ShiftSwapRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface ShiftSwapRepository extends JpaRepository<ShiftSwapRequest, Long> {

    List<ShiftSwapRequest> findByRequestorId(Long requestorId);

    List<ShiftSwapRequest> findByRequestedToId(Long requestedToId);

    List<ShiftSwapRequest> findByRequestedToIdAndStatus(Long requestedToId, String status);

    List<ShiftSwapRequest> findByStatus(String status);

    @Query("SELECT s FROM ShiftSwapRequest s WHERE s.requestor.id = :userId OR s.requestedTo.id = :userId")
    List<ShiftSwapRequest> findByRequestorIdOrRequestedToId(@Param("userId") Long userId, @Param("userId") Long userId2);

    Optional<ShiftSwapRequest> findByRequestorIdAndRequestedToIdAndSwapDateAndStatus(
            Long requestorId, Long requestedToId, LocalDate swapDate, String status);

    @Query("SELECT s FROM ShiftSwapRequest s WHERE s.requestor.id = :userId AND s.swapDate >= :date")
    List<ShiftSwapRequest> findUpcomingSwapsByRequestor(@Param("userId") Long userId, @Param("date") LocalDate date);

    @Query("SELECT s FROM ShiftSwapRequest s WHERE s.requestedTo.id = :userId AND s.swapDate >= :date AND s.status = 'PENDING'")
    List<ShiftSwapRequest> findPendingSwapsForUser(@Param("userId") Long userId, @Param("date") LocalDate date);

    @Query("SELECT COUNT(s) FROM ShiftSwapRequest s WHERE s.requestor.id = :userId AND s.status = 'PENDING'")
    Long countPendingRequestsByUser(@Param("userId") Long userId);
}