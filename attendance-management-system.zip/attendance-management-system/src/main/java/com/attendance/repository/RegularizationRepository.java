package com.attendance.repository;

import com.attendance.entity.RegularizationRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RegularizationRepository extends JpaRepository<RegularizationRequest, Long> {

    List<RegularizationRequest> findByUserId(Long userId);

    List<RegularizationRequest> findByStatus(String status);

    List<RegularizationRequest> findByUserIdAndStatus(Long userId, String status);
}