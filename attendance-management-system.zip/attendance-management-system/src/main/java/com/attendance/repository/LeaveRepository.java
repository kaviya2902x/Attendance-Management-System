package com.attendance.repository;

import com.attendance.entity.LeaveApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface LeaveRepository extends JpaRepository<LeaveApplication, Long> {

    List<LeaveApplication> findByUserId(Long userId);

    List<LeaveApplication> findByUserIdAndStatus(Long userId, String status);

    List<LeaveApplication> findByStatus(String status);

    @Query("SELECT l FROM LeaveApplication l WHERE l.status = 'PENDING' " +
            "AND l.user.reportingManager = :managerEmail")
    List<LeaveApplication> findPendingByManager(@Param("managerEmail") String managerEmail);

    @Query("SELECT l FROM LeaveApplication l WHERE l.user.id = :userId " +
            "AND ((l.startDate <= :endDate AND l.endDate >= :startDate) " +
            "OR (l.startDate BETWEEN :startDate AND :endDate) " +
            "OR (l.endDate BETWEEN :startDate AND :endDate))")
    List<LeaveApplication> findOverlappingLeaves(@Param("userId") Long userId,
                                                 @Param("startDate") LocalDate startDate,
                                                 @Param("endDate") LocalDate endDate);

    @Query("SELECT SUM(l.totalDays) FROM LeaveApplication l WHERE l.user.id = :userId " +
            "AND l.status = 'APPROVED' AND YEAR(l.startDate) = :year")
    Integer getTotalApprovedLeaveDays(@Param("userId") Long userId, @Param("year") int year);
}