package com.attendance.repository;

import com.attendance.entity.OnDutyApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface OnDutyRepository extends JpaRepository<OnDutyApplication, Long> {

    List<OnDutyApplication> findByUserId(Long userId);

    List<OnDutyApplication> findByStatus(String status);

    @Query("SELECT o FROM OnDutyApplication o WHERE o.user.id = :userId " +
            "AND o.status = :status " +
            "AND ((o.startDate <= :endDate AND o.endDate >= :startDate))")
    List<OnDutyApplication> findByUserIdAndStatusAndDateRange(
            @Param("userId") Long userId,
            @Param("status") String status,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate);

    @Query("SELECT o FROM OnDutyApplication o WHERE o.status = 'APPROVED' " +
            "AND o.startDate <= :date AND o.endDate >= :date")
    List<OnDutyApplication> findApprovedOnDate(@Param("date") LocalDate date);
}