package com.attendance.repository;

import com.attendance.entity.Attendance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {

    Optional<Attendance> findByUserIdAndAttendanceDate(Long userId, LocalDate date);

    List<Attendance> findByUserId(Long userId);

    List<Attendance> findByUserIdAndAttendanceDateBetween(Long userId, LocalDate startDate, LocalDate endDate);

    List<Attendance> findByAttendanceDate(LocalDate date);

    List<Attendance> findByAttendanceDateBetween(LocalDate startDate, LocalDate endDate);

    @Query("SELECT a FROM Attendance a WHERE a.user.department = :department AND a.attendanceDate = :date")
    List<Attendance> findByDepartmentAndDate(@Param("department") String department,
                                             @Param("date") LocalDate date);

    @Query("SELECT COUNT(a) FROM Attendance a WHERE a.user.id = :userId AND a.status = 'PRESENT' " +
            "AND a.attendanceDate BETWEEN :startDate AND :endDate")
    Long countPresentDays(@Param("userId") Long userId,
                          @Param("startDate") LocalDate startDate,
                          @Param("endDate") LocalDate endDate);

    @Query("SELECT a FROM Attendance a WHERE a.user.id = :userId AND YEAR(a.attendanceDate) = :year " +
            "AND MONTH(a.attendanceDate) = :month")
    List<Attendance> findByUserIdAndMonth(@Param("userId") Long userId,
                                          @Param("year") int year,
                                          @Param("month") int month);
}