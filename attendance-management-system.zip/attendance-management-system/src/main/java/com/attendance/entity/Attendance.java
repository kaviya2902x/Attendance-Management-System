package com.attendance.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
@Table(name = "attendance", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"user_id", "attendance_date"})
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Attendance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "attendance_date", nullable = false)
    private LocalDate attendanceDate;

    @Column(name = "clock_in_time")
    private LocalTime clockInTime;

    @Column(name = "clock_out_time")
    private LocalTime clockOutTime;

    @Column(name = "total_hours")
    private Double totalHours;

    @Column(name = "status", nullable = false)
    private String status = "ABSENT"; // PRESENT, ABSENT, HALF_DAY, LEAVE, HOLIDAY

    @Column(name = "late_minutes")
    private Integer lateMinutes = 0;

    @Column(name = "early_departure_minutes")
    private Integer earlyDepartureMinutes = 0;

    @Column(name = "overtime_hours")
    private Double overtimeHours = 0.0;

    @Column(name = "notes")
    private String notes;

    @Column(name = "clock_in_location")
    private String clockInLocation;

    @Column(name = "clock_out_location")
    private String clockOutLocation;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "updated_at")
    private LocalDateTime updatedAt = LocalDateTime.now();

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public Double calculateTotalHours() {
        if (clockInTime != null && clockOutTime != null) {
            long minutes = java.time.Duration.between(clockInTime, clockOutTime).toMinutes();
            return minutes / 60.0;
        }
        return 0.0;
    }
}