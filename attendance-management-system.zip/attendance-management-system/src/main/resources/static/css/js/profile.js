// Profile Page JavaScript
$(document).ready(function() {
    // Check authentication
    const userStr = localStorage.getItem('user');
    if (!userStr) {
        window.location.href = '/login';
        return;
    }

    // Load profile data
    loadProfileData();

    // Event listeners
    $('#logoutBtn').click(logout);
});

// Load profile data
function loadProfileData() {
    const userStr = localStorage.getItem('user');
    if (!userStr) return;

    const user = JSON.parse(userStr);

    // Update all profile fields
    $('#userFullName').text(user.firstName + ' ' + user.lastName);
    $('#firstName').text(user.firstName);
    $('#lastName').text(user.lastName);
    $('#userEmail').text(user.email);
    $('#userPhone').text(user.phone || 'Not set');
    $('#userRole').text(user.role);
    $('#employeeId').text(user.employeeId);
    $('#department').text(user.department || 'Not assigned');
    $('#designation').text(user.designation || 'Not assigned');
    $('#userDesignation').text(user.designation || 'Not assigned');
    $('#userDepartment').text(user.department || 'Not assigned');
    $('#userEmployeeId').text(user.employeeId);

    // Set initials for avatar
    const initials = (user.firstName.charAt(0) + user.lastName.charAt(0)).toUpperCase();
    $('#userAvatar').html(initials);

    // Set account status
    if (user.isActive) {
        $('#accountStatus').removeClass('bg-danger').addClass('bg-success').text('Active');
    } else {
        $('#accountStatus').removeClass('bg-success').addClass('bg-danger').text('Inactive');
    }

    // Set modal form values
    $('#editFirstName').val(user.firstName);
    $('#editLastName').val(user.lastName);
    $('#editEmail').val(user.email);
    $('#editPhone').val(user.phone || '');
}

// Change password
function changePassword() {
    const currentPassword = $('#currentPassword').val();
    const newPassword = $('#newPassword').val();
    const confirmPassword = $('#confirmPassword').val();

    if (!currentPassword || !newPassword || !confirmPassword) {
        showToast('Please fill all password fields', 'warning');
        return;
    }

    if (newPassword !== confirmPassword) {
        showToast('New passwords do not match', 'danger');
        return;
    }

    if (newPassword.length < 6) {
        showToast('Password must be at least 6 characters', 'warning');
        return;
    }

    // In a real application, you would make an API call to change password
    showToast('Password change feature coming soon!', 'info');
    $('#changePasswordModal').modal('hide');
    $('#passwordForm')[0].reset();
}

// Update profile
function updateProfile() {
    const firstName = $('#editFirstName').val().trim();
    const lastName = $('#editLastName').val().trim();
    const email = $('#editEmail').val().trim();
    const phone = $('#editPhone').val().trim();

    if (!firstName || !lastName || !email) {
        showToast('Please fill all required fields', 'warning');
        return;
    }

    const userStr = localStorage.getItem('user');
    if (!userStr) return;

    const user = JSON.parse(userStr);

    // Update user object
    user.firstName = firstName;
    user.lastName = lastName;
    user.email = email;
    user.phone = phone;

    // Save updated user to localStorage
    localStorage.setItem('user', JSON.stringify(user));

    // Update UI
    loadProfileData();

    showToast('Profile updated successfully', 'success');
    $('#updateProfileModal').modal('hide');
}

// Download profile
function downloadProfile() {
    const userStr = localStorage.getItem('user');
    if (!userStr) return;

    const user = JSON.parse(userStr);

    // Create profile content
    const profileContent = `
        EMPLOYEE PROFILE
        =====================
        
        Personal Information:
        ---------------------
        Name: ${user.firstName} ${user.lastName}
        Employee ID: ${user.employeeId}
        Email: ${user.email}
        Phone: ${user.phone || 'Not provided'}
        Role: ${user.role}
        
        Employment Details:
        --------------------
        Department: ${user.department || 'Not assigned'}
        Designation: ${user.designation || 'Not assigned'}
        Status: ${user.isActive ? 'Active' : 'Inactive'}
        
        Generated on: ${new Date().toLocaleString()}
        System: Attendance Management System
    `;

    // Create and download file
    const blob = new Blob([profileContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `profile_${user.employeeId}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('Profile downloaded successfully', 'success');
}

// Logout function
function logout() {
    localStorage.clear();
    window.location.href = '/login';
}