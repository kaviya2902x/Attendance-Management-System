// Dashboard functionality
let currentUser = null;
let currentAttendance = null;

// Initialize dashboard
$(document).ready(function() {
    // Check authentication
    const userStr = localStorage.getItem('user');
    if (!userStr) {
        window.location.href = '/login';
        return;
    }

    // Parse user data
    try {
        currentUser = JSON.parse(userStr);
        updateUserInfo();
        loadDashboardData();
    } catch (error) {
        console.error('Error parsing user data:', error);
        logout();
    }

    // Update time every second
    setInterval(updateDateTime, 1000);

    // Check attendance status every 30 seconds
    setInterval(checkAttendanceStatus, 30000);

    // Event listeners
    $('#logoutBtn').click(logout);
});

// Update user information in UI
function updateUserInfo() {
    if (!currentUser) return;

    $('#userName').text(currentUser.firstName + ' ' + currentUser.lastName);
    $('#userRole').text(currentUser.role);

    if (currentUser.designation) {
        $('.user-designation').text(currentUser.designation);
    }
    if (currentUser.department) {
        $('.user-department').text(currentUser.department);
    }
}

// Update date and time
function updateDateTime() {
    const now = new Date();
    const dateStr = now.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    const timeStr = now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    });

    $('#currentDate').text('Today: ' + dateStr);
    $('#currentTime').text(timeStr);
}

// Load dashboard data
function loadDashboardData() {
    if (!currentUser) return;

    // Load today's attendance
    $.ajax({
        url: API_BASE_URL + '/attendance/today/' + currentUser.id,
        method: 'GET',
        success: function(attendance) {
            currentAttendance = attendance;
            updateAttendanceUI(attendance);
        },
        error: function(error) {
            console.error('Error loading attendance:', error);
        }
    });

    // Load monthly stats
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth() + 1;

    $.ajax({
        url: `${API_BASE_URL}/attendance/monthly/${currentUser.id}?year=${year}&month=${month}`,
        method: 'GET',
        success: function(attendanceList) {
            updateMonthlyStats(attendanceList);
            updateRecentAttendance(attendanceList);
        },
        error: function(error) {
            console.error('Error loading monthly stats:', error);
        }
    });
}

// Update attendance UI
function updateAttendanceUI(attendance) {
    if (!attendance) {
        $('#clockInTime').text('--:--');
        $('#clockOutTime').text('--:--');
        $('#totalHours').text('0.00');
        $('#currentStatus').text('Ready').removeClass('bg-success bg-danger').addClass('bg-secondary');
        $('#attendanceStatus').text('Not Started');
        $('#lateMinutes').text('0');
        $('#overtimeMinutes').text('0');
        $('#ipAddress').text('-');
        $('#clockInBtn').prop('disabled', false);
        $('#clockOutBtn').prop('disabled', true);
        $('#workProgress').css('width', '0%');
        return;
    }

    // Update clock times
    if (attendance.clockIn) {
        const clockInTime = attendance.clockIn.substring(0, 5);
        $('#clockInTime').text(clockInTime);
        $('#clockInBtn').prop('disabled', true)
            .removeClass('btn-success').addClass('btn-secondary')
            .html('<i class="fas fa-check me-2"></i>Clocked In');
        $('#currentStatus').text('Working').removeClass('bg-secondary bg-danger').addClass('bg-success');
        $('#attendanceStatus').text('Present');
        $('#ipAddress').text(attendance.ipAddress || '-');
    }

    if (attendance.clockOut) {
        const clockOutTime = attendance.clockOut.substring(0, 5);
        $('#clockOutTime').text(clockOutTime);
        $('#clockOutBtn').prop('disabled', true)
            .removeClass('btn-danger').addClass('btn-secondary')
            .html('<i class="fas fa-check me-2"></i>Clocked Out');
        $('#currentStatus').text('Completed').removeClass('bg-success bg-secondary').addClass('bg-info');
        $('#attendanceStatus').text('Completed');
    } else if (attendance.clockIn) {
        $('#clockOutBtn').prop('disabled', false);
    }

    // Update other fields
    if (attendance.totalHours) {
        $('#totalHours').text(attendance.totalHours.toFixed(2));
        // Update progress bar (assuming 8-hour work day)
        const progress = Math.min((attendance.totalHours / 8) * 100, 100);
        $('#workProgress').css('width', progress + '%');
    }

    if (attendance.lateMinutes) {
        $('#lateMinutes').text(attendance.lateMinutes);
    }

    if (attendance.overtimeMinutes) {
        $('#overtimeMinutes').text(attendance.overtimeMinutes);
    }
}

// Update monthly statistics
function updateMonthlyStats(attendanceList) {
    if (!attendanceList || !Array.isArray(attendanceList)) return;

    let present = 0, absent = 0, late = 0, overtime = 0;

    attendanceList.forEach(record => {
        if (record.status === 'PRESENT') present++;
        if (record.status === 'ABSENT') absent++;
        if (record.lateMinutes > 0) late++;
        if (record.overtimeMinutes > 0) overtime++;
    });

    $('#presentDays').text(present);
    $('#absentDays').text(absent);
    $('#lateDays').text(late);
    $('#overtimeDays').text(overtime);
}

// Update recent attendance table
function updateRecentAttendance(attendanceList) {
    if (!attendanceList || !Array.isArray(attendanceList)) return;

    const tableBody = $('#recentAttendance');
    tableBody.empty();

    // Sort by date (most recent first) and take last 7 days
    const sortedList = attendanceList.sort((a, b) =>
        new Date(b.date) - new Date(a.date)
    ).slice(0, 7);

    if (sortedList.length === 0) {
        tableBody.append(`
            <tr>
                <td colspan="7" class="text-center text-muted">
                    No attendance records found
                </td>
            </tr>
        `);
        return;
    }

    sortedList.forEach(record => {
        const date = new Date(record.date);
        const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
        const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

        const clockIn = record.clockIn ? record.clockIn.substring(0, 5) : '--:--';
        const clockOut = record.clockOut ? record.clockOut.substring(0, 5) : '--:--';
        const totalHours = record.totalHours ? record.totalHours.toFixed(2) : '--';

        let statusBadge = '';
        switch(record.status) {
            case 'PRESENT':
                statusBadge = '<span class="badge bg-success">Present</span>';
                break;
            case 'ABSENT':
                statusBadge = '<span class="badge bg-danger">Absent</span>';
                break;
            case 'HALF_DAY':
                statusBadge = '<span class="badge bg-warning">Half Day</span>';
                break;
            case 'LEAVE':
                statusBadge = '<span class="badge bg-info">Leave</span>';
                break;
            default:
                statusBadge = '<span class="badge bg-secondary">' + record.status + '</span>';
        }

        const row = `
            <tr>
                <td>${dateStr}</td>
                <td>${dayName}</td>
                <td>${clockIn}</td>
                <td>${clockOut}</td>
                <td>${totalHours}</td>
                <td>${statusBadge}</td>
                <td>${record.lateMinutes || 0} min</td>
            </tr>
        `;

        tableBody.append(row);
    });
}

// Clock In function
function clockIn() {
    if (!currentUser) {
        showToast('Please login first', 'warning');
        return;
    }

    $('#clockInBtn').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Processing...');

    $.ajax({
        url: API_BASE_URL + '/attendance/clock-in?userId=' + currentUser.id,
        method: 'POST',
        success: function(response) {
            if (response.success) {
                showToast(response.message, 'success');
                currentAttendance = response.data;
                updateAttendanceUI(response.data);
                loadDashboardData(); // Refresh all data
            } else {
                showToast(response.message, 'danger');
                $('#clockInBtn').prop('disabled', false)
                    .html('<i class="fas fa-sign-in-alt me-2"></i>Clock In');
            }
        },
        error: function(xhr, status, error) {
            showToast('Error clocking in: ' + error, 'danger');
            $('#clockInBtn').prop('disabled', false)
                .html('<i class="fas fa-sign-in-alt me-2"></i>Clock In');
        }
    });
}

// Clock Out function
function clockOut() {
    if (!currentUser) {
        showToast('Please login first', 'warning');
        return;
    }

    $('#clockOutBtn').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Processing...');

    $.ajax({
        url: API_BASE_URL + '/attendance/clock-out?userId=' + currentUser.id,
        method: 'POST',
        success: function(response) {
            if (response.success) {
                showToast(response.message, 'success');
                currentAttendance = response.data;
                updateAttendanceUI(response.data);
                loadDashboardData(); // Refresh all data
            } else {
                showToast(response.message, 'danger');
                $('#clockOutBtn').prop('disabled', false)
                    .html('<i class="fas fa-sign-out-alt me-2"></i>Clock Out');
            }
        },
        error: function(xhr, status, error) {
            showToast('Error clocking out: ' + error, 'danger');
            $('#clockOutBtn').prop('disabled', false)
                .html('<i class="fas fa-sign-out-alt me-2"></i>Clock Out');
        }
    });
}

// Check attendance status
function checkAttendanceStatus() {
    if (!currentUser) return;

    $.ajax({
        url: API_BASE_URL + '/attendance/today/' + currentUser.id,
        method: 'GET',
        success: function(attendance) {
            if (JSON.stringify(attendance) !== JSON.stringify(currentAttendance)) {
                currentAttendance = attendance;
                updateAttendanceUI(attendance);
            }
        },
        error: function(error) {
            console.error('Error checking attendance:', error);
        }
    });
}

// Quick action functions
function applyLeave() {
    showToast('Leave application feature coming soon!', 'info');
}

function applyRegularization() {
    showToast('Regularization feature coming soon!', 'info');
}

function requestShiftSwap() {
    showToast('Shift swap feature coming soon!', 'info');
}

function applyOnDuty() {
    showToast('On Duty application feature coming soon!', 'info');
}

function requestWFH() {
    showToast('WFH request feature coming soon!', 'info');
}

function downloadReport() {
    showToast('Report download feature coming soon!', 'info');
}