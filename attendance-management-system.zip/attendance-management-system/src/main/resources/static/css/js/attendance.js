// Attendance Page JavaScript
let currentMonth = new Date().getMonth() + 1;
let currentYear = new Date().getFullYear();
let attendanceData = [];

$(document).ready(function() {
    // Check authentication
    const userStr = localStorage.getItem('user');
    if (!userStr) {
        window.location.href = '/login';
        return;
    }

    // Set current month/year in selects
    $('#monthSelect').val(currentMonth);
    $('#yearSelect').val(currentYear);

    // Load attendance data
    loadAttendanceData();

    // Event listeners
    $('#logoutBtn').click(logout);
    $('#monthSelect, #yearSelect').change(function() {
        currentMonth = $('#monthSelect').val();
        currentYear = $('#yearSelect').val();
        loadAttendanceData();
    });
    $('#prevMonth').click(prevMonth);
    $('#nextMonth').click(nextMonth);
});

// Load attendance data
function loadAttendanceData() {
    const userStr = localStorage.getItem('user');
    if (!userStr) return;

    const user = JSON.parse(userStr);
    const userId = user.id;

    // Load monthly attendance
    $.ajax({
        url: `${API_BASE_URL}/attendance/monthly/${userId}?year=${currentYear}&month=${currentMonth}`,
        method: 'GET',
        success: function(data) {
            attendanceData = data;
            updateCalendar();
            updateAttendanceDetails();
            updateMonthlySummary();
        },
        error: function(error) {
            console.error('Error loading attendance:', error);
            showToast('Error loading attendance data', 'danger');
        }
    });
}

// Update calendar
function updateCalendar() {
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'];

    // Update header
    $('#currentMonthYear').text(`${monthNames[currentMonth - 1]} ${currentYear}`);

    // Create calendar grid
    const firstDay = new Date(currentYear, currentMonth - 1, 1);
    const lastDay = new Date(currentYear, currentMonth, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();

    let calendarHTML = '';

    // Empty cells for days before the first day of month
    for (let i = 0; i < startingDay; i++) {
        calendarHTML += '<div class="calendar-day"></div>';
    }

    // Days of the month
    const today = new Date();
    for (let day = 1; day <= daysInMonth; day++) {
        const currentDate = new Date(currentYear, currentMonth - 1, day);
        const dateStr = currentDate.toISOString().split('T')[0];

        // Check attendance status for this day
        const attendance = attendanceData.find(a => {
            const attDate = new Date(a.date).toISOString().split('T')[0];
            return attDate === dateStr;
        });

        let dayClass = 'calendar-day';
        let statusText = '';

        if (currentDate.getDay() === 0 || currentDate.getDay() === 6) {
            dayClass += ' weekend';
        }

        if (currentDate.toDateString() === today.toDateString()) {
            dayClass += ' today';
        }

        if (attendance) {
            switch(attendance.status) {
                case 'PRESENT':
                    dayClass += ' present';
                    statusText = '✓';
                    break;
                case 'ABSENT':
                    dayClass += ' absent';
                    statusText = '✗';
                    break;
                case 'LEAVE':
                    dayClass += ' leave';
                    statusText = 'L';
                    break;
                case 'HOLIDAY':
                    dayClass += ' holiday';
                    statusText = 'H';
                    break;
            }
        }

        calendarHTML += `
            <div class="${dayClass}" onclick="showDayDetails('${dateStr}')" 
                 title="${dateStr} ${attendance ? attendance.status : 'No record'}">
                ${day}<br>
                <small>${statusText}</small>
            </div>
        `;
    }

    $('#calendarDays').html(calendarHTML);
}

// Update attendance details table
function updateAttendanceDetails() {
    const tableBody = $('#attendanceDetails');
    tableBody.empty();

    if (!attendanceData || attendanceData.length === 0) {
        tableBody.html(`
            <tr>
                <td colspan="7" class="text-center text-muted">
                    No attendance records found for this month
                </td>
            </tr>
        `);
        return;
    }

    // Sort by date (newest first)
    attendanceData.sort((a, b) => new Date(b.date) - new Date(a.date));

    // Calculate stats
    let totalPresent = 0, totalAbsent = 0, totalLate = 0;
    const workingDays = attendanceData.filter(a => {
        const date = new Date(a.date);
        return date.getDay() !== 0 && date.getDay() !== 6; // Exclude weekends
    }).length;

    attendanceData.forEach(record => {
        const date = new Date(record.date);
        const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
        const dateStr = date.toLocaleDateString('en-IN');

        const clockIn = record.clockIn ? record.clockIn.substring(0, 5) : '--:--';
        const clockOut = record.clockOut ? record.clockOut.substring(0, 5) : '--:--';
        const totalHours = record.totalHours ? record.totalHours.toFixed(2) : '--';

        let statusBadge = '';
        switch(record.status) {
            case 'PRESENT':
                statusBadge = '<span class="badge bg-success">Present</span>';
                totalPresent++;
                break;
            case 'ABSENT':
                statusBadge = '<span class="badge bg-danger">Absent</span>';
                totalAbsent++;
                break;
            case 'HALF_DAY':
                statusBadge = '<span class="badge bg-warning">Half Day</span>';
                totalPresent += 0.5;
                break;
            case 'LEAVE':
                statusBadge = '<span class="badge bg-info">Leave</span>';
                break;
            case 'HOLIDAY':
                statusBadge = '<span class="badge bg-secondary">Holiday</span>';
                break;
        }

        if (record.lateMinutes > 0) totalLate++;

        const lateMinutes = record.lateMinutes || 0;
        const lateDisplay = lateMinutes > 0 ?
            `<span class="text-warning">${lateMinutes} min</span>` :
            '<span class="text-success">On Time</span>';

        const row = `
            <tr>
                <td>${dateStr}</td>
                <td>${dayName}</td>
                <td>${clockIn}</td>
                <td>${clockOut}</td>
                <td>${totalHours}</td>
                <td>${statusBadge}</td>
                <td>${lateDisplay}</td>
            </tr>
        `;

        tableBody.append(row);
    });

    // Update stats
    $('#totalWorkingDays').text(workingDays);
    $('#totalPresent').text(totalPresent);
    $('#totalAbsent').text(totalAbsent);
    $('#totalLate').text(totalLate);
}

// Update monthly summary
function updateMonthlySummary() {
    const summaryDiv = $('#monthlySummary');

    if (!attendanceData || attendanceData.length === 0) {
        summaryDiv.html('<p class="text-muted">No data available</p>');
        return;
    }

    let totalHours = 0;
    let lateDays = 0;
    let overtimeHours = 0;

    attendanceData.forEach(record => {
        if (record.totalHours) totalHours += record.totalHours;
        if (record.lateMinutes > 0) lateDays++;
        if (record.overtimeMinutes) overtimeHours += record.overtimeMinutes / 60;
    });

    const avgHours = attendanceData.length > 0 ?
        (totalHours / attendanceData.length).toFixed(2) : 0;

    summaryDiv.html(`
        <div class="mb-3">
            <small class="text-muted">Total Hours Worked</small>
            <h4>${totalHours.toFixed(2)} hours</h4>
        </div>
        <div class="mb-3">
            <small class="text-muted">Average Daily Hours</small>
            <h4>${avgHours} hours</h4>
        </div>
        <div class="mb-3">
            <small class="text-muted">Late Days</small>
            <h4 class="text-warning">${lateDays} days</h4>
        </div>
        <div>
            <small class="text-muted">Overtime</small>
            <h4 class="text-success">${overtimeHours.toFixed(2)} hours</h4>
        </div>
    `);
}

// Show day details
function showDayDetails(dateStr) {
    const attendance = attendanceData.find(a => {
        const attDate = new Date(a.date).toISOString().split('T')[0];
        return attDate === dateStr;
    });

    if (!attendance) {
        showToast(`No attendance record for ${dateStr}`, 'info');
        return;
    }

    const date = new Date(dateStr);
    const formattedDate = date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });

    let details = `
        <strong>${formattedDate}</strong><br><br>
        <strong>Status:</strong> ${attendance.status}<br>
    `;

    if (attendance.clockIn) {
        details += `<strong>Clock In:</strong> ${attendance.clockIn.substring(0, 5)}<br>`;
    }
    if (attendance.clockOut) {
        details += `<strong>Clock Out:</strong> ${attendance.clockOut.substring(0, 5)}<br>`;
    }
    if (attendance.totalHours) {
        details += `<strong>Total Hours:</strong> ${attendance.totalHours.toFixed(2)}<br>`;
    }
    if (attendance.lateMinutes > 0) {
        details += `<strong>Late Minutes:</strong> ${attendance.lateMinutes}<br>`;
    }
    if (attendance.overtimeMinutes > 0) {
        details += `<strong>Overtime:</strong> ${attendance.overtimeMinutes} minutes<br>`;
    }

    showToast(details, 'info');
}

// Navigation functions
function prevMonth() {
    currentMonth--;
    if (currentMonth < 1) {
        currentMonth = 12;
        currentYear--;
    }
    $('#monthSelect').val(currentMonth);
    $('#yearSelect').val(currentYear);
    loadAttendanceData();
}

function nextMonth() {
    currentMonth++;
    if (currentMonth > 12) {
        currentMonth = 1;
        currentYear++;
    }
    $('#monthSelect').val(currentMonth);
    $('#yearSelect').val(currentYear);
    loadAttendanceData();
}

// Submit regularization
function submitRegularization() {
    const userStr = localStorage.getItem('user');
    if (!userStr) {
        showToast('Please login first', 'warning');
        return;
    }

    const user = JSON.parse(userStr);
    const regDate = $('#regDate').val();
    const regType = $('#regType').val();
    const actualClockIn = $('#actualClockIn').val();
    const actualClockOut = $('#actualClockOut').val();
    const reason = $('#regReason').val();

    if (!regDate || !regType || !reason) {
        showToast('Please fill all required fields', 'warning');
        return;
    }

    const regularizationData = {
        user: { id: user.id },
        attendanceDate: regDate,
        requestType: regType,
        actualClockIn: actualClockIn || null,
        actualClockOut: actualClockOut || null,
        reason: reason
    };

    $.ajax({
        url: API_BASE_URL + '/regularization/apply',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(regularizationData),
        success: function(response) {
            if (response.success) {
                showToast(response.message, 'success');
                $('#regularizationModal').modal('hide');
                $('#regularizationForm')[0].reset();
            } else {
                showToast(response.message, 'danger');
            }
        },
        error: function(xhr, status, error) {
            showToast('Error submitting regularization: ' + error, 'danger');
        }
    });
}

// Logout function
function logout() {
    localStorage.clear();
    window.location.href = '/login';
}