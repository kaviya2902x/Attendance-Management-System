// Leave Management JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initializeLeavePage();
});

function initializeLeavePage() {
    // Initialize date pickers
    initializeDatePickers();

    // Setup form validation
    setupLeaveFormValidation();

    // Load leave balance
    loadLeaveBalance();

    // Load upcoming holidays
    loadUpcomingHolidays();
}

function initializeDatePickers() {
    const startDateInput = document.getElementById('startDate');
    const endDateInput = document.getElementById('endDate');
    const today = new Date().toISOString().split('T')[0];

    if (startDateInput) {
        // Minimum start date is today
        startDateInput.min = today;
        startDateInput.value = today;

        startDateInput.addEventListener('change', function() {
            if (endDateInput) {
                // End date cannot be before start date
                endDateInput.min = this.value;

                if (endDateInput.value && endDateInput.value < this.value) {
                    endDateInput.value = this.value;
                }

                // Calculate total days
                calculateTotalDays();
            }
        });
    }

    if (endDateInput) {
        endDateInput.min = today;
        endDateInput.value = today;

        endDateInput.addEventListener('change', function() {
            calculateTotalDays();
        });
    }
}

function setupLeaveFormValidation() {
    const form = document.getElementById('leaveForm');
    if (!form) return;

    const startDate = form.querySelector('#startDate');
    const endDate = form.querySelector('#endDate');
    const reason = form.querySelector('#reason');

    // Validate date range
    if (startDate && endDate) {
        endDate.addEventListener('change', function() {
            if (startDate.value && this.value < startDate.value) {
                showValidationError(this, 'End date cannot be before start date');
            } else {
                clearValidationError(this);
            }
        });
    }

    // Validate reason length
    if (reason) {
        reason.addEventListener('input', function() {
            if (this.value.length > 500) {
                showValidationError(this, 'Reason must be 500 characters or less');
            } else {
                clearValidationError(this);
            }
        });
    }
}

function showValidationError(input, message) {
    const formGroup = input.closest('.mb-3');
    const errorDiv = formGroup.querySelector('.invalid-feedback') ||
        document.createElement('div');

    if (!errorDiv.classList.contains('invalid-feedback')) {
        errorDiv.className = 'invalid-feedback';
        formGroup.appendChild(errorDiv);
    }

    input.classList.add('is-invalid');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
}

function clearValidationError(input) {
    const formGroup = input.closest('.mb-3');
    input.classList.remove('is-invalid');

    const errorDiv = formGroup.querySelector('.invalid-feedback');
    if (errorDiv) {
        errorDiv.style.display = 'none';
    }
}

async function loadLeaveBalance() {
    try {
        const response = await fetch('/api/leave/balance');
        const data = await response.json();

        if (data.success) {
            updateLeaveBalanceUI(data.data);
        }
    } catch (error) {
        console.error('Error loading leave balance:', error);
    }
}

function updateLeaveBalanceUI(balance) {
    const balanceElement = document.getElementById('leaveBalance');
    if (balanceElement && balance.total !== undefined) {
        balanceElement.textContent = `${balance.available} / ${balance.total}`;
    }

    // Update leave type breakdown if available
    if (balance.breakdown) {
        const breakdownContainer = document.getElementById('leaveBreakdown');
        if (breakdownContainer) {
            let html = '';
            balance.breakdown.forEach(item => {
                html += `
                    <div class="d-flex justify-content-between mb-1">
                        <span>${item.type}</span>
                        <span>${item.used} / ${item.total}</span>
                    </div>
                `;
            });
            breakdownContainer.innerHTML = html;
        }
    }
}

async function loadUpcomingHolidays() {
    try {
        const response = await fetch('/api/holidays/upcoming');
        const data = await response.json();

        if (data.success) {
            updateHolidaysUI(data.data);
        }
    } catch (error) {
        console.error('Error loading upcoming holidays:', error);
    }
}

function updateHolidaysUI(holidays) {
    const holidaysContainer = document.getElementById('upcomingHolidays');
    if (!holidaysContainer) return;

    if (holidays && holidays.length > 0) {
        let html = '';
        holidays.slice(0, 5).forEach(holiday => {
            const date = new Date(holiday.date);
            html += `
                <div class="list-group-item">
                    <div class="d-flex w-100 justify-content-between">
                        <h6 class="mb-1">${holiday.name}</h6>
                        <small>${date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</small>
                    </div>
                    <small class="text-muted">${holiday.description || ''}</small>
                </div>
            `;
        });
        holidaysContainer.innerHTML = html;
    } else {
        holidaysContainer.innerHTML = `
            <div class="text-center text-muted py-3">
                <i class="bi bi-calendar-event display-4 mb-2"></i>
                <p class="mb-0">No upcoming holidays</p>
            </div>
        `;
    }
}

function calculateTotalDays() {
    const startDateInput = document.getElementById('startDate');
    const endDateInput = document.getElementById('endDate');
    const totalDaysElement = document.getElementById('totalDays');

    if (!startDateInput || !endDateInput || !totalDaysElement) return;

    const startDate = new Date(startDateInput.value);
    const endDate = new Date(endDateInput.value);

    if (startDate && endDate && endDate >= startDate) {
        // Calculate difference in days
        const timeDiff = endDate.getTime() - startDate.getTime();
        const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1; // Inclusive of both dates

        totalDaysElement.textContent = daysDiff;

        // Check against leave balance
        checkLeaveBalance(daysDiff);
    } else {
        totalDaysElement.textContent = '0';
    }
}

async function checkLeaveBalance(requestedDays) {
    try {
        const response = await fetch('/api/leave/balance');
        const data = await response.json();

        if (data.success && data.data.available !== undefined) {
            const available = data.data.available;

            if (requestedDays > available) {
                showToast(`Warning: You only have ${available} days leave balance remaining`, 'warning');
            }
        }
    } catch (error) {
        console.error('Error checking leave balance:', error);
    }
}

async function submitLeaveApplication() {
    const form = document.getElementById('leaveForm');
    const leaveType = form.querySelector('#leaveType').value;
    const startDate = form.querySelector('#startDate').value;
    const endDate = form.querySelector('#endDate').value;
    const reason = form.querySelector('#reason').value;
    const attachment = form.querySelector('#attachment').files[0];

    // Validate form
    if (!leaveType || !startDate || !endDate || !reason.trim()) {
        showToast('Please fill all required fields', 'warning');
        return;
    }

    if (reason.trim().length > 500) {
        showToast('Reason must be 500 characters or less', 'warning');
        return;
    }

    const start = new Date(startDate);
    const end = new Date(endDate);

    if (end < start) {
        showToast('End date cannot be before start date', 'warning');
        return;
    }

    // Check for overlapping holidays
    try {
        const holidaysResponse = await fetch(`/api/holidays/range?start=${startDate}&end=${endDate}`);
        const holidaysData = await holidaysResponse.json();

        if (holidaysData.success && holidaysData.data.length > 0) {
            if (!confirm('Your leave period includes company holidays. Do you want to proceed?')) {
                return;
            }
        }
    } catch (error) {
        console.error('Error checking holidays:', error);
    }

    // Prepare form data
    const formData = new FormData();
    formData.append('leaveType', leaveType);
    formData.append('startDate', startDate);
    formData.append('endDate', endDate);
    formData.append('reason', reason.trim());

    if (attachment) {
        formData.append('attachment', attachment);
    }

    try {
        const response = await fetch('/leave/apply', {
            method: 'POST',
            body: formData
        });

        if (response.redirected) {
            // Handle redirect for Thymeleaf form submission
            window.location.href = response.url;
        } else {
            const data = await response.json();

            if (data.success) {
                showToast('Leave application submitted successfully', 'success');
                form.reset();
                setTimeout(() => {
                    window.location.href = '/leave/history';
                }, 1500);
            } else {
                showToast('Error: ' + data.message, 'error');
            }
        }
    } catch (error) {
        console.error('Error submitting leave application:', error);
        showToast('Network error. Please try again.', 'error');
    }
}

async function cancelLeave(leaveId) {
    if (!confirm('Are you sure you want to cancel this leave application?')) {
        return;
    }

    try {
        const response = await fetch(`/leave/${leaveId}/cancel`, {
            method: 'POST'
        });

        const data = await response.json();

        if (data.success) {
            showToast('Leave application cancelled successfully', 'success');
            setTimeout(() => {
                location.reload();
            }, 1000);
        } else {
            showToast('Error: ' + data.message, 'error');
        }
    } catch (error) {
        console.error('Error cancelling leave:', error);
        showToast('Network error. Please try again.', 'error');
    }
}

async function uploadAttachment(file) {
    if (!file) return null;

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
        showToast('File size must be less than 5MB', 'error');
        return null;
    }

    // Check file type
    const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf', 'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];

    if (!allowedTypes.includes(file.type)) {
        showToast('Only JPG, PNG, PDF, and DOC files are allowed', 'error');
        return null;
    }

    // In a real application, you would upload to a server
    // For now, return a fake URL
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(`/uploads/${Date.now()}_${file.name}`);
        }, 1000);
    });
}

function showLeaveDetails(leaveId) {
    fetch(`/api/leave/${leaveId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const leave = data.data;

                // Populate modal
                document.getElementById('detailLeaveType').textContent = leave.leaveType;
                document.getElementById('detailDates').textContent =
                    `${new Date(leave.startDate).toLocaleDateString()} - ${new Date(leave.endDate).toLocaleDateString()}`;
                document.getElementById('detailTotalDays').textContent = leave.totalDays;
                document.getElementById('detailReason').textContent = leave.reason;
                document.getElementById('detailStatus').textContent = leave.status;
                document.getElementById('detailAppliedDate').textContent =
                    new Date(leave.appliedDate).toLocaleDateString();

                if (leave.approvedBy) {
                    document.getElementById('detailApprovedBy').textContent = leave.approvedBy;
                    document.getElementById('detailApprovalDate').textContent =
                        new Date(leave.approvalDate).toLocaleDateString();
                }

                if (leave.rejectionReason) {
                    document.getElementById('detailRejectionReason').textContent = leave.rejectionReason;
                    document.getElementById('rejectionReasonSection').style.display = 'block';
                } else {
                    document.getElementById('rejectionReasonSection').style.display = 'none';
                }

                if (leave.attachmentUrl) {
                    document.getElementById('detailAttachment').href = leave.attachmentUrl;
                    document.getElementById('attachmentSection').style.display = 'block';
                } else {
                    document.getElementById('attachmentSection').style.display = 'none';
                }

                // Show modal
                const modal = new bootstrap.Modal(document.getElementById('leaveDetailsModal'));
                modal.show();
            }
        })
        .catch(error => {
            console.error('Error loading leave details:', error);
            showToast('Error loading leave details', 'error');
        });
}

function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toastContainer');

    if (!toastContainer) {
        const container = document.createElement('div');
        container.id = 'toastContainer';
        container.className = 'toast-container position-fixed top-0 end-0 p-3';
        container.style.zIndex = '9999';
        document.body.appendChild(container);
    }

    const toastId = 'toast-' + Date.now();
    const toastHtml = `
        <div id="${toastId}" class="toast align-items-center text-bg-${type} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">
                    <i class="bi ${type === 'success' ? 'bi-check-circle' :
        type === 'error' ? 'bi-x-circle' :
            type === 'warning' ? 'bi-exclamation-triangle' : 'bi-info-circle'} me-2"></i>
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;

    document.getElementById('toastContainer').innerHTML = toastHtml;

    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, {
        autohide: true,
        delay: 3000
    });
    toast.show();

    toastElement.addEventListener('hidden.bs.toast', function() {
        toastElement.remove();
    });
}

// Export leave history
function exportLeaveHistory(format) {
    const startDate = document.getElementById('filterStartDate')?.value;
    const endDate = document.getElementById('filterEndDate')?.value;
    const status = document.getElementById('filterStatus')?.value;

    let url = `/api/leave/export/${format}`;
    const params = new URLSearchParams();

    if (startDate) params.append('startDate', startDate);
    if (endDate) params.append('endDate', endDate);
    if (status) params.append('status', status);

    if (params.toString()) {
        url += '?' + params.toString();
    }

    window.open(url, '_blank');
}

// Filter leave history
function filterLeaveHistory() {
    const startDate = document.getElementById('filterStartDate')?.value;
    const endDate = document.getElementById('filterEndDate')?.value;
    const status = document.getElementById('filterStatus')?.value;
    const leaveType = document.getElementById('filterLeaveType')?.value;

    // Apply filters to table
    const table = document.getElementById('leaveHistoryTable');
    if (!table) return;

    const rows = table.querySelectorAll('tbody tr');

    rows.forEach(row => {
        let show = true;

        if (startDate) {
            const rowDate = new Date(row.cells[1].textContent);
            if (rowDate < new Date(startDate)) {
                show = false;
            }
        }

        if (endDate && show) {
            const rowDate = new Date(row.cells[2].textContent);
            if (rowDate > new Date(endDate)) {
                show = false;
            }
        }

        if (status && show && status !== 'ALL') {
            const rowStatus = row.cells[4].textContent.trim();
            if (rowStatus !== status) {
                show = false;
            }
        }

        if (leaveType && show && leaveType !== 'ALL') {
            const rowType = row.cells[0].textContent.trim();
            if (rowType !== leaveType) {
                show = false;
            }
        }

        row.style.display = show ? '' : 'none';
    });
}