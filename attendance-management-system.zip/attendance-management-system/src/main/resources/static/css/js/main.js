// Admin Dashboard JavaScript

$(document).ready(function() {
    checkAdminAuth();
    loadAdminDashboard();
    setupAdminEventListeners();
});

// Check admin authentication
function checkAdminAuth() {
    const userStr = localStorage.getItem('user');
    if (!userStr) {
        window.location.href = '/login';
        return;
    }

    try {
        const user = JSON.parse(userStr);
        if (user.role !== 'ADMIN' && user.role !== 'HR') {
            window.location.href = '/employee/dashboard';
        }
    } catch (error) {
        console.error('Error checking admin auth:', error);
        logout();
    }
}

// Load admin dashboard data
function loadAdminDashboard() {
    loadDashboardStats();
    loadRecentActivities();
    loadAttendanceSummary();
    loadEmployeeStats();
    loadPendingApprovals();
}

// Load dashboard statistics
function loadDashboardStats() {
    $.ajax({
        url: `${API_BASE_URL}/admin/dashboard/stats`,
        method: 'GET',
        success: function(stats) {
            updateDashboardStats(stats);
        },
        error: function(error) {
            console.error('Error loading dashboard stats:', error);
        }
    });
}

// Update dashboard statistics
function updateDashboardStats(stats) {
    if (!stats) return;

    // Update stat cards
    $('#totalEmployees').text(stats.totalEmployees || 0);
    $('#presentToday').text(stats.presentToday || 0);
    $('#absentToday').text(stats.absentToday || 0);
    $('#onLeaveToday').text(stats.onLeaveToday || 0);
    $('#lateToday').text(stats.lateToday || 0);
    $('#overtimeToday').text(stats.overtimeToday || 0);

    // Update charts if they exist
    updateAttendanceChart(stats);
}

// Load recent activities
function loadRecentActivities() {
    $.ajax({
        url: `${API_BASE_URL}/notifications/recent`,
        method: 'GET',
        success: function(activities) {
            updateRecentActivities(activities);
        },
        error: function(error) {
            console.error('Error loading recent activities:', error);
        }
    });
}

// Update recent activities
function updateRecentActivities(activities) {
    const container = $('#recentActivities');
    if (!container.length || !activities) return;

    container.empty();

    if (activities.length === 0) {
        container.html('<p class="text-muted text-center">No recent activities</p>');
        return;
    }

    activities.slice(0, 10).forEach(activity => {
        const timeAgo = getTimeAgo(activity.createdAt);
        const activityItem = `
            <div class="activity-item mb-3">
                <div class="d-flex">
                    <div class="activity-icon me-3">
                        <i class="fas ${getActivityIcon(activity.type)} ${getActivityColor(activity.type)}"></i>
                    </div>
                    <div class="flex-grow-1">
                        <h6 class="mb-1">${activity.title}</h6>
                        <p class="mb-0 text-muted small">${activity.message}</p>
                        <small class="text-muted">${timeAgo}</small>
                    </div>
                </div>
            </div>
        `;
        container.append(activityItem);
    });
}

// Get activity icon
function getActivityIcon(type) {
    switch(type) {
        case 'ATTENDANCE': return 'fa-clock';
        case 'LEAVE': return 'fa-calendar-alt';
        case 'REGULARIZATION': return 'fa-edit';
        case 'USER': return 'fa-user';
        default: return 'fa-bell';
    }
}

// Get activity color
function getActivityColor(type) {
    switch(type) {
        case 'ATTENDANCE': return 'text-primary';
        case 'LEAVE': return 'text-success';
        case 'REGULARIZATION': return 'text-warning';
        case 'USER': return 'text-info';
        default: return 'text-secondary';
    }
}

// Load attendance summary
function loadAttendanceSummary() {
    const today = new Date();

    $.ajax({
        url: `${API_BASE_URL}/attendance/summary/today`,
        method: 'GET',
        success: function(summary) {
            updateAttendanceSummary(summary);
        },
        error: function(error) {
            console.error('Error loading attendance summary:', error);
        }
    });
}

// Update attendance summary
function updateAttendanceSummary(summary) {
    if (!summary) return;

    $('#totalAttendance').text(summary.total || 0);
    $('#presentCount').text(summary.present || 0);
    $('#absentCount').text(summary.absent || 0);

    // Calculate percentages
    const total = summary.total || 1;
    const presentPercent = Math.round((summary.present || 0) / total * 100);
    const absentPercent = Math.round((summary.absent || 0) / total * 100);

    // Update progress bars
    $('#presentProgress').css('width', presentPercent + '%').text(presentPercent + '%');
    $('#absentProgress').css('width', absentPercent + '%').text(absentPercent + '%');
}

// Load employee statistics
function loadEmployeeStats() {
    $.ajax({
        url: `${API_BASE_URL}/users/stats`,
        method: 'GET',
        success: function(stats) {
            updateEmployeeStats(stats);
        },
        error: function(error) {
            console.error('Error loading employee stats:', error);
        }
    });
}

// Update employee statistics
function updateEmployeeStats(stats) {
    if (!stats) return;

    $('#totalUsers').text(stats.total || 0);
    $('#activeUsers').text(stats.active || 0);
    $('#employeeCount').text(stats.employees || 0);
    $('#managerCount').text(stats.managers || 0);
    $('#hrCount').text(stats.hr || 0);
    $('#adminCount').text(stats.admins || 0);

    // Update department distribution
    updateDepartmentChart(stats.departments);
}

// Load pending approvals
function loadPendingApprovals() {
    // Load pending leaves
    $.ajax({
        url: `${API_BASE_URL}/leaves/pending`,
        method: 'GET',
        success: function(leaves) {
            updatePendingLeaves(leaves);
        },
        error: function(error) {
            console.error('Error loading pending leaves:', error);
        }
    });

    // Load pending regularizations
    $.ajax({
        url: `${API_BASE_URL}/regularization/pending`,
        method: 'GET',
        success: function(regularizations) {
            updatePendingRegularizations(regularizations);
        },
        error: function(error) {
            console.error('Error loading pending regularizations:', error);
        }
    });
}

// Update pending leaves
function updatePendingLeaves(leaves) {
    const container = $('#pendingLeaves');
    if (!container.length) return;

    container.empty();

    if (!leaves || leaves.length === 0) {
        container.html('<p class="text-muted text-center">No pending leaves</p>');
        return;
    }

    leaves.slice(0, 5).forEach(leave => {
        const leaveItem = `
            <div class="pending-item mb-2 p-2 border rounded">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <strong>${leave.user?.firstName} ${leave.user?.lastName}</strong>
                        <small class="d-block text-muted">${leave.leaveType} - ${leave.totalDays} days</small>
                        <small class="text-muted">${formatDate(leave.startDate)} to ${formatDate(leave.endDate)}</small>
                    </div>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-success btn-sm" onclick="approveLeave(${leave.id})">
                            <i class="fas fa-check"></i>
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="rejectLeave(${leave.id})">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
        container.append(leaveItem);
    });
}

// Update pending regularizations
function updatePendingRegularizations(regularizations) {
    const container = $('#pendingRegularizations');
    if (!container.length) return;

    container.empty();

    if (!regularizations || regularizations.length === 0) {
        container.html('<p class="text-muted text-center">No pending regularizations</p>');
        return;
    }

    regularizations.slice(0, 5).forEach(reg => {
        const regItem = `
            <div class="pending-item mb-2 p-2 border rounded">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <strong>${reg.user?.firstName} ${reg.user?.lastName}</strong>
                        <small class="d-block text-muted">${reg.requestType}</small>
                        <small class="text-muted">${formatDate(reg.attendanceDate)}</small>
                    </div>
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-success btn-sm" onclick="approveRegularization(${reg.id})">
                            <i class="fas fa-check"></i>
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="rejectRegularization(${reg.id})">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
        container.append(regItem);
    });
}

// Setup admin event listeners
function setupAdminEventListeners() {
    // Date range picker
    $('#dateRange').change(function() {
        loadAttendanceByDateRange();
    });

    // Department filter
    $('#departmentFilter').change(function() {
        loadDepartmentAttendance();
    });

    // Export buttons
    $('.export-btn').click(function() {
        const type = $(this).data('type');
        exportReport(type);
    });

    // Refresh button
    $('#refreshDashboard').click(function() {
        loadAdminDashboard();
        showToast('Dashboard refreshed', 'success');
    });
}

// Load attendance by date range
function loadAttendanceByDateRange() {
    const range = $('#dateRange').val();
    let startDate, endDate;

    const today = new Date();

    switch(range) {
        case 'today':
            startDate = endDate = formatDate(today);
            break;
        case 'week':
            startDate = formatDate(new Date(today.getFullYear(), today.getMonth(), today.getDate() - 7));
            endDate = formatDate(today);
            break;
        case 'month':
            startDate = formatDate(new Date(today.getFullYear(), today.getMonth() - 1, today.getDate()));
            endDate = formatDate(today);
            break;
        default:
            return;
    }

    $.ajax({
        url: `${API_BASE_URL}/admin/attendance/range`,
        method: 'GET',
        data: { startDate, endDate },
        success: function(data) {
            updateAttendanceTable(data);
        },
        error: function(error) {
            console.error('Error loading attendance by range:', error);
        }
    });
}

// Update attendance table
function updateAttendanceTable(data) {
    const tableBody = $('#attendanceTable tbody');
    if (!tableBody.length || !data) return;

    tableBody.empty();

    if (data.length === 0) {
        tableBody.html('<tr><td colspan="7" class="text-center text-muted">No attendance records found</td></tr>');
        return;
    }

    data.forEach(record => {
        const row = `
            <tr>
                <td>${record.employeeId || ''}</td>
                <td>${record.firstName || ''} ${record.lastName || ''}</td>
                <td>${formatDate(record.date)}</td>
                <td>${formatTime(record.clockIn)}</td>
                <td>${formatTime(record.clockOut)}</td>
                <td>${record.totalHours ? record.totalHours.toFixed(2) : '--'}</td>
                <td>
                    ${getStatusBadge(record.status)}
                    ${record.lateMinutes > 0 ? '<span class="badge bg-warning ms-1">Late</span>' : ''}
                </td>
            </tr>
        `;
        tableBody.append(row);
    });
}

// Get status badge
function getStatusBadge(status) {
    switch(status) {
        case 'PRESENT': return '<span class="badge bg-success">Present</span>';
        case 'ABSENT': return '<span class="badge bg-danger">Absent</span>';
        case 'HALF_DAY': return '<span class="badge bg-warning">Half Day</span>';
        case 'LEAVE': return '<span class="badge bg-info">Leave</span>';
        default: return '<span class="badge bg-secondary">' + status + '</span>';
    }
}

// Load department attendance
function loadDepartmentAttendance() {
    const department = $('#departmentFilter').val();
    if (!department) return;

    $.ajax({
        url: `${API_BASE_URL}/admin/attendance/department/${department}`,
        method: 'GET',
        success: function(data) {
            updateDepartmentAttendance(data);
        },
        error: function(error) {
            console.error('Error loading department attendance:', error);
        }
    });
}

// Update department attendance
function updateDepartmentAttendance(data) {
    // Implement based on your needs
    console.log('Department attendance:', data);
}

// Export report
function exportReport(type) {
    const params = {
        type: type,
        startDate: $('#exportStartDate').val(),
        endDate: $('#exportEndDate').val(),
        department: $('#exportDepartment').val()
    };

    $.ajax({
        url: `${API_BASE_URL}/admin/reports/export`,
        method: 'POST',
        data: params,
        xhrFields: {
            responseType: 'blob'
        },
        success: function(blob) {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `report_${type}_${new Date().getTime()}.${type === 'pdf' ? 'pdf' : 'xlsx'}`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);

            showToast('Report exported successfully', 'success');
        },
        error: function(error) {
            console.error('Error exporting report:', error);
            showToast('Error exporting report', 'error');
        }
    });
}

// Approve leave
function approveLeave(leaveId) {
    if (!confirm('Approve this leave application?')) return;

    const user = JSON.parse(localStorage.getItem('user'));

    $.ajax({
        url: `${API_BASE_URL}/leaves/approve/${leaveId}`,
        method: 'POST',
        data: { approverId: user.id },
        success: function(response) {
            if (response.success) {
                showToast('Leave approved successfully', 'success');
                loadPendingApprovals();
                loadAdminDashboard();
            } else {
                showToast(response.message, 'error');
            }
        },
        error: function(error) {
            console.error('Error approving leave:', error);
            showToast('Error approving leave', 'error');
        }
    });
}

// Reject leave
function rejectLeave(leaveId) {
    const reason = prompt('Enter rejection reason:');
    if (!reason) return;

    const user = JSON.parse(localStorage.getItem('user'));

    $.ajax({
        url: `${API_BASE_URL}/leaves/reject/${leaveId}`,
        method: 'POST',
        data: { approverId: user.id, reason: reason },
        success: function(response) {
            if (response.success) {
                showToast('Leave rejected', 'success');
                loadPendingApprovals();
                loadAdminDashboard();
            } else {
                showToast(response.message, 'error');
            }
        },
        error: function(error) {
            console.error('Error rejecting leave:', error);
            showToast('Error rejecting leave', 'error');
        }
    });
}

// Approve regularization
function approveRegularization(requestId) {
    if (!confirm('Approve this regularization request?')) return;

    const user = JSON.parse(localStorage.getItem('user'));

    $.ajax({
        url: `${API_BASE_URL}/regularization/approve/${requestId}`,
        method: 'POST',
        data: { approverId: user.id },
        success: function(response) {
            if (response.success) {
                showToast('Regularization approved', 'success');
                loadPendingApprovals();
                loadAdminDashboard();
            } else {
                showToast(response.message, 'error');
            }
        },
        error: function(error) {
            console.error('Error approving regularization:', error);
            showToast('Error approving regularization', 'error');
        }
    });
}

// Reject regularization
function rejectRegularization(requestId) {
    const reason = prompt('Enter rejection reason:');
    if (!reason) return;

    const user = JSON.parse(localStorage.getItem('user'));

    $.ajax({
        url: `${API_BASE_URL}/regularization/reject/${requestId}`,
        method: 'POST',
        data: { approverId: user.id, reason: reason },
        success: function(response) {
            if (response.success) {
                showToast('Regularization rejected', 'success');
                loadPendingApprovals();
                loadAdminDashboard();
            } else {
                showToast(response.message, 'error');
            }
        },
        error: function(error) {
            console.error('Error rejecting regularization:', error);
            showToast('Error rejecting regularization', 'error');
        }
    });
}

// Update attendance chart
function updateAttendanceChart(stats) {
    const ctx = document.getElementById('attendanceChart');
    if (!ctx) return;

    // Destroy existing chart
    if (window.attendanceChart instanceof Chart) {
        window.attendanceChart.destroy();
    }

    const labels = ['Present', 'Absent', 'Late', 'On Leave'];
    const data = [
        stats.presentToday || 0,
        stats.absentToday || 0,
        stats.lateToday || 0,
        stats.onLeaveToday || 0
    ];

    window.attendanceChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: [
                    '#28a745',
                    '#dc3545',
                    '#ffc107',
                    '#17a2b8'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Update department chart
function updateDepartmentChart(departments) {
    const ctx = document.getElementById('departmentChart');
    if (!ctx || !departments) return;

    // Destroy existing chart
    if (window.departmentChart instanceof Chart) {
        window.departmentChart.destroy();
    }

    const labels = Object.keys(departments);
    const data = Object.values(departments);

    window.departmentChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Employees',
                data: data,
                backgroundColor: '#007bff',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
}

// Initialize charts on page load
function initializeCharts() {
    // This will be called after data loads
    console.log('Charts initialized');
}