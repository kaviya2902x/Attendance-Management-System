// Admin JavaScript

document.addEventListener('DOMContentLoaded', function() {
    initializeAdminPage();
});

function initializeAdminPage() {
    // Initialize all admin components
    initializeUserManagement();
    initializeAttendanceReports();
    initializeLeaveApprovals();
    initializeHolidayManagement();
    initializeShiftManagement();

    // Load dashboard stats
    loadDashboardStats();

    // Setup event listeners
    setupAdminEventListeners();

    // Initialize charts if needed
    initializeCharts();
}

function initializeUserManagement() {
    // User search functionality
    const userSearch = document.getElementById('userSearch');
    if (userSearch) {
        userSearch.addEventListener('input', debounce(searchUsers, 300));
    }

    // User table actions
    const userTable = document.getElementById('userTable');
    if (userTable) {
        userTable.addEventListener('click', handleUserTableClick);
    }
}

function initializeAttendanceReports() {
    // Date range picker for reports
    const dateRangePicker = document.getElementById('reportDateRange');
    if (dateRangePicker) {
        // Initialize date range picker
        const today = new Date();
        const startDate = new Date(today.getFullYear(), today.getMonth(), 1);
        const endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);

        dateRangePicker.value =
            `${startDate.toISOString().split('T')[0]} to ${endDate.toISOString().split('T')[0]}`;

        dateRangePicker.addEventListener('change', function() {
            loadAttendanceReport();
        });
    }

    // Department filter
    const departmentFilter = document.getElementById('departmentFilter');
    if (departmentFilter) {
        departmentFilter.addEventListener('change', function() {
            loadAttendanceReport();
        });
    }
}

function initializeLeaveApprovals() {
    // Leave approval buttons
    const leaveTable = document.getElementById('leaveTable');
    if (leaveTable) {
        leaveTable.addEventListener('click', handleLeaveTableClick);
    }

    // Bulk actions
    const bulkApproveBtn = document.getElementById('bulkApproveBtn');
    const bulkRejectBtn = document.getElementById('bulkRejectBtn');

    if (bulkApproveBtn) {
        bulkApproveBtn.addEventListener('click', bulkApproveLeaves);
    }

    if (bulkRejectBtn) {
        bulkRejectBtn.addEventListener('click', bulkRejectLeaves);
    }
}

function initializeHolidayManagement() {
    // Holiday form
    const holidayForm = document.getElementById('holidayForm');
    if (holidayForm) {
        holidayForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveHoliday();
        });
    }

    // Holiday table actions
    const holidayTable = document.getElementById('holidayTable');
    if (holidayTable) {
        holidayTable.addEventListener('click', handleHolidayTableClick);
    }
}

function initializeShiftManagement() {
    // Shift form
    const shiftForm = document.getElementById('shiftForm');
    if (shiftForm) {
        shiftForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveShift();
        });
    }

    // Shift assignment
    const assignShiftForm = document.getElementById('assignShiftForm');
    if (assignShiftForm) {
        assignShiftForm.addEventListener('submit', function(e) {
            e.preventDefault();
            assignShift();
        });
    }
}

function loadDashboardStats() {
    fetch('/api/admin/stats')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateDashboardStats(data.data);
            }
        })
        .catch(error => {
            console.error('Error loading dashboard stats:', error);
        });
}

function updateDashboardStats(stats) {
    // Update total users
    const totalUsersElement = document.getElementById('totalUsers');
    if (totalUsersElement && stats.totalUsers !== undefined) {
        totalUsersElement.textContent = stats.totalUsers;
    }

    // Update today's attendance
    const todayAttendanceElement = document.getElementById('todayAttendance');
    if (todayAttendanceElement && stats.todayAttendance !== undefined) {
        todayAttendanceElement.textContent = stats.todayAttendance;
    }

    // Update pending leaves
    const pendingLeavesElement = document.getElementById('pendingLeaves');
    if (pendingLeavesElement && stats.pendingLeaves !== undefined) {
        pendingLeavesElement.textContent = stats.pendingLeaves;
    }

    // Update active employees
    const activeEmployeesElement = document.getElementById('activeEmployees');
    if (activeEmployeesElement && stats.activeEmployees !== undefined) {
        activeEmployeesElement.textContent = stats.activeEmployees;
    }

    // Update this month's attendance rate
    const attendanceRateElement = document.getElementById('attendanceRate');
    if (attendanceRateElement && stats.attendanceRate !== undefined) {
        attendanceRateElement.textContent = `${stats.attendanceRate}%`;
    }
}

async function searchUsers(searchTerm) {
    try {
        const response = await fetch(`/api/admin/users/search?q=${encodeURIComponent(searchTerm)}`);
        const data = await response.json();

        if (data.success) {
            updateUserTable(data.data);
        }
    } catch (error) {
        console.error('Error searching users:', error);
    }
}

function updateUserTable(users) {
    const userTableBody = document.getElementById('userTableBody');
    if (!userTableBody) return;

    if (users && users.length > 0) {
        let html = '';

        users.forEach(user => {
            html += `
                <tr>
                    <td>
                        <div class="d-flex align-items-center">
                            <img src="/images/avatar.png" alt="Avatar" class="rounded-circle me-2" width="32" height="32">
                            <div>
                                <strong>${user.firstName} ${user.lastName}</strong>
                                <br>
                                <small class="text-muted">${user.employeeId}</small>
                            </div>
                        </div>
                    </td>
                    <td>${user.email}</td>
                    <td>${user.department}</td>
                    <td>${user.position}</td>
                    <td>
                        <span class="badge ${user.status === 'ACTIVE' ? 'bg-success' : 'bg-danger'}">
                            ${user.status}
                        </span>
                    </td>
                    <td>
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-primary" onclick="editUser(${user.id})">
                                <i class="bi bi-pencil"></i>
                            </button>
                            <button class="btn btn-outline-info" onclick="viewUser(${user.id})">
                                <i class="bi bi-eye"></i>
                            </button>
                            <button class="btn btn-outline-danger" onclick="deleteUser(${user.id})">
                                <i class="bi bi-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        });

        userTableBody.innerHTML = html;
    } else {
        userTableBody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center text-muted py-4">
                    <i class="bi bi-search display-4 mb-3"></i>
                    <p class="mb-0">No users found</p>
                </td>
            </tr>
        `;
    }
}

async function loadAttendanceReport() {
    const dateRange = document.getElementById('reportDateRange')?.value;
    const department = document.getElementById('departmentFilter')?.value;

    try {
        let url = '/api/admin/reports/attendance';
        const params = new URLSearchParams();

        if (dateRange) {
            const [startDate, endDate] = dateRange.split(' to ');
            params.append('startDate', startDate);
            params.append('endDate', endDate);
        }

        if (department) {
            params.append('department', department);
        }

        if (params.toString()) {
            url += '?' + params.toString();
        }

        const response = await fetch(url);
        const data = await response.json();

        if (data.success) {
            updateAttendanceReport(data.data);
        }
    } catch (error) {
        console.error('Error loading attendance report:', error);
    }
}

function updateAttendanceReport(reportData) {
    // Update report table
    const reportTableBody = document.getElementById('reportTableBody');
    if (reportTableBody && reportData.attendances) {
        let html = '';

        reportData.attendances.forEach(attendance => {
            html += `
                <tr>
                    <td>${attendance.employeeName}</td>
                    <td>${attendance.employeeId}</td>
                    <td>${new Date(attendance.attendanceDate).toLocaleDateString()}</td>
                    <td>${attendance.clockInTime || '--:--'}</td>
                    <td>${attendance.clockOutTime || '--:--'}</td>
                    <td>${attendance.totalHours ? attendance.totalHours.toFixed(2) : '--'}</td>
                    <td>
                        <span class="badge ${attendance.status === 'PRESENT' ? 'bg-success' :
                attendance.status === 'ABSENT' ? 'bg-danger' :
                    attendance.status === 'HALF_DAY' ? 'bg-warning' : 'bg-info'}">
                            ${attendance.status}
                        </span>
                    </td>
                </tr>
            `;
        });

        reportTableBody.innerHTML = html;
    }

    // Update summary statistics
    if (reportData.summary) {
        const summary = reportData.summary;

        const presentCount = document.getElementById('presentCount');
        const absentCount = document.getElementById('absentCount');
        const averageHours = document.getElementById('averageHours');
        const totalLate = document.getElementById('totalLate');

        if (presentCount) presentCount.textContent = summary.presentDays || 0;
        if (absentCount) absentCount.textContent = summary.absentDays || 0;
        if (averageHours) averageHours.textContent = summary.averageHours ? summary.averageHours.toFixed(2) : '0.00';
        if (totalLate) totalLate.textContent = summary.totalLateMinutes || 0;
    }
}

async function approveLeave(leaveId) {
    if (!confirm('Approve this leave request?')) return;

    try {
        const response = await fetch(`/leave/${leaveId}/approve`, {
            method: 'POST'
        });

        const data = await response.json();

        if (data.success) {
            showToast('Leave approved successfully', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast('Error: ' + data.message, 'error');
        }
    } catch (error) {
        console.error('Error approving leave:', error);
        showToast('Network error', 'error');
    }
}

async function rejectLeave(leaveId, reason) {
    if (!reason) {
        const rejectReason = prompt('Please enter rejection reason:');
        if (!rejectReason) return;
        reason = rejectReason;
    }

    try {
        const response = await fetch(`/leave/${leaveId}/reject?reason=${encodeURIComponent(reason)}`, {
            method: 'POST'
        });

        const data = await response.json();

        if (data.success) {
            showToast('Leave rejected successfully', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast('Error: ' + data.message, 'error');
        }
    } catch (error) {
        console.error('Error rejecting leave:', error);
        showToast('Network error', 'error');
    }
}

function handleLeaveTableClick(event) {
    const target = event.target;
    const row = target.closest('tr');

    if (!row) return;

    const leaveId = row.dataset.leaveId;

    if (target.classList.contains('approve-btn')) {
        approveLeave(leaveId);
    } else if (target.classList.contains('reject-btn')) {
        rejectLeave(leaveId);
    } else if (target.classList.contains('view-btn')) {
        viewLeaveDetails(leaveId);
    }
}

async function saveHoliday() {
    const form = document.getElementById('holidayForm');
    const formData = new FormData(form);

    try {
        const response = await fetch('/api/holidays', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: formData.get('name'),
                date: formData.get('date'),
                description: formData.get('description'),
                type: formData.get('type'),
                recurring: formData.get('recurring') === 'on'
            })
        });

        const data = await response.json();

        if (data.success) {
            showToast('Holiday saved successfully', 'success');
            form.reset();
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast('Error: ' + data.message, 'error');
        }
    } catch (error) {
        console.error('Error saving holiday:', error);
        showToast('Network error', 'error');
    }
}

function handleHolidayTableClick(event) {
    const target = event.target;
    const row = target.closest('tr');

    if (!row) return;

    const holidayId = row.dataset.holidayId;

    if (target.classList.contains('edit-btn')) {
        editHoliday(holidayId);
    } else if (target.classList.contains('delete-btn')) {
        deleteHoliday(holidayId);
    }
}

async function saveShift() {
    const form = document.getElementById('shiftForm');
    const formData = new FormData(form);

    try {
        const response = await fetch('/api/shifts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: formData.get('name'),
                startTime: formData.get('startTime'),
                endTime: formData.get('endTime'),
                description: formData.get('description'),
                breakDurationMinutes: parseInt(formData.get('breakDuration')),
                isActive: formData.get('isActive') === 'on'
            })
        });

        const data = await response.json();

        if (data.success) {
            showToast('Shift saved successfully', 'success');
            form.reset();
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast('Error: ' + data.message, 'error');
        }
    } catch (error) {
        console.error('Error saving shift:', error);
        showToast('Network error', 'error');
    }
}

async function assignShift() {
    const form = document.getElementById('assignShiftForm');
    const formData = new FormData(form);

    try {
        const response = await fetch('/api/shifts/assign', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: parseInt(formData.get('userId')),
                shiftId: parseInt(formData.get('shiftId')),
                startDate: formData.get('startDate'),
                endDate: formData.get('endDate') || null
            })
        });

        const data = await response.json();

        if (data.success) {
            showToast('Shift assigned successfully', 'success');
            form.reset();
        } else {
            showToast('Error: ' + data.message, 'error');
        }
    } catch (error) {
        console.error('Error assigning shift:', error);
        showToast('Network error', 'error');
    }
}

function exportReport(format) {
    const dateRange = document.getElementById('reportDateRange')?.value;
    const department = document.getElementById('departmentFilter')?.value;

    let url = `/api/admin/reports/export/${format}`;
    const params = new URLSearchParams();

    if (dateRange) {
        const [startDate, endDate] = dateRange.split(' to ');
        params.append('startDate', startDate);
        params.append('endDate', endDate);
    }

    if (department) {
        params.append('department', department);
    }

    if (params.toString()) {
        url += '?' + params.toString();
    }

    window.open(url, '_blank');
}

function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toastContainer');

    if (!toastContainer) {
        const container = document.createElement('div');
        container.id = 'toastContainer';
        container.className = 'toast-container position-fixed top-0 end-0 p-3';
        container.style.zIndex = '9999';
        document.body.appendChild(container);
    }

    const toastId = 'toast-' + Date.now();
    const toastHtml = `
        <div id="${toastId}" class="toast align-items-center text-bg-${type} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">
                    <i class="bi ${type === 'success' ? 'bi-check-circle' :
        type === 'error' ? 'bi-x-circle' :
            type === 'warning' ? 'bi-exclamation-triangle' : 'bi-info-circle'} me-2"></i>
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;

    document.getElementById('toastContainer').innerHTML = toastHtml;

    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, {
        autohide: true,
        delay: 3000
    });
    toast.show();

    toastElement.addEventListener('hidden.bs.toast', function() {
        toastElement.remove();
    });
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function setupAdminEventListeners() {
    // Refresh dashboard button
    const refreshBtn = document.getElementById('refreshDashboard');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', loadDashboardStats);
    }

    // Export buttons
    const exportPdfBtn = document.getElementById('exportPdf');
    const exportExcelBtn = document.getElementById('exportExcel');
    const exportCsvBtn = document.getElementById('exportCsv');

    if (exportPdfBtn) exportPdfBtn.addEventListener('click', () => exportReport('pdf'));
    if (exportExcelBtn) exportExcelBtn.addEventListener('click', () => exportReport('excel'));
    if (exportCsvBtn) exportCsvBtn.addEventListener('click', () => exportReport('csv'));
}

function initializeCharts() {
    // Initialize dashboard charts if needed
    if (typeof Chart !== 'undefined') {
        // Attendance trend chart
        const attendanceTrendCtx = document.getElementById('attendanceTrendChart');
        if (attendanceTrendCtx) {
            new Chart(attendanceTrendCtx.getContext('2d'), {
                type: 'line',
                data: {
                    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    datasets: [{
                        label: 'Attendance Rate',
                        data: [85, 92, 88, 95, 90, 65, 70],
                        borderColor: '#3498db',
                        backgroundColor: 'rgba(52, 152, 219, 0.1)',
                        tension: 0.3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }

        // Department distribution chart
        const departmentDistCtx = document.getElementById('departmentDistChart');
        if (departmentDistCtx) {
            new Chart(departmentDistCtx.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: ['IT', 'HR', 'Finance', 'Marketing', 'Operations'],
                    datasets: [{
                        data: [25, 15, 20, 10, 30],
                        backgroundColor: [
                            '#3498db',
                            '#2ecc71',
                            '#9b59b6',
                            '#f39c12',
                            '#e74c3c'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }
    }
}