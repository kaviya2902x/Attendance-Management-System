// Base API URL
const API_BASE_URL = '/api';

// Show toast notification
function showToast(message, type = 'info') {
    const toastId = 'toast-' + Date.now();
    const toast = $(`
        <div id="${toastId}" class="toast align-items-center text-white bg-${type} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">
                    <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'} me-2"></i>
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `);

    $('.toast-container').append(toast);
    const bsToast = new bootstrap.Toast(toast[0]);
    bsToast.show();

    toast.on('hidden.bs.toast', function() {
        $(this).remove();
    });
}

// Login function
function login() {
    const email = $('#email').val().trim();
    const password = $('#password').val();

    if (!email || !password) {
        showToast('Please enter email and password', 'warning');
        return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showToast('Please enter a valid email address', 'warning');
        return;
    }

    $('#loginBtn').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Signing In...');

    $.ajax({
        url: API_BASE_URL + '/login',
        method: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ email, password }),
        success: function(response) {
            if (response.success) {
                showToast(response.message, 'success');

                // Store user data in localStorage
                localStorage.setItem('user', JSON.stringify(response.user));
                localStorage.setItem('userId', response.user.id);
                localStorage.setItem('userRole', response.user.role);

                // Redirect based on role
                setTimeout(() => {
                    if (response.user.role === 'ADMIN') {
                        window.location.href = '/admin/dashboard';
                    } else {
                        window.location.href = '/employee/dashboard';
                    }
                }, 1000);

            } else {
                showToast(response.message, 'danger');
                $('#loginBtn').prop('disabled', false)
                    .html('<i class="fas fa-sign-in-alt me-2"></i>Sign In');
            }
        },
        error: function(xhr, status, error) {
            showToast('Login failed. Please try again.', 'danger');
            $('#loginBtn').prop('disabled', false)
                .html('<i class="fas fa-sign-in-alt me-2"></i>Sign In');
        }
    });
}

// Logout function
function logout() {
    localStorage.clear();
    window.location.href = '/login';
}

// Toggle password visibility
function togglePassword() {
    const passwordInput = $('#password');
    const toggleBtn = $('#togglePassword');

    if (passwordInput.attr('type') === 'password') {
        passwordInput.attr('type', 'text');
        toggleBtn.html('<i class="fas fa-eye-slash"></i>');
    } else {
        passwordInput.attr('type', 'password');
        toggleBtn.html('<i class="fas fa-eye"></i>');
    }
}

// Initialize auth page
$(document).ready(function() {
    // Login form submit
    $('#loginForm').submit(function(e) {
        e.preventDefault();
        login();
    });

    // Toggle password visibility
    $('#togglePassword').click(togglePassword);

    // Auto-fill demo credentials
    $('#email').on('focus', function() {
        if (!$(this).val()) {
            $(this).attr('placeholder', 'admin@company.com');
        }
    });

    // Enter key to submit
    $('#password').keypress(function(e) {
        if (e.which === 13) {
            login();
        }
    });
});