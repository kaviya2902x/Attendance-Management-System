-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2025 at 04:49 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_db`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `calculate_monthly_payroll` (IN `month_year` VARCHAR(7), IN `hourly_rate` DECIMAL(10,2))   BEGIN
    DECLARE start_date DATE;
    DECLARE end_date DATE;

    -- Calculate month start and end dates
    SET start_date = STR_TO_DATE(CONCAT(month_year, '-01'), '%Y-%m-%d');
    SET end_date = LAST_DAY(start_date);

SELECT
    u.employee_id,
    CONCAT(u.first_name, ' ', u.last_name) as employee_name,
    u.department,
    COUNT(DISTINCT a.attendance_date) as working_days,
    SUM(CASE WHEN a.status = 'PRESENT' THEN 1 ELSE 0 END) as present_days,
    SUM(CASE WHEN a.status IN ('ABSENT', 'HALF_DAY') THEN 1 ELSE 0 END) as unpaid_days,
    ROUND(COALESCE(SUM(a.total_hours), 0), 2) as total_hours,
    ROUND(COALESCE(SUM(a.overtime_hours), 0), 2) as overtime_hours,
    ROUND((COALESCE(SUM(a.total_hours), 0) * hourly_rate), 2) as base_salary,
    ROUND((COALESCE(SUM(a.overtime_hours), 0) * hourly_rate * 1.5), 2) as overtime_pay,
    ROUND(((COALESCE(SUM(a.total_hours), 0) * hourly_rate) +
           (COALESCE(SUM(a.overtime_hours), 0) * hourly_rate * 1.5)), 2) as total_salary
FROM users u
         LEFT JOIN attendance a ON u.id = a.user_id
    AND a.attendance_date BETWEEN start_date AND end_date
WHERE u.status = 'ACTIVE'
GROUP BY u.id, u.employee_id, u.first_name, u.last_name, u.department
ORDER BY u.department, u.employee_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cleanup_test_data` ()   BEGIN
    -- Delete test attendance records (older than 3 months)
DELETE FROM attendance WHERE attendance_date < DATE_SUB(CURDATE(), INTERVAL 3 MONTH);

-- Delete old notifications (older than 1 month)
DELETE FROM notifications WHERE created_at < DATE_SUB(CURDATE(), INTERVAL 1 MONTH);

-- Delete test users (except admin)
DELETE FROM users WHERE role != 'ROLE_ADMIN' AND created_at < DATE_SUB(CURDATE(), INTERVAL 1 MONTH);

-- Reset auto-increment counters
ALTER TABLE attendance AUTO_INCREMENT = 1000;
ALTER TABLE users AUTO_INCREMENT = 10;
ALTER TABLE notifications AUTO_INCREMENT = 100;

SELECT 'Test data cleanup completed' as message;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `generate_attendance_report` (IN `start_date` DATE, IN `end_date` DATE, IN `department_filter` VARCHAR(100))   BEGIN
SELECT
    u.employee_id,
    CONCAT(u.first_name, ' ', u.last_name) as employee_name,
    u.department,
    u.position,
    COUNT(a.id) as total_days,
    SUM(CASE WHEN a.status = 'PRESENT' THEN 1 ELSE 0 END) as present_days,
    SUM(CASE WHEN a.status = 'ABSENT' THEN 1 ELSE 0 END) as absent_days,
    SUM(CASE WHEN a.status = 'HALF_DAY' THEN 1 ELSE 0 END) as half_days,
    SUM(CASE WHEN a.status = 'LEAVE' THEN 1 ELSE 0 END) as leave_days,
    ROUND(COALESCE(SUM(a.total_hours), 0), 2) as total_hours,
    ROUND(COALESCE(SUM(a.overtime_hours), 0), 2) as overtime_hours,
    SUM(a.late_minutes) as total_late_minutes,
    SUM(a.early_departure_minutes) as total_early_minutes
FROM users u
         LEFT JOIN attendance a ON u.id = a.user_id
    AND a.attendance_date BETWEEN start_date AND end_date
WHERE u.status = 'ACTIVE'
  AND (department_filter IS NULL OR u.department = department_filter)
GROUP BY u.id, u.employee_id, u.first_name, u.last_name, u.department, u.position
ORDER BY u.department, u.employee_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `mark_daily_attendance` (IN `attendance_date` DATE)   BEGIN
    DECLARE user_count INT DEFAULT 0;
    DECLARE i INT DEFAULT 0;
    DECLARE current_user_id BIGINT;

    -- Get all active users
    DROP TEMPORARY TABLE IF EXISTS temp_users;
    CREATE TEMPORARY TABLE temp_users AS
SELECT id FROM users WHERE status = 'ACTIVE';

SELECT COUNT(*) INTO user_count FROM temp_users;

-- Loop through each user and create attendance record
WHILE i < user_count DO
SELECT id INTO current_user_id FROM temp_users LIMIT i,1;

-- Check if attendance already exists
IF NOT EXISTS (SELECT 1 FROM attendance WHERE user_id = current_user_id AND attendance_date = attendance_date) THEN
            -- Check if it's a holiday
            IF EXISTS (SELECT 1 FROM holidays WHERE date = attendance_date) THEN
                INSERT INTO attendance (user_id, attendance_date, status)
                VALUES (current_user_id, attendance_date, 'HOLIDAY');
            -- Check if it's weekend (Saturday or Sunday)
            ELSEIF DAYOFWEEK(attendance_date) IN (1,7) THEN
                INSERT INTO attendance (user_id, attendance_date, status)
                VALUES (current_user_id, attendance_date, 'WEEKEND');
ELSE
                -- Default to ABSENT
                INSERT INTO attendance (user_id, attendance_date, status)
                VALUES (current_user_id, attendance_date, 'ABSENT');
END IF;
END IF;

        SET i = i + 1;
END WHILE;

    DROP TEMPORARY TABLE temp_users;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
                              `id` bigint(20) NOT NULL,
                              `attendance_date` date NOT NULL,
                              `clock_in_location` varchar(255) DEFAULT NULL,
                              `clock_in_time` time(6) DEFAULT NULL,
                              `clock_out_location` varchar(255) DEFAULT NULL,
                              `clock_out_time` time(6) DEFAULT NULL,
                              `created_at` datetime(6) DEFAULT NULL,
                              `early_departure_minutes` int(11) DEFAULT NULL,
                              `late_minutes` int(11) DEFAULT NULL,
                              `notes` varchar(255) DEFAULT NULL,
                              `overtime_hours` double DEFAULT NULL,
                              `status` varchar(255) NOT NULL,
                              `total_hours` double DEFAULT NULL,
                              `updated_at` datetime(6) DEFAULT NULL,
                              `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
                              `id` bigint(20) NOT NULL,
                              `user_id` bigint(20) DEFAULT NULL,
                              `action` varchar(100) NOT NULL,
                              `entity_type` varchar(50) NOT NULL,
                              `entity_id` bigint(20) DEFAULT NULL,
                              `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
                              `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
                              `ip_address` varchar(45) DEFAULT NULL,
                              `user_agent` text DEFAULT NULL,
                              `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `database_maintenance_info`
-- (See below for the actual view)
--
CREATE TABLE `database_maintenance_info` (
                                             `TABLE_NAME` varchar(64)
    ,`TABLE_ROWS` bigint(21) unsigned
    ,`data_size_bytes` bigint(21) unsigned
    ,`index_size_bytes` bigint(21) unsigned
    ,`total_size_mb` decimal(25,2)
    ,`UPDATE_TIME` datetime
    ,`TABLE_COLLATION` varchar(32)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `employee_leave_balance`
-- (See below for the actual view)
--
CREATE TABLE `employee_leave_balance` (
                                          `user_id` bigint(20)
    ,`employee_id` varchar(50)
    ,`employee_name` varchar(201)
    ,`department` varchar(100)
    ,`current_year` int(4)
    ,`total_leave_entitlement` int(2)
    ,`used_leaves` decimal(32,0)
    ,`remaining_leaves` decimal(33,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

CREATE TABLE `holidays` (
                            `id` bigint(20) NOT NULL,
                            `created_at` date NOT NULL,
                            `date` date NOT NULL,
                            `description` varchar(255) DEFAULT NULL,
                            `name` varchar(255) NOT NULL,
                            `recurring` bit(1) NOT NULL,
                            `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `holidays`
--

INSERT INTO `holidays` (`id`, `created_at`, `date`, `description`, `name`, `recurring`, `type`) VALUES
    (1, '2025-12-04', '2025-01-01', 'Public Holiday', 'New Year\'s Day', b'1', NULL),
(2, '2025-12-04', '2025-12-25', 'Public Holiday', 'Christmas Day', b'1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `leave_applications`
--

CREATE TABLE `leave_applications` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `leave_type` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total_days` int(11) NOT NULL,
  `reason` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'PENDING',
  `approved_by` varchar(255) DEFAULT NULL,
  `approval_date` date DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `attachment_url` varchar(500) DEFAULT NULL,
  `applied_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leave_applications`
--

INSERT INTO `leave_applications` (`id`, `user_id`, `leave_type`, `start_date`, `end_date`, `total_days`, `reason`, `status`, `approved_by`, `approval_date`, `rejection_reason`, `attachment_url`, `applied_date`, `created_at`, `updated_at`) VALUES
(1, 2, 'CASUAL', '2025-11-19', '2025-11-21', 3, 'Family function', 'APPROVED', NULL, NULL, NULL, NULL, '2025-11-14', '2025-12-04 09:40:36', '2025-12-04 09:40:36'),
(2, 3, 'SICK', '2025-11-24', '2025-11-24', 1, 'Fever and cold', 'APPROVED', NULL, NULL, NULL, NULL, '2025-11-22', '2025-12-04 09:40:36', '2025-12-04 09:40:36'),
(3, 4, 'EARNED', '2025-11-29', '2025-12-02', 4, 'Vacation with family', 'PENDING', NULL, NULL, NULL, NULL, '2025-11-27', '2025-12-04 09:40:36', '2025-12-04 09:40:36'),
(4, 5, 'CASUAL', '2025-12-09', '2025-12-09', 1, 'Doctor appointment', 'PENDING', NULL, NULL, NULL, NULL, '2025-12-02', '2025-12-04 09:40:36', '2025-12-04 09:40:36');

--
-- Triggers `leave_applications`
--
DELIMITER $$
CREATE TRIGGER `notify_leave_application` AFTER INSERT ON `leave_applications` FOR EACH ROW BEGIN
    DECLARE manager_email VARCHAR(255);

    -- Get reporting manager email
    SELECT email INTO manager_email
    FROM users
    WHERE CONCAT(first_name, ' ', last_name) = NEW.approved_by
    OR email = NEW.approved_by
    LIMIT 1;

    -- If no specific manager, get from user's reporting_manager field
    IF manager_email IS NULL THEN
        SELECT email INTO manager_email
        FROM users
        WHERE CONCAT(first_name, ' ', last_name) = (SELECT reporting_manager FROM users WHERE id = NEW.user_id)
        LIMIT 1;
END IF;

    -- Create notification for manager
    IF manager_email IS NOT NULL THEN
        INSERT INTO notifications (
            user_id,
            title,
            message,
            type,
            related_entity,
            related_id,
            created_at
        ) VALUES (
            (SELECT id FROM users WHERE email = manager_email),
            'New Leave Application',
            CONCAT(
                (SELECT CONCAT(first_name, ' ', last_name) FROM users WHERE id = NEW.user_id),
                ' has applied for ',
                NEW.leave_type,
                ' leave from ',
                DATE_FORMAT(NEW.start_date, '%b %d, %Y'),
                ' to ',
                DATE_FORMAT(NEW.end_date, '%b %d, %Y')
            ),
            'INFO',
            'LEAVE',
            NEW.id,
            NOW()
        );
END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
                                 `id` bigint(20) NOT NULL,
                                 `user_id` bigint(20) NOT NULL,
                                 `title` varchar(255) NOT NULL,
                                 `message` text NOT NULL,
                                 `type` varchar(50) NOT NULL,
                                 `is_read` tinyint(1) NOT NULL DEFAULT 0,
                                 `related_entity` varchar(50) DEFAULT NULL,
                                 `related_id` bigint(20) DEFAULT NULL,
                                 `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `is_read`, `related_entity`, `related_id`, `created_at`) VALUES
                                                                                                                                       (1, 1, 'New Leave Application', 'John Doe has applied for CASUAL leave from Nov 19, 2025 to Nov 21, 2025', 'INFO', 0, 'LEAVE', 1, '2025-12-04 09:40:36'),
                                                                                                                                       (2, 1, 'New Leave Application', 'Jane Smith has applied for SICK leave from Nov 24, 2025 to Nov 24, 2025', 'INFO', 0, 'LEAVE', 2, '2025-12-04 09:40:36'),
                                                                                                                                       (3, 1, 'New Leave Application', 'Robert Johnson has applied for EARNED leave from Nov 29, 2025 to Dec 02, 2025', 'INFO', 0, 'LEAVE', 3, '2025-12-04 09:40:36'),
                                                                                                                                       (4, 1, 'New Leave Application', 'Sarah Williams has applied for CASUAL leave from Dec 09, 2025 to Dec 09, 2025', 'INFO', 0, 'LEAVE', 4, '2025-12-04 09:40:36'),
                                                                                                                                       (5, 1, 'System Update', 'System maintenance scheduled for tomorrow night', 'INFO', 0, 'SYSTEM', NULL, '2025-12-04 09:40:36'),
                                                                                                                                       (6, 2, 'Leave Approved', 'Your casual leave has been approved', 'SUCCESS', 1, 'LEAVE', 1, '2025-12-04 09:40:36'),
                                                                                                                                       (7, 3, 'Regularization Pending', 'Your regularization request is pending approval', 'WARNING', 0, 'REGULARIZATION', 1, '2025-12-04 09:40:36'),
                                                                                                                                       (8, 4, 'New Holiday Added', 'Diwali holiday has been added to calendar', 'INFO', 0, 'HOLIDAY', 9, '2025-12-04 09:40:36');

-- --------------------------------------------------------

--
-- Table structure for table `onduty_applications`
--

CREATE TABLE `onduty_applications` (
                                       `id` bigint(20) NOT NULL,
                                       `user_id` bigint(20) NOT NULL,
                                       `start_date` date NOT NULL,
                                       `end_date` date NOT NULL,
                                       `total_days` int(11) NOT NULL,
                                       `purpose` text NOT NULL,
                                       `destination` varchar(255) DEFAULT NULL,
                                       `status` varchar(20) NOT NULL DEFAULT 'PENDING',
                                       `approved_by` varchar(255) DEFAULT NULL,
                                       `approval_date` date DEFAULT NULL,
                                       `rejection_reason` text DEFAULT NULL,
                                       `applied_date` date NOT NULL,
                                       `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `onduty_applications`
--

INSERT INTO `onduty_applications` (`id`, `user_id`, `start_date`, `end_date`, `total_days`, `purpose`, `destination`, `status`, `approved_by`, `approval_date`, `rejection_reason`, `applied_date`, `created_at`) VALUES
                                                                                                                                                                                                                      (1, 2, '2025-12-14', '2025-12-16', 3, 'Client meeting', 'Mumbai', 'PENDING', NULL, NULL, NULL, '2025-12-04', '2025-12-04 09:40:36'),
                                                                                                                                                                                                                      (2, 5, '2025-11-27', '2025-11-29', 3, 'Training program', 'Delhi', 'APPROVED', NULL, NULL, NULL, '2025-11-24', '2025-12-04 09:40:36');

-- --------------------------------------------------------

--
-- Table structure for table `regularization_requests`
--

CREATE TABLE `regularization_requests` (
                                           `id` bigint(20) NOT NULL,
                                           `approval_date` date DEFAULT NULL,
                                           `approved_by` varchar(255) DEFAULT NULL,
                                           `attendance_date` date NOT NULL,
                                           `created_at` datetime(6) DEFAULT NULL,
                                           `reason` varchar(500) NOT NULL,
                                           `rejection_reason` varchar(255) DEFAULT NULL,
                                           `requested_clock_in` varchar(255) DEFAULT NULL,
                                           `requested_clock_out` varchar(255) DEFAULT NULL,
                                           `requested_date` date NOT NULL,
                                           `status` varchar(255) NOT NULL,
                                           `updated_at` datetime(6) DEFAULT NULL,
                                           `attendance_id` bigint(20) DEFAULT NULL,
                                           `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shifts`
--

CREATE TABLE `shifts` (
                          `id` bigint(20) NOT NULL,
                          `name` varchar(100) NOT NULL,
                          `start_time` time NOT NULL,
                          `end_time` time NOT NULL,
                          `description` text DEFAULT NULL,
                          `break_duration_minutes` int(11) DEFAULT 60,
                          `is_active` tinyint(1) NOT NULL DEFAULT 1,
                          `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
                          `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shifts`
--

INSERT INTO `shifts` (`id`, `name`, `start_time`, `end_time`, `description`, `break_duration_minutes`, `is_active`, `created_at`, `updated_at`) VALUES
                                                                                                                                                    (1, 'Morning Shift', '09:00:00', '18:00:00', 'Regular 9 AM to 6 PM shift with 1 hour lunch break', 60, 1, '2025-12-04 09:40:35', '2025-12-04 09:40:35'),
                                                                                                                                                    (2, 'Night Shift', '22:00:00', '06:00:00', 'Night shift with overnight duty', 60, 1, '2025-12-04 09:40:35', '2025-12-04 09:40:35'),
                                                                                                                                                    (3, 'Flexi Shift', '10:00:00', '19:00:00', 'Flexible timing shift', 60, 1, '2025-12-04 09:40:35', '2025-12-04 09:40:35'),
                                                                                                                                                    (4, 'Part Time', '14:00:00', '18:00:00', 'Part time shift for 4 hours', 30, 1, '2025-12-04 09:40:35', '2025-12-04 09:40:35');

-- --------------------------------------------------------

--
-- Table structure for table `shift_swap_requests`
--

CREATE TABLE `shift_swap_requests` (
                                       `id` bigint(20) NOT NULL,
                                       `requestor_id` bigint(20) NOT NULL,
                                       `requested_to_id` bigint(20) NOT NULL,
                                       `swap_date` date NOT NULL,
                                       `requestor_shift_id` bigint(20) DEFAULT NULL,
                                       `requested_shift_id` bigint(20) DEFAULT NULL,
                                       `reason` text DEFAULT NULL,
                                       `status` varchar(20) NOT NULL DEFAULT 'PENDING',
                                       `approved_date` date DEFAULT NULL,
                                       `rejection_reason` text DEFAULT NULL,
                                       `requested_date` date NOT NULL,
                                       `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shift_swap_requests`
--

INSERT INTO `shift_swap_requests` (`id`, `requestor_id`, `requested_to_id`, `swap_date`, `requestor_shift_id`, `requested_shift_id`, `reason`, `status`, `approved_date`, `rejection_reason`, `requested_date`, `created_at`) VALUES
                                                                                                                                                                                                                                  (1, 2, 3, '2025-12-07', NULL, NULL, 'Have a doctor appointment', 'PENDING', NULL, NULL, '2025-12-04', '2025-12-04 09:40:36'),
                                                                                                                                                                                                                                  (2, 4, 5, '2025-12-02', NULL, NULL, 'Family emergency', 'APPROVED', NULL, NULL, '2025-12-01', '2025-12-04 09:40:36');

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

CREATE TABLE `system_settings` (
                                   `id` bigint(20) NOT NULL,
                                   `setting_key` varchar(100) NOT NULL,
                                   `setting_value` text NOT NULL,
                                   `description` text DEFAULT NULL,
                                   `category` varchar(50) DEFAULT 'GENERAL',
                                   `is_encrypted` tinyint(1) DEFAULT 0,
                                   `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
                                   `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `description`, `category`, `is_encrypted`, `created_at`, `updated_at`) VALUES
                                                                                                                                                (1, 'app.name', 'Attendance Management System', 'Application name', 'GENERAL', 0, '2025-12-04 09:40:36', '2025-12-04 09:40:36'),
                                                                                                                                                (2, 'app.company', 'TechCorp Inc.', 'Company name', 'GENERAL', 0, '2025-12-04 09:40:36', '2025-12-04 09:40:36'),
                                                                                                                                                (3, 'max.leave.days', '30', 'Maximum leave days per year', 'LEAVE', 0, '2025-12-04 09:40:36', '2025-12-04 09:40:36'),
                                                                                                                                                (4, 'working.hours.per.day', '8', 'Standard working hours per day', 'ATTENDANCE', 0, '2025-12-04 09:40:36', '2025-12-04 09:40:36'),
                                                                                                                                                (5, 'late.threshold.minutes', '15', 'Late arrival threshold in minutes', 'ATTENDANCE', 0, '2025-12-04 09:40:36', '2025-12-04 09:40:36'),
                                                                                                                                                (6, 'early.departure.threshold', '30', 'Early departure threshold in minutes', 'ATTENDANCE', 0, '2025-12-04 09:40:36', '2025-12-04 09:40:36'),
                                                                                                                                                (7, 'overtime.rate', '1.5', 'Overtime pay rate multiplier', 'PAYROLL', 0, '2025-12-04 09:40:36', '2025-12-04 09:40:36'),
                                                                                                                                                (8, 'attendance.report.email', 'hr@techcorp.com', 'Email for attendance reports', 'EMAIL', 0, '2025-12-04 09:40:36', '2025-12-04 09:40:36'),
                                                                                                                                                (9, 'allow.remote.attendance', 'true', 'Allow remote attendance marking', 'ATTENDANCE', 0, '2025-12-04 09:40:36', '2025-12-04 09:40:36'),
                                                                                                                                                (10, 'default.shift.id', '1', 'Default shift ID for new employees', 'SHIFT', 0, '2025-12-04 09:40:36', '2025-12-04 09:40:36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
                         `id` bigint(20) NOT NULL,
                         `employee_id` varchar(50) NOT NULL,
                         `first_name` varchar(100) NOT NULL,
                         `last_name` varchar(100) NOT NULL,
                         `email` varchar(255) NOT NULL,
                         `password` varchar(255) NOT NULL,
                         `phone_number` varchar(20) DEFAULT NULL,
                         `date_of_birth` date DEFAULT NULL,
                         `role` varchar(50) NOT NULL DEFAULT 'ROLE_EMPLOYEE',
                         `department` varchar(100) NOT NULL,
                         `position` varchar(100) NOT NULL,
                         `joining_date` date NOT NULL,
                         `reporting_manager` varchar(255) DEFAULT NULL,
                         `emergency_contact` varchar(100) DEFAULT NULL,
                         `emergency_phone` varchar(20) DEFAULT NULL,
                         `current_address` text DEFAULT NULL,
                         `permanent_address` text DEFAULT NULL,
                         `profile_image` varchar(500) DEFAULT 'avatar.png',
                         `status` varchar(20) NOT NULL DEFAULT 'ACTIVE',
                         `shift_id` bigint(20) DEFAULT NULL,
                         `created_at` date DEFAULT curdate(),
                         `updated_at` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `employee_id`, `first_name`, `last_name`, `email`, `password`, `phone_number`, `date_of_birth`, `role`, `department`, `position`, `joining_date`, `reporting_manager`, `emergency_contact`, `emergency_phone`, `current_address`, `permanent_address`, `profile_image`, `status`, `shift_id`, `created_at`, `updated_at`) VALUES
                                                                                                                                                                                                                                                                                                                                                         (1, 'ADM001', 'Admin', 'System', 'admin@techcorp.com', '$2a$10$YourHashedPasswordHere', '+1234567890', NULL, 'ROLE_ADMIN', 'Administration', 'System Administrator', '2025-12-04', NULL, NULL, NULL, NULL, NULL, 'avatar.png', 'ACTIVE', 1, '2025-12-04', '2025-12-04'),
                                                                                                                                                                                                                                                                                                                                                         (2, 'EMP001', 'John', 'Doe', 'john.doe@techcorp.com', '$2a$10$YourHashedPasswordHere', '+1234567891', '1990-05-15', 'ROLE_EMPLOYEE', 'IT', 'Software Developer', '2022-01-15', 'Admin System', 'Jane Doe', '+1234567892', '123 Main St, City', '456 Park Ave, Hometown', 'avatar.png', 'ACTIVE', 1, '2025-12-04', '2025-12-04'),
                                                                                                                                                                                                                                                                                                                                                         (3, 'EMP002', 'Jane', 'Smith', 'jane.smith@techcorp.com', '$2a$10$YourHashedPasswordHere', '+1234567893', '1988-08-22', 'ROLE_EMPLOYEE', 'HR', 'HR Manager', '2021-03-10', 'Admin System', 'John Smith', '+1234567894', '456 Oak St, City', '789 Pine St, Hometown', 'avatar.png', 'ACTIVE', 1, '2025-12-04', '2025-12-04'),
                                                                                                                                                                                                                                                                                                                                                         (4, 'EMP003', 'Robert', 'Johnson', 'robert.johnson@techcorp.com', '$2a$10$YourHashedPasswordHere', '+1234567895', '1992-11-30', 'ROLE_EMPLOYEE', 'Finance', 'Accountant', '2023-06-20', 'Admin System', 'Mary Johnson', '+1234567896', '789 Maple St, City', '321 Elm St, Hometown', 'avatar.png', 'ACTIVE', 2, '2025-12-04', '2025-12-04'),
                                                                                                                                                                                                                                                                                                                                                         (5, 'EMP004', 'Sarah', 'Williams', 'sarah.williams@techcorp.com', '$2a$10$YourHashedPasswordHere', '+1234567897', '1995-02-14', 'ROLE_EMPLOYEE', 'Marketing', 'Marketing Executive', '2022-11-05', 'Admin System', 'David Williams', '+1234567898', '321 Birch St, City', '654 Cedar St, Hometown', 'avatar.png', 'ACTIVE', 3, '2025-12-04', '2025-12-04'),
                                                                                                                                                                                                                                                                                                                                                         (6, 'EMP005', 'Michael', 'Brown', 'michael.brown@techcorp.com', '$2a$10$YourHashedPasswordHere', '+1234567899', '1985-07-08', 'ROLE_MANAGER', 'IT', 'IT Manager', '2020-09-12', 'Admin System', 'Lisa Brown', '+1234567800', '654 Walnut St, City', '987 Spruce St, Hometown', 'avatar.png', 'ACTIVE', 1, '2025-12-04', '2025-12-04');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `update_user_timestamp` BEFORE UPDATE ON `users` FOR EACH ROW BEGIN
    SET NEW.updated_at = CURDATE();
END
    $$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure for view `database_maintenance_info`
--
DROP TABLE IF EXISTS `database_maintenance_info`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `database_maintenance_info`  AS SELECT `information_schema`.`tables`.`TABLE_NAME` AS `TABLE_NAME`, `information_schema`.`tables`.`TABLE_ROWS` AS `TABLE_ROWS`, `information_schema`.`tables`.`DATA_LENGTH` AS `data_size_bytes`, `information_schema`.`tables`.`INDEX_LENGTH` AS `index_size_bytes`, round((`information_schema`.`tables`.`DATA_LENGTH` + `information_schema`.`tables`.`INDEX_LENGTH`) / 1024 / 1024,2) AS `total_size_mb`, `information_schema`.`tables`.`UPDATE_TIME` AS `UPDATE_TIME`, `information_schema`.`tables`.`TABLE_COLLATION` AS `TABLE_COLLATION` FROM `information_schema`.`tables` WHERE `information_schema`.`tables`.`TABLE_SCHEMA` = 'attendance_db' ORDER BY round((`information_schema`.`tables`.`DATA_LENGTH` + `information_schema`.`tables`.`INDEX_LENGTH`) / 1024 / 1024,2) DESC ;

-- --------------------------------------------------------

--
-- Structure for view `employee_leave_balance`
--
DROP TABLE IF EXISTS `employee_leave_balance`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `employee_leave_balance`  AS SELECT `u`.`id` AS `user_id`, `u`.`employee_id` AS `employee_id`, concat(`u`.`first_name`,' ',`u`.`last_name`) AS `employee_name`, `u`.`department` AS `department`, year(curdate()) AS `current_year`, 30 AS `total_leave_entitlement`, coalesce(sum(case when `l`.`status` = 'APPROVED' and year(`l`.`start_date`) = year(curdate()) then `l`.`total_days` else 0 end),0) AS `used_leaves`, 30 - coalesce(sum(case when `l`.`status` = 'APPROVED' and year(`l`.`start_date`) = year(curdate()) then `l`.`total_days` else 0 end),0) AS `remaining_leaves` FROM (`users` `u` left join `leave_applications` `l` on(`u`.`id` = `l`.`user_id`)) GROUP BY `u`.`id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
    ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK6y2t3r1ig8a9ccqwbrs6wk4l8` (`user_id`,`attendance_date`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
    ADD PRIMARY KEY (`id`),
  ADD KEY `idx_audit_user` (`user_id`),
  ADD KEY `idx_audit_entity` (`entity_type`,`entity_id`),
  ADD KEY `idx_audit_created` (`created_at`);

--
-- Indexes for table `holidays`
--
ALTER TABLE `holidays`
    ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_applications`
--
ALTER TABLE `leave_applications`
    ADD PRIMARY KEY (`id`),
  ADD KEY `idx_leave_user` (`user_id`),
  ADD KEY `idx_leave_status` (`status`),
  ADD KEY `idx_leave_dates` (`start_date`,`end_date`),
  ADD KEY `idx_leave_applied_date` (`applied_date`),
  ADD KEY `idx_leave_type` (`leave_type`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
    ADD PRIMARY KEY (`id`),
  ADD KEY `idx_notification_user` (`user_id`),
  ADD KEY `idx_notification_read` (`is_read`),
  ADD KEY `idx_notification_created` (`created_at`),
  ADD KEY `idx_notification_user_read` (`user_id`,`is_read`);

--
-- Indexes for table `onduty_applications`
--
ALTER TABLE `onduty_applications`
    ADD PRIMARY KEY (`id`),
  ADD KEY `idx_onduty_user` (`user_id`),
  ADD KEY `idx_onduty_status` (`status`),
  ADD KEY `idx_onduty_dates` (`start_date`,`end_date`);

--
-- Indexes for table `regularization_requests`
--
ALTER TABLE `regularization_requests`
    ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_j6xyhxdvc63yhh8s0svgpefga` (`attendance_id`),
  ADD KEY `FKbmw59hxkhdl78fh0e85r55u5b` (`user_id`);

--
-- Indexes for table `shifts`
--
ALTER TABLE `shifts`
    ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `shift_swap_requests`
--
ALTER TABLE `shift_swap_requests`
    ADD PRIMARY KEY (`id`),
  ADD KEY `fk_swap_requestor_shift` (`requestor_shift_id`),
  ADD KEY `fk_swap_requested_shift` (`requested_shift_id`),
  ADD KEY `idx_swap_requestor` (`requestor_id`),
  ADD KEY `idx_swap_requested_to` (`requested_to_id`),
  ADD KEY `idx_swap_status` (`status`),
  ADD KEY `idx_swap_date` (`swap_date`);

--
-- Indexes for table `system_settings`
--
ALTER TABLE `system_settings`
    ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`),
  ADD KEY `idx_settings_key` (`setting_key`),
  ADD KEY `idx_settings_category` (`category`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
    ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `employee_id` (`employee_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `UK6dotkott2kjsp8vw4d0m25fb7` (`email`),
  ADD UNIQUE KEY `UKd1s31g1a7ilra77m65xmka3ei` (`employee_id`),
  ADD KEY `fk_user_shift` (`shift_id`),
  ADD KEY `idx_user_email` (`email`),
  ADD KEY `idx_user_status` (`status`),
  ADD KEY `idx_user_department` (`department`),
  ADD KEY `idx_user_role` (`role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
    MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
    MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `holidays`
--
ALTER TABLE `holidays`
    MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `leave_applications`
--
ALTER TABLE `leave_applications`
    MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
    MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `onduty_applications`
--
ALTER TABLE `onduty_applications`
    MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `regularization_requests`
--
ALTER TABLE `regularization_requests`
    MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shifts`
--
ALTER TABLE `shifts`
    MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `shift_swap_requests`
--
ALTER TABLE `shift_swap_requests`
    MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `system_settings`
--
ALTER TABLE `system_settings`
    MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
    MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
    ADD CONSTRAINT `FKjcaqd29v2qy723owsdah2t8vx` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `leave_applications`
--
ALTER TABLE `leave_applications`
    ADD CONSTRAINT `fk_leave_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
    ADD CONSTRAINT `fk_notification_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `onduty_applications`
--
ALTER TABLE `onduty_applications`
    ADD CONSTRAINT `fk_onduty_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `regularization_requests`
--
ALTER TABLE `regularization_requests`
    ADD CONSTRAINT `FK3jnxe2h9uefbsxgolvfr06iw0` FOREIGN KEY (`attendance_id`) REFERENCES `attendance` (`id`),
  ADD CONSTRAINT `FKbmw59hxkhdl78fh0e85r55u5b` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `shift_swap_requests`
--
ALTER TABLE `shift_swap_requests`
    ADD CONSTRAINT `fk_swap_requested_shift` FOREIGN KEY (`requested_shift_id`) REFERENCES `shifts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_swap_requested_to` FOREIGN KEY (`requested_to_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_swap_requestor` FOREIGN KEY (`requestor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_swap_requestor_shift` FOREIGN KEY (`requestor_shift_id`) REFERENCES `shifts` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
    ADD CONSTRAINT `fk_user_shift` FOREIGN KEY (`shift_id`) REFERENCES `shifts` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
