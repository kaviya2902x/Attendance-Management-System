package com.attendance.integration;

import com.attendance.controller.AuthController;
import com.attendance.entity.User;
import com.attendance.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class SecurityIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AuthController authController;

    @BeforeEach
    void setUp() {
        // Clean up before tests
        userRepository.deleteAll();
    }

    @Test
    void testUnauthenticatedAccessToProtectedPage() throws Exception {
        mockMvc.perform(get("/employee/dashboard"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("**/login"));
    }

    @Test
    @WithMockUser(username = "john.doe@techcorp.com", roles = {"EMPLOYEE"})
    void testAuthenticatedEmployeeAccess() throws Exception {
        mockMvc.perform(get("/employee/dashboard"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/attendance/mark"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/leave/apply"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "john.doe@techcorp.com", roles = {"EMPLOYEE"})
    void testEmployeeCannotAccessAdminPages() throws Exception {
        mockMvc.perform(get("/admin/dashboard"))
                .andExpect(status().isForbidden());

        mockMvc.perform(get("/admin/users"))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(username = "admin@techcorp.com", roles = {"ADMIN"})
    void testAdminCanAccessAllPages() throws Exception {
        mockMvc.perform(get("/admin/dashboard"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/admin/users"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/employee/dashboard"))
                .andExpect(status().isOk());
    }

    @Test
    void testPublicAccessToAuthPages() throws Exception {
        mockMvc.perform(get("/auth/login"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/auth/register"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/auth/forgot-password"))
                .andExpect(status().isOk());
    }

    @Test
    void testLoginProcess() throws Exception {
        // Create a test user
        User user = new User();
        user.setEmployeeId("TEST001");
        user.setFirstName("Test");
        user.setLastName("User");
        user.setEmail("test.user@techcorp.com");
        user.setPassword("$2a$10$YourHashedPasswordHere"); // BCrypt hash
        user.setDepartment("TEST");
        user.setPosition("Tester");
        user.setRole("ROLE_EMPLOYEE");
        user.setStatus("ACTIVE");

        userRepository.save(user);

        // Note: Actual login test would require proper authentication setup
        // This test verifies the login page is accessible
        mockMvc.perform(post("/auth/login")
                        .with(csrf())
                        .param("email", "test.user@techcorp.com")
                        .param("password", "password123"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/employee/dashboard"));
    }

    @Test
    void testLogoutProcess() throws Exception {
        mockMvc.perform(get("/auth/logout"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/auth/login?logout=true"));
    }
}