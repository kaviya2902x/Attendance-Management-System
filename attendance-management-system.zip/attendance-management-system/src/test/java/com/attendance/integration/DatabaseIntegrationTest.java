package com.attendance.integration;

import com.attendance.entity.Attendance;
import com.attendance.entity.User;
import com.attendance.repository.AttendanceRepository;
import com.attendance.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles("test")
@Transactional
class DatabaseIntegrationTest {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AttendanceRepository attendanceRepository;

    private User testUser;

    @BeforeEach
    void setUp() {
        // Create test user
        testUser = new User();
        testUser.setEmployeeId("TEST001");
        testUser.setFirstName("Integration");
        testUser.setLastName("Test");
        testUser.setEmail("integration.test@techcorp.com");
        testUser.setPassword("password123");
        testUser.setDepartment("IT");
        testUser.setPosition("Tester");
        testUser.setJoiningDate(LocalDate.now());
        testUser.setRole("ROLE_EMPLOYEE");
        testUser.setStatus("ACTIVE");

        userRepository.save(testUser);
    }

    @Test
    void testUserPersistence() {
        // Verify user was saved
        List<User> users = userRepository.findAll();
        assertThat(users).isNotEmpty();

        User savedUser = userRepository.findByEmail("integration.test@techcorp.com")
                .orElse(null);
        assertThat(savedUser).isNotNull();
        assertThat(savedUser.getEmployeeId()).isEqualTo("TEST001");
        assertThat(savedUser.getFirstName()).isEqualTo("Integration");
    }

    @Test
    void testAttendancePersistence() {
        // Create attendance record
        Attendance attendance = new Attendance();
        attendance.setUser(testUser);
        attendance.setAttendanceDate(LocalDate.now());
        attendance.setClockInTime(LocalTime.of(9, 0));
        attendance.setClockOutTime(LocalTime.of(18, 0));
        attendance.setStatus("PRESENT");
        attendance.setTotalHours(9.0);

        attendanceRepository.save(attendance);

        // Verify attendance was saved
        List<Attendance> attendances = attendanceRepository.findAll();
        assertThat(attendances).isNotEmpty();

        Attendance savedAttendance = attendanceRepository
                .findByUserIdAndAttendanceDate(testUser.getId(), LocalDate.now())
                .orElse(null);
        assertThat(savedAttendance).isNotNull();
        assertThat(savedAttendance.getStatus()).isEqualTo("PRESENT");
        assertThat(savedAttendance.getTotalHours()).isEqualTo(9.0);
    }

    @Test
    void testUserAttendanceRelationship() {
        // Create multiple attendance records for user
        for (int i = 1; i <= 5; i++) {
            Attendance attendance = new Attendance();
            attendance.setUser(testUser);
            attendance.setAttendanceDate(LocalDate.now().minusDays(i));
            attendance.setStatus(i % 2 == 0 ? "PRESENT" : "ABSENT");
            attendanceRepository.save(attendance);
        }

        // Verify relationship
        User userWithAttendances = userRepository.findById(testUser.getId())
                .orElseThrow();

        // Note: LAZY loading might require @Transactional or explicit fetching
        // For this test, we'll query attendance repository directly
        List<Attendance> userAttendances = attendanceRepository.findByUserId(testUser.getId());

        assertThat(userAttendances).hasSize(5);
        assertThat(userAttendances).allMatch(a -> a.getUser().getId().equals(testUser.getId()));
    }

    @Test
    void testAttendanceQueries() {
        // Create test data
        LocalDate startDate = LocalDate.now().minusDays(7);
        LocalDate endDate = LocalDate.now();

        for (int i = 0; i < 7; i++) {
            Attendance attendance = new Attendance();
            attendance.setUser(testUser);
            attendance.setAttendanceDate(LocalDate.now().minusDays(i));
            attendance.setStatus(i % 2 == 0 ? "PRESENT" : "ABSENT");
            attendanceRepository.save(attendance);
        }

        // Test date range query
        List<Attendance> dateRangeAttendances = attendanceRepository
                .findByUserIdAndAttendanceDateBetween(testUser.getId(), startDate, endDate);
        assertThat(dateRangeAttendances).hasSize(7);

        // Test monthly query
        int currentMonth = LocalDate.now().getMonthValue();
        int currentYear = LocalDate.now().getYear();
        List<Attendance> monthlyAttendances = attendanceRepository
                .findByUserIdAndMonth(testUser.getId(), currentYear, currentMonth);
        assertThat(monthlyAttendances).isNotEmpty();

        // Test present days count
        Long presentDays = attendanceRepository.countPresentDays(
                testUser.getId(), startDate, endDate
        );
        assertThat(presentDays).isEqualTo(4L); // Even days are present (0,2,4,6)
    }
}