package com.attendance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles("test")
class AttendanceApplicationTests {

    @Test
    void contextLoads() {
        // Test that the application context loads successfully
        assertThat(true).isTrue();
    }

    @Test
    void testApplicationStartup() {
        AttendanceApplication application = new AttendanceApplication();
        assertThat(application).isNotNull();
    }
}