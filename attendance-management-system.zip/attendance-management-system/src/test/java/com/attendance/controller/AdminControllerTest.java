package com.attendance.controller;

import com.attendance.entity.User;
import com.attendance.service.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AdminController.class)
class AdminControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @MockBean
    private AttendanceService attendanceService;

    @MockBean
    private LeaveService leaveService;

    @MockBean
    private HolidayService holidayService;

    @MockBean
    private ShiftService shiftService;

    private User testUser;
    private User testAdmin;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setEmail("john.doe@techcorp.com");
        testUser.setFirstName("John");
        testUser.setLastName("Doe");
        testUser.setRole("ROLE_EMPLOYEE");

        testAdmin = new User();
        testAdmin.setId(2L);
        testAdmin.setEmail("admin@techcorp.com");
        testAdmin.setFirstName("Admin");
        testAdmin.setLastName("System");
        testAdmin.setRole("ROLE_ADMIN");
    }

    @Test
    @WithMockUser(username = "admin@techcorp.com", roles = {"ADMIN"})
    void testAdminDashboard_Success() throws Exception {
        when(userService.getActiveUsersCount()).thenReturn(10L);

        mockMvc.perform(get("/admin/dashboard"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/dashboard"))
                .andExpect(model().attributeExists("totalUsers"))
                .andExpect(model().attributeExists("user"));
    }

    @Test
    @WithMockUser(username = "admin@techcorp.com", roles = {"ADMIN"})
    void testManageUsers_Success() throws Exception {
        List<User> users = Arrays.asList(testUser, testAdmin);
        when(userService.getAllUsers()).thenReturn(users);

        mockMvc.perform(get("/admin/users"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/users"))
                .andExpect(model().attributeExists("users"));
    }

    @Test
    @WithMockUser(username = "admin@techcorp.com", roles = {"ADMIN"})
    void testViewUser_Success() throws Exception {
        when(userService.getUserById(anyLong())).thenReturn(testUser);

        mockMvc.perform(get("/admin/users/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/user-details"))
                .andExpect(model().attributeExists("targetUser"));
    }

    @Test
    @WithMockUser(username = "admin@techcorp.com", roles = {"ADMIN"})
    void testViewAllAttendance_Success() throws Exception {
        mockMvc.perform(get("/admin/attendance"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/attendance-view"));
    }

    @Test
    @WithMockUser(username = "admin@techcorp.com", roles = {"ADMIN"})
    void testViewAllLeaves_Success() throws Exception {
        mockMvc.perform(get("/admin/leaves"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/leave-approvals"));
    }

    @Test
    @WithMockUser(username = "admin@techcorp.com", roles = {"ADMIN"})
    void testManageHolidays_Success() throws Exception {
        mockMvc.perform(get("/admin/holidays"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/holidays"));
    }

    @Test
    @WithMockUser(username = "admin@techcorp.com", roles = {"ADMIN"})
    void testManageShifts_Success() throws Exception {
        mockMvc.perform(get("/admin/shifts"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/shifts"));
    }

    @Test
    @WithMockUser(username = "admin@techcorp.com", roles = {"ADMIN"})
    void testViewReports_Success() throws Exception {
        mockMvc.perform(get("/admin/reports"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/reports"));
    }
}