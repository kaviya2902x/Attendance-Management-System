package com.attendance.controller;

import com.attendance.dto.ApiResponse;
import com.attendance.entity.Attendance;
import com.attendance.entity.User;
import com.attendance.service.AttendanceService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.LocalTime;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AttendanceController.class)
class AttendanceControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AttendanceService attendanceService;

    @Autowired
    private ObjectMapper objectMapper;

    private User testUser;
    private Attendance testAttendance;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setEmail("john.doe@techcorp.com");
        testUser.setFirstName("John");
        testUser.setLastName("Doe");

        testAttendance = new Attendance();
        testAttendance.setId(1L);
        testAttendance.setUser(testUser);
        testAttendance.setAttendanceDate(LocalDate.now());
        testAttendance.setClockInTime(LocalTime.of(9, 0));
        testAttendance.setStatus("PRESENT");
    }

    @Test
    @WithMockUser(username = "john.doe@techcorp.com")
    void testClockIn_Success() throws Exception {
        when(attendanceService.clockIn(anyLong(), anyString())).thenReturn(testAttendance);

        mockMvc.perform(post("/attendance/clock-in")
                        .with(csrf())
                        .param("location", "Office"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Clocked in successfully"));
    }

    @Test
    @WithMockUser(username = "john.doe@techcorp.com")
    void testClockOut_Success() throws Exception {
        testAttendance.setClockOutTime(LocalTime.of(18, 0));
        when(attendanceService.clockOut(anyLong(), anyString())).thenReturn(testAttendance);

        mockMvc.perform(post("/attendance/clock-out")
                        .with(csrf())
                        .param("location", "Office"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Clocked out successfully"));
    }

    @Test
    @WithMockUser(username = "john.doe@techcorp.com")
    void testGetTodayAttendance_Success() throws Exception {
        when(attendanceService.getTodayAttendance(anyLong())).thenReturn(testAttendance);

        mockMvc.perform(get("/attendance/api/today"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    @WithMockUser(username = "john.doe@techcorp.com")
    void testGetMonthlyAttendance_Success() throws Exception {
        when(attendanceService.getUserAttendanceByMonth(anyLong(), anyInt(), anyInt()))
                .thenReturn(java.util.Collections.singletonList(testAttendance));

        mockMvc.perform(get("/attendance/api/monthly/2024/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    @WithMockUser(username = "john.doe@techcorp.com")
    void testMarkManualAttendance_Success() throws Exception {
        when(attendanceService.markAttendance(anyLong(), any(), any(), any()))
                .thenReturn(testAttendance);

        mockMvc.perform(post("/attendance/api/manual")
                        .with(csrf())
                        .param("date", "2024-01-15")
                        .param("clockIn", "09:00")
                        .param("clockOut", "18:00"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    @WithMockUser(username = "john.doe@techcorp.com")
    void testGetAttendanceHistory_Success() throws Exception {
        mockMvc.perform(get("/attendance/history")
                        .param("year", "2024")
                        .param("month", "1"))
                .andExpect(status().isOk())
                .andExpect(view().name("employee/attendance-history"));
    }
}