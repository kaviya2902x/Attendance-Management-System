package com.attendance.controller;

import com.attendance.entity.LeaveApplication;
import com.attendance.entity.User;
import com.attendance.service.LeaveService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(LeaveController.class)
class LeaveControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LeaveService leaveService;

    private User testUser;
    private LeaveApplication testLeave;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setEmail("john.doe@techcorp.com");
        testUser.setFirstName("John");
        testUser.setLastName("Doe");

        testLeave = new LeaveApplication();
        testLeave.setId(1L);
        testLeave.setUser(testUser);
        testLeave.setLeaveType("CASUAL");
        testLeave.setStartDate(LocalDate.now().plusDays(1));
        testLeave.setEndDate(LocalDate.now().plusDays(3));
        testLeave.setStatus("PENDING");
        testLeave.setReason("Family function");
    }

    @Test
    @WithMockUser(username = "john.doe@techcorp.com")
    void testShowLeaveApplicationForm_Success() throws Exception {
        mockMvc.perform(get("/leave/apply"))
                .andExpect(status().isOk())
                .andExpect(view().name("employee/leave-apply"))
                .andExpect(model().attributeExists("leaveApplication"));
    }

    @Test
    @WithMockUser(username = "john.doe@techcorp.com")
    void testGetLeaveHistory_Success() throws Exception {
        List<LeaveApplication> leaves = Arrays.asList(testLeave);
        when(leaveService.getUserLeaves(anyLong())).thenReturn(leaves);

        mockMvc.perform(get("/leave/history"))
                .andExpect(status().isOk())
                .andExpect(view().name("employee/leave-history"))
                .andExpect(model().attributeExists("leaves"));
    }

    @Test
    @WithMockUser(username = "manager@techcorp.com")
    void testGetPendingLeaves_Success() throws Exception {
        List<LeaveApplication> pendingLeaves = Arrays.asList(testLeave);
        when(leaveService.getPendingLeavesByManager(anyString())).thenReturn(pendingLeaves);

        mockMvc.perform(get("/leave/pending"))
                .andExpect(status().isOk())
                .andExpect(view().name("manager/leave-approvals"))
                .andExpect(model().attributeExists("pendingLeaves"));
    }

    @Test
    @WithMockUser(username = "manager@techcorp.com")
    void testApproveLeave_Success() throws Exception {
        testLeave.setStatus("APPROVED");
        when(leaveService.approveLeave(anyLong(), anyString())).thenReturn(testLeave);

        mockMvc.perform(post("/leave/1/approve")
                        .with(csrf()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Leave approved successfully"));
    }

    @Test
    @WithMockUser(username = "manager@techcorp.com")
    void testRejectLeave_Success() throws Exception {
        testLeave.setStatus("REJECTED");
        when(leaveService.rejectLeave(anyLong(), anyString(), anyString())).thenReturn(testLeave);

        mockMvc.perform(post("/leave/1/reject")
                        .with(csrf())
                        .param("reason", "Insufficient documentation"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Leave rejected successfully"));
    }

    @Test
    @WithMockUser(username = "john.doe@techcorp.com")
    void testCancelLeave_Success() throws Exception {
        mockMvc.perform(post("/leave/1/cancel")
                        .with(csrf()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("Leave cancelled successfully"));
    }
}