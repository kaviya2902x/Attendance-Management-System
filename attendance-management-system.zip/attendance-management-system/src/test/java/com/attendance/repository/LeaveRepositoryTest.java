package com.attendance.repository;

import com.attendance.entity.LeaveApplication;
import com.attendance.entity.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
class LeaveRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private LeaveRepository leaveRepository;

    private User testUser;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setEmployeeId("EMP001");
        testUser.setFirstName("John");
        testUser.setLastName("Doe");
        testUser.setEmail("john.doe@techcorp.com");
        testUser.setPassword("password123");
        testUser.setDepartment("IT");
        testUser.setPosition("Developer");
        testUser.setJoiningDate(LocalDate.now());
        testUser.setRole("ROLE_EMPLOYEE");
        testUser.setStatus("ACTIVE");
        testUser.setReportingManager("manager@techcorp.com");

        entityManager.persist(testUser);
        entityManager.flush();
    }

    @Test
    void testFindByUserId() {
        // Given
        LeaveApplication leave1 = new LeaveApplication();
        leave1.setUser(testUser);
        leave1.setLeaveType("CASUAL");
        leave1.setStartDate(LocalDate.now().plusDays(1));
        leave1.setEndDate(LocalDate.now().plusDays(3));
        leave1.setTotalDays(3);
        leave1.setReason("Family function");
        leave1.setStatus("PENDING");
        leave1.setAppliedDate(LocalDate.now());

        LeaveApplication leave2 = new LeaveApplication();
        leave2.setUser(testUser);
        leave2.setLeaveType("SICK");
        leave2.setStartDate(LocalDate.now().plusDays(5));
        leave2.setEndDate(LocalDate.now().plusDays(5));
        leave2.setTotalDays(1);
        leave2.setReason("Fever");
        leave2.setStatus("APPROVED");
        leave2.setAppliedDate(LocalDate.now());

        entityManager.persist(leave1);
        entityManager.persist(leave2);
        entityManager.flush();

        // When
        List<LeaveApplication> found = leaveRepository.findByUserId(testUser.getId());

        // Then
        assertThat(found).hasSize(2);
        assertThat(found).extracting(LeaveApplication::getLeaveType)
                .containsExactlyInAnyOrder("CASUAL", "SICK");
    }

    @Test
    void testFindByUserIdAndStatus() {
        // Given
        LeaveApplication pendingLeave = new LeaveApplication();
        pendingLeave.setUser(testUser);
        pendingLeave.setLeaveType("CASUAL");
        pendingLeave.setStartDate(LocalDate.now().plusDays(1));
        pendingLeave.setEndDate(LocalDate.now().plusDays(3));
        pendingLeave.setTotalDays(3);
        pendingLeave.setReason("Family function");
        pendingLeave.setStatus("PENDING");
        pendingLeave.setAppliedDate(LocalDate.now());

        LeaveApplication approvedLeave = new LeaveApplication();
        approvedLeave.setUser(testUser);
        approvedLeave.setLeaveType("SICK");
        approvedLeave.setStartDate(LocalDate.now().plusDays(5));
        approvedLeave.setEndDate(LocalDate.now().plusDays(5));
        approvedLeave.setTotalDays(1);
        approvedLeave.setReason("Fever");
        approvedLeave.setStatus("APPROVED");
        approvedLeave.setAppliedDate(LocalDate.now());

        entityManager.persist(pendingLeave);
        entityManager.persist(approvedLeave);
        entityManager.flush();

        // When
        List<LeaveApplication> pendingLeaves = leaveRepository
                .findByUserIdAndStatus(testUser.getId(), "PENDING");
        List<LeaveApplication> approvedLeaves = leaveRepository
                .findByUserIdAndStatus(testUser.getId(), "APPROVED");

        // Then
        assertThat(pendingLeaves).hasSize(1);
        assertThat(pendingLeaves.get(0).getStatus()).isEqualTo("PENDING");

        assertThat(approvedLeaves).hasSize(1);
        assertThat(approvedLeaves.get(0).getStatus()).isEqualTo("APPROVED");
    }

    @Test
    void testFindByStatus() {
        // Given
        LeaveApplication pendingLeave = new LeaveApplication();
        pendingLeave.setUser(testUser);
        pendingLeave.setLeaveType("CASUAL");
        pendingLeave.setStartDate(LocalDate.now().plusDays(1));
        pendingLeave.setEndDate(LocalDate.now().plusDays(3));
        pendingLeave.setTotalDays(3);
        pendingLeave.setReason("Family function");
        pendingLeave.setStatus("PENDING");
        pendingLeave.setAppliedDate(LocalDate.now());

        LeaveApplication approvedLeave = new LeaveApplication();
        approvedLeave.setUser(testUser);
        approvedLeave.setLeaveType("SICK");
        approvedLeave.setStartDate(LocalDate.now().plusDays(5));
        approvedLeave.setEndDate(LocalDate.now().plusDays(5));
        approvedLeave.setTotalDays(1);
        approvedLeave.setReason("Fever");
        approvedLeave.setStatus("APPROVED");
        approvedLeave.setAppliedDate(LocalDate.now());

        entityManager.persist(pendingLeave);
        entityManager.persist(approvedLeave);
        entityManager.flush();

        // When
        List<LeaveApplication> pendingLeaves = leaveRepository.findByStatus("PENDING");
        List<LeaveApplication> approvedLeaves = leaveRepository.findByStatus("APPROVED");

        // Then
        assertThat(pendingLeaves).hasSize(1);
        assertThat(pendingLeaves.get(0).getStatus()).isEqualTo("PENDING");

        assertThat(approvedLeaves).hasSize(1);
        assertThat(approvedLeaves.get(0).getStatus()).isEqualTo("APPROVED");
    }

    @Test
    void testFindOverlappingLeaves() {
        // Given
        LocalDate existingStart = LocalDate.now().plusDays(1);
        LocalDate existingEnd = LocalDate.now().plusDays(3);

        LeaveApplication existingLeave = new LeaveApplication();
        existingLeave.setUser(testUser);
        existingLeave.setLeaveType("CASUAL");
        existingLeave.setStartDate(existingStart);
        existingLeave.setEndDate(existingEnd);
        existingLeave.setTotalDays(3);
        existingLeave.setReason("Existing leave");
        existingLeave.setStatus("APPROVED");
        existingLeave.setAppliedDate(LocalDate.now());

        entityManager.persist(existingLeave);
        entityManager.flush();

        // When - Test overlapping dates
        List<LeaveApplication> overlapping = leaveRepository.findOverlappingLeaves(
                testUser.getId(),
                existingStart.minusDays(1), // Overlaps from day before
                existingEnd.minusDays(1)    // Ends one day before existing ends
        );

        // Then
        assertThat(overlapping).hasSize(1);
        assertThat(overlapping.get(0).getId()).isEqualTo(existingLeave.getId());
    }

    @Test
    void testGetTotalApprovedLeaveDays() {
        // Given
        int currentYear = LocalDate.now().getYear();

        LeaveApplication leave1 = new LeaveApplication();
        leave1.setUser(testUser);
        leave1.setLeaveType("CASUAL");
        leave1.setStartDate(LocalDate.of(currentYear, 1, 10));
        leave1.setEndDate(LocalDate.of(currentYear, 1, 12));
        leave1.setTotalDays(3);
        leave1.setReason("Leave 1");
        leave1.setStatus("APPROVED");
        leave1.setAppliedDate(LocalDate.now());

        LeaveApplication leave2 = new LeaveApplication();
        leave2.setUser(testUser);
        leave2.setLeaveType("SICK");
        leave2.setStartDate(LocalDate.of(currentYear, 2, 1));
        leave2.setEndDate(LocalDate.of(currentYear, 2, 1));
        leave2.setTotalDays(1);
        leave2.setReason("Leave 2");
        leave2.setStatus("APPROVED");
        leave2.setAppliedDate(LocalDate.now());

        // Pending leave should not be counted
        LeaveApplication leave3 = new LeaveApplication();
        leave3.setUser(testUser);
        leave3.setLeaveType("CASUAL");
        leave3.setStartDate(LocalDate.of(currentYear, 3, 1));
        leave3.setEndDate(LocalDate.of(currentYear, 3, 5));
        leave3.setTotalDays(5);
        leave3.setReason("Leave 3");
        leave3.setStatus("PENDING");
        leave3.setAppliedDate(LocalDate.now());

        entityManager.persist(leave1);
        entityManager.persist(leave2);
        entityManager.persist(leave3);
        entityManager.flush();

        // When
        Integer totalDays = leaveRepository.getTotalApprovedLeaveDays(testUser.getId(), currentYear);

        // Then
        assertThat(totalDays).isEqualTo(4); // 3 + 1 days from approved leaves
    }
}