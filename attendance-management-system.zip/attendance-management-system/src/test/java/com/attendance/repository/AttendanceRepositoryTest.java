package com.attendance.repository;

import com.attendance.entity.Attendance;
import com.attendance.entity.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
class AttendanceRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private AttendanceRepository attendanceRepository;

    private User testUser;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setEmployeeId("EMP001");
        testUser.setFirstName("John");
        testUser.setLastName("Doe");
        testUser.setEmail("john.doe@techcorp.com");
        testUser.setPassword("password123");
        testUser.setDepartment("IT");
        testUser.setPosition("Developer");
        testUser.setJoiningDate(LocalDate.now());
        testUser.setRole("ROLE_EMPLOYEE");
        testUser.setStatus("ACTIVE");

        entityManager.persist(testUser);
        entityManager.flush();
    }

    @Test
    void testFindByUserIdAndAttendanceDate() {
        // Given
        LocalDate today = LocalDate.now();
        Attendance attendance = new Attendance();
        attendance.setUser(testUser);
        attendance.setAttendanceDate(today);
        attendance.setClockInTime(LocalTime.of(9, 0));
        attendance.setStatus("PRESENT");

        entityManager.persist(attendance);
        entityManager.flush();

        // When
        Optional<Attendance> found = attendanceRepository
                .findByUserIdAndAttendanceDate(testUser.getId(), today);

        // Then
        assertThat(found).isPresent();
        assertThat(found.get().getUser().getId()).isEqualTo(testUser.getId());
        assertThat(found.get().getAttendanceDate()).isEqualTo(today);
        assertThat(found.get().getStatus()).isEqualTo("PRESENT");
    }

    @Test
    void testFindByUserId() {
        // Given
        LocalDate date1 = LocalDate.now().minusDays(1);
        LocalDate date2 = LocalDate.now();

        Attendance attendance1 = new Attendance();
        attendance1.setUser(testUser);
        attendance1.setAttendanceDate(date1);
        attendance1.setStatus("PRESENT");

        Attendance attendance2 = new Attendance();
        attendance2.setUser(testUser);
        attendance2.setAttendanceDate(date2);
        attendance2.setStatus("ABSENT");

        entityManager.persist(attendance1);
        entityManager.persist(attendance2);
        entityManager.flush();

        // When
        List<Attendance> found = attendanceRepository.findByUserId(testUser.getId());

        // Then
        assertThat(found).hasSize(2);
        assertThat(found).extracting(Attendance::getStatus)
                .containsExactlyInAnyOrder("PRESENT", "ABSENT");
    }

    @Test
    void testFindByUserIdAndAttendanceDateBetween() {
        // Given
        LocalDate startDate = LocalDate.now().minusDays(5);
        LocalDate endDate = LocalDate.now();

        for (int i = 0; i < 7; i++) {
            Attendance attendance = new Attendance();
            attendance.setUser(testUser);
            attendance.setAttendanceDate(LocalDate.now().minusDays(i));
            attendance.setStatus(i % 2 == 0 ? "PRESENT" : "ABSENT");
            entityManager.persist(attendance);
        }
        entityManager.flush();

        // When
        List<Attendance> found = attendanceRepository
                .findByUserIdAndAttendanceDateBetween(testUser.getId(), startDate, endDate);

        // Then
        assertThat(found).hasSize(6); // 5 days + today
        assertThat(found).allMatch(a ->
                !a.getAttendanceDate().isBefore(startDate) &&
                        !a.getAttendanceDate().isAfter(endDate)
        );
    }

    @Test
    void testFindByAttendanceDate() {
        // Given
        LocalDate today = LocalDate.now();

        // Create another user
        User user2 = new User();
        user2.setEmployeeId("EMP002");
        user2.setFirstName("Jane");
        user2.setLastName("Smith");
        user2.setEmail("jane.smith@techcorp.com");
        user2.setPassword("password123");
        user2.setDepartment("HR");
        user2.setPosition("Manager");
        user2.setJoiningDate(LocalDate.now());
        user2.setRole("ROLE_EMPLOYEE");
        user2.setStatus("ACTIVE");
        entityManager.persist(user2);

        Attendance attendance1 = new Attendance();
        attendance1.setUser(testUser);
        attendance1.setAttendanceDate(today);
        attendance1.setStatus("PRESENT");

        Attendance attendance2 = new Attendance();
        attendance2.setUser(user2);
        attendance2.setAttendanceDate(today);
        attendance2.setStatus("ABSENT");

        entityManager.persist(attendance1);
        entityManager.persist(attendance2);
        entityManager.flush();

        // When
        List<Attendance> found = attendanceRepository.findByAttendanceDate(today);

        // Then
        assertThat(found).hasSize(2);
        assertThat(found).extracting(a -> a.getUser().getId())
                .containsExactlyInAnyOrder(testUser.getId(), user2.getId());
    }

    @Test
    void testFindByUserIdAndMonth() {
        // Given
        LocalDate date1 = LocalDate.of(2024, 1, 15);
        LocalDate date2 = LocalDate.of(2024, 2, 15);

        Attendance attendance1 = new Attendance();
        attendance1.setUser(testUser);
        attendance1.setAttendanceDate(date1);
        attendance1.setStatus("PRESENT");

        Attendance attendance2 = new Attendance();
        attendance2.setUser(testUser);
        attendance2.setAttendanceDate(date2);
        attendance2.setStatus("ABSENT");

        entityManager.persist(attendance1);
        entityManager.persist(attendance2);
        entityManager.flush();

        // When
        List<Attendance> januaryAttendances = attendanceRepository
                .findByUserIdAndMonth(testUser.getId(), 2024, 1);
        List<Attendance> februaryAttendances = attendanceRepository
                .findByUserIdAndMonth(testUser.getId(), 2024, 2);

        // Then
        assertThat(januaryAttendances).hasSize(1);
        assertThat(januaryAttendances.get(0).getAttendanceDate().getMonthValue()).isEqualTo(1);

        assertThat(februaryAttendances).hasSize(1);
        assertThat(februaryAttendances.get(0).getAttendanceDate().getMonthValue()).isEqualTo(2);
    }

    @Test
    void testCountPresentDays() {
        // Given
        LocalDate startDate = LocalDate.now().minusDays(10);
        LocalDate endDate = LocalDate.now();

        for (int i = 0; i <= 10; i++) {
            Attendance attendance = new Attendance();
            attendance.setUser(testUser);
            attendance.setAttendanceDate(LocalDate.now().minusDays(i));
            attendance.setStatus(i % 2 == 0 ? "PRESENT" : "ABSENT");
            entityManager.persist(attendance);
        }
        entityManager.flush();

        // When
        Long presentDays = attendanceRepository.countPresentDays(
                testUser.getId(), startDate, endDate
        );

        // Then
        // Out of 11 days (0 to 10), half should be present (rounded up)
        assertThat(presentDays).isEqualTo(6L); // Even numbers from 0 to 10: 0,2,4,6,8,10 = 6 days
    }
}