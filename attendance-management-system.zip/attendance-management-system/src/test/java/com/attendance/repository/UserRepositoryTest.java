package com.attendance.repository;

import com.attendance.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepositoryTest extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);

    Optional<User> findByEmployeeId(String employeeId);

    List<User> findByDepartment(String department);

    List<User> findByStatus(String status);

    List<User> findByRole(String role);

    @Query("SELECT u FROM User u WHERE " +
            "LOWER(u.firstName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(u.lastName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(u.email) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(u.employeeId) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<User> findByNameContaining(@Param("keyword") String keyword);

    // Method 1: Generic count by any status
    Long countByStatus(String status);

    // Method 2: Specific count for active users
    @Query("SELECT COUNT(u) FROM User u WHERE u.status = 'ACTIVE'")
    Long countActiveUsers();

    @Query("SELECT u FROM User u WHERE u.reportingManager = :managerEmail")
    List<User> findByReportingManager(@Param("managerEmail") String managerEmail);

    // Find active users in a specific department
    List<User> findByDepartmentAndStatus(String department, String status);
}