package com.attendance.service;

import com.attendance.entity.RegularizationRequest;
import com.attendance.entity.User;
import com.attendance.repository.RegularizationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RegularizationServiceTest {

    @Mock
    private RegularizationRepository regularizationRepository;

    @Mock
    private UserService userService;

    @Mock
    private AttendanceService attendanceService;

    @InjectMocks
    private RegularizationService regularizationService;

    private User testUser;
    private RegularizationRequest testRequest;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setEmail("john.doe@techcorp.com");
        testUser.setFirstName("John");
        testUser.setLastName("Doe");

        testRequest = new RegularizationRequest();
        testRequest.setAttendanceDate(LocalDate.now().minusDays(1));
        testRequest.setRequestedClockIn("09:00");
        testRequest.setRequestedClockOut("18:00");
        testRequest.setReason("Forgot to clock in");
        testRequest.setUser(testUser);
    }

    @Test
    void testCreateRequest_Success() {
        when(userService.getUserById(1L)).thenReturn(testUser);
        when(regularizationRepository.findByUserIdAndStatus(anyLong(), anyString()))
                .thenReturn(Collections.emptyList());
        when(regularizationRepository.save(any(RegularizationRequest.class))).thenReturn(testRequest);

        RegularizationRequest result = regularizationService.createRequest(1L, testRequest);

        assertNotNull(result);
        assertEquals("PENDING", result.getStatus());
        assertEquals(LocalDate.now(), result.getRequestedDate());
        verify(regularizationRepository, times(1)).save(any(RegularizationRequest.class));
    }

    @Test
    void testCreateRequest_DuplicateRequest() {
        List<RegularizationRequest> existingRequests = Collections.singletonList(testRequest);
        when(userService.getUserById(1L)).thenReturn(testUser);
        when(regularizationRepository.findByUserIdAndStatus(anyLong(), anyString()))
                .thenReturn(existingRequests);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            regularizationService.createRequest(1L, testRequest);
        });

        assertTrue(exception.getMessage().contains("already exists"));
    }

    @Test
    void testApproveRequest_Success() {
        testRequest.setId(1L);
        when(regularizationRepository.findById(1L)).thenReturn(java.util.Optional.of(testRequest));
        when(regularizationRepository.save(any(RegularizationRequest.class))).thenReturn(testRequest);

        RegularizationRequest result = regularizationService.approveRequest(1L, "approver@techcorp.com");

        assertNotNull(result);
        assertEquals("APPROVED", result.getStatus());
        assertEquals("approver@techcorp.com", result.getApprovedBy());
        assertNotNull(result.getApprovalDate());
        verify(regularizationRepository, times(1)).save(any(RegularizationRequest.class));
    }

    @Test
    void testRejectRequest_Success() {
        testRequest.setId(1L);
        when(regularizationRepository.findById(1L)).thenReturn(java.util.Optional.of(testRequest));
        when(regularizationRepository.save(any(RegularizationRequest.class))).thenReturn(testRequest);

        RegularizationRequest result = regularizationService.rejectRequest(
                1L, "rejector@techcorp.com", "Invalid reason"
        );

        assertNotNull(result);
        assertEquals("REJECTED", result.getStatus());
        assertEquals("Invalid reason", result.getRejectionReason());
        verify(regularizationRepository, times(1)).save(any(RegularizationRequest.class));
    }

    @Test
    void testGetUserRequests() {
        List<RegularizationRequest> requests = Collections.singletonList(testRequest);
        when(regularizationRepository.findByUserId(1L)).thenReturn(requests);

        List<RegularizationRequest> result = regularizationService.getUserRequests(1L);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(testRequest, result.get(0));
    }

    @Test
    void testGetPendingRequests() {
        List<RegularizationRequest> pendingRequests = Collections.singletonList(testRequest);
        when(regularizationRepository.findByStatus("PENDING")).thenReturn(pendingRequests);

        List<RegularizationRequest> result = regularizationService.getPendingRequests();

        assertNotNull(result);
        assertEquals(1, result.size());
    }
}