package com.attendance.service;

import com.attendance.entity.Notification;
import com.attendance.entity.User;
import com.attendance.repository.NotificationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationServiceTest {

    @Mock
    private NotificationRepository notificationRepository;

    @InjectMocks
    private NotificationService notificationService;

    private User testUser;
    private Notification testNotification;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setEmail("john.doe@techcorp.com");
        testUser.setFirstName("John");
        testUser.setLastName("Doe");

        testNotification = new Notification();
        testNotification.setId(1L);
        testNotification.setUser(testUser);
        testNotification.setTitle("Test Notification");
        testNotification.setMessage("This is a test notification");
        testNotification.setType("INFO");
        testNotification.setIsRead(false);
    }

    @Test
    void testCreateNotification_Success() {
        when(notificationRepository.save(any(Notification.class))).thenReturn(testNotification);

        Notification result = notificationService.createNotification(
                testUser, "Test", "Message", "INFO"
        );

        assertNotNull(result);
        assertEquals("Test", result.getTitle());
        assertEquals("Message", result.getMessage());
        assertEquals("INFO", result.getType());
        assertFalse(result.getIsRead());
        verify(notificationRepository, times(1)).save(any(Notification.class));
    }

    @Test
    void testMarkAsRead_Success() {
        when(notificationRepository.findById(1L)).thenReturn(java.util.Optional.of(testNotification));
        when(notificationRepository.save(any(Notification.class))).thenReturn(testNotification);

        notificationService.markAsRead(1L);

        assertTrue(testNotification.getIsRead());
        verify(notificationRepository, times(1)).save(any(Notification.class));
    }

    @Test
    void testMarkAllAsRead_Success() {
        List<Notification> unreadNotifications = Collections.singletonList(testNotification);
        when(notificationRepository.findByUserIdAndIsRead(1L, false)).thenReturn(unreadNotifications);
        when(notificationRepository.save(any(Notification.class))).thenReturn(testNotification);

        notificationService.markAllAsRead(1L);

        assertTrue(testNotification.getIsRead());
        verify(notificationRepository, times(1)).save(any(Notification.class));
    }

    @Test
    void testGetUserNotifications() {
        List<Notification> notifications = Collections.singletonList(testNotification);
        when(notificationRepository.findByUserId(1L)).thenReturn(notifications);

        List<Notification> result = notificationService.getUserNotifications(1L);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(testNotification, result.get(0));
    }

    @Test
    void testGetUnreadNotifications() {
        List<Notification> unreadNotifications = Collections.singletonList(testNotification);
        when(notificationRepository.findByUserIdAndIsRead(1L, false)).thenReturn(unreadNotifications);

        List<Notification> result = notificationService.getUnreadNotifications(1L);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertFalse(result.get(0).getIsRead());
    }

    @Test
    void testGetUnreadNotificationCount() {
        when(notificationRepository.countByUserIdAndIsRead(1L, false)).thenReturn(5L);

        Long count = notificationService.getUnreadNotificationCount(1L);

        assertEquals(5L, count);
    }

    @Test
    void testDeleteNotification_Success() {
        doNothing().when(notificationRepository).deleteById(1L);

        notificationService.deleteNotification(1L);

        verify(notificationRepository, times(1)).deleteById(1L);
    }
}