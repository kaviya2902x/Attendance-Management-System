package com.attendance.service;

import com.attendance.entity.LeaveApplication;
import com.attendance.entity.User;
import com.attendance.repository.LeaveRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LeaveServiceTest {

    @Mock
    private LeaveRepository leaveRepository;

    @Mock
    private UserService userService;

    @Mock
    private NotificationService notificationService;

    @InjectMocks
    private LeaveService leaveService;

    private User testUser;
    private LeaveApplication testLeave;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setEmail("john.doe@techcorp.com");
        testUser.setFirstName("John");
        testUser.setLastName("Doe");
        testUser.setReportingManager("manager@techcorp.com");

        testLeave = new LeaveApplication();
        testLeave.setLeaveType("CASUAL");
        testLeave.setStartDate(LocalDate.now().plusDays(1));
        testLeave.setEndDate(LocalDate.now().plusDays(3));
        testLeave.setReason("Family function");
        testLeave.setUser(testUser);
    }

    @Test
    void testApplyLeave_Success() {
        when(userService.getUserById(1L)).thenReturn(testUser);
        when(leaveRepository.findOverlappingLeaves(anyLong(), any(), any()))
                .thenReturn(Collections.emptyList());
        when(leaveRepository.getTotalApprovedLeaveDays(anyLong(), anyInt()))
                .thenReturn(10);
        when(leaveRepository.save(any(LeaveApplication.class))).thenReturn(testLeave);

        LeaveApplication result = leaveService.applyLeave(1L, testLeave);

        assertNotNull(result);
        assertEquals("PENDING", result.getStatus());
        assertEquals(3, result.getTotalDays());
        verify(leaveRepository, times(1)).save(any(LeaveApplication.class));
        verify(notificationService, times(1)).createLeaveNotification(any(), any());
    }

    @Test
    void testApplyLeave_OverlappingLeaves() {
        List<LeaveApplication> overlappingLeaves = Collections.singletonList(testLeave);
        when(userService.getUserById(1L)).thenReturn(testUser);
        when(leaveRepository.findOverlappingLeaves(anyLong(), any(), any()))
                .thenReturn(overlappingLeaves);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            leaveService.applyLeave(1L, testLeave);
        });

        assertTrue(exception.getMessage().contains("overlaps with existing leave"));
    }

    @Test
    void testApplyLeave_InsufficientBalance() {
        when(userService.getUserById(1L)).thenReturn(testUser);
        when(leaveRepository.findOverlappingLeaves(anyLong(), any(), any()))
                .thenReturn(Collections.emptyList());
        when(leaveRepository.getTotalApprovedLeaveDays(anyLong(), anyInt()))
                .thenReturn(30); // Already used all leaves

        testLeave.setStartDate(LocalDate.now().plusDays(1));
        testLeave.setEndDate(LocalDate.now().plusDays(5)); // 5 days leave

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            leaveService.applyLeave(1L, testLeave);
        });

        assertTrue(exception.getMessage().contains("Insufficient leave balance"));
    }

    @Test
    void testApproveLeave_Success() {
        testLeave.setId(1L);
        when(leaveRepository.findById(1L)).thenReturn(java.util.Optional.of(testLeave));
        when(leaveRepository.save(any(LeaveApplication.class))).thenReturn(testLeave);

        LeaveApplication result = leaveService.approveLeave(1L, "approver@techcorp.com");

        assertNotNull(result);
        assertEquals("APPROVED", result.getStatus());
        assertEquals("approver@techcorp.com", result.getApprovedBy());
        assertNotNull(result.getApprovalDate());
        verify(leaveRepository, times(1)).save(any(LeaveApplication.class));
        verify(notificationService, times(1)).createLeaveApprovalNotification(any());
    }

    @Test
    void testRejectLeave_Success() {
        testLeave.setId(1L);
        when(leaveRepository.findById(1L)).thenReturn(java.util.Optional.of(testLeave));
        when(leaveRepository.save(any(LeaveApplication.class))).thenReturn(testLeave);

        LeaveApplication result = leaveService.rejectLeave(1L, "rejector@techcorp.com", "Insufficient documentation");

        assertNotNull(result);
        assertEquals("REJECTED", result.getStatus());
        assertEquals("Insufficient documentation", result.getRejectionReason());
        verify(leaveRepository, times(1)).save(any(LeaveApplication.class));
        verify(notificationService, times(1)).createLeaveRejectionNotification(any());
    }

    @Test
    void testGetUserLeaves() {
        List<LeaveApplication> leaves = Collections.singletonList(testLeave);
        when(leaveRepository.findByUserId(1L)).thenReturn(leaves);

        List<LeaveApplication> result = leaveService.getUserLeaves(1L);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(testLeave, result.get(0));
    }

    @Test
    void testGetPendingLeaves() {
        List<LeaveApplication> pendingLeaves = Collections.singletonList(testLeave);
        when(leaveRepository.findByStatus("PENDING")).thenReturn(pendingLeaves);

        List<LeaveApplication> result = leaveService.getPendingLeaves();

        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    void testCancelLeave_Success() {
        testLeave.setId(1L);
        testLeave.setStatus("PENDING");
        when(leaveRepository.findById(1L)).thenReturn(java.util.Optional.of(testLeave));
        when(leaveRepository.save(any(LeaveApplication.class))).thenReturn(testLeave);

        leaveService.cancelLeave(1L);

        assertEquals("CANCELLED", testLeave.getStatus());
        verify(leaveRepository, times(1)).save(any(LeaveApplication.class));
    }

    @Test
    void testCancelLeave_NotPending() {
        testLeave.setId(1L);
        testLeave.setStatus("APPROVED");
        when(leaveRepository.findById(1L)).thenReturn(java.util.Optional.of(testLeave));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            leaveService.cancelLeave(1L);
        });

        assertTrue(exception.getMessage().contains("Only pending leaves can be cancelled"));
    }
}