package com.attendance.service;

import com.attendance.entity.User;
import com.attendance.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserService userService;

    private User testUser;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setId(1L);
        testUser.setEmail("test@techcorp.com");
        testUser.setPassword("password123");
        testUser.setFirstName("John");
        testUser.setLastName("Doe");
        testUser.setEmployeeId("EMP001");
        testUser.setDepartment("IT");
        testUser.setPosition("Developer");
        testUser.setRole("ROLE_EMPLOYEE");
        testUser.setStatus("ACTIVE");
    }

    @Test
    void testLoadUserByUsername_Success() {
        when(userRepository.findByEmail("test@techcorp.com")).thenReturn(Optional.of(testUser));

        UserDetails userDetails = userService.loadUserByUsername("test@techcorp.com");

        assertNotNull(userDetails);
        assertEquals("test@techcorp.com", userDetails.getUsername());
        assertTrue(userDetails.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ROLE_EMPLOYEE")));
    }

    @Test
    void testLoadUserByUsername_NotFound() {
        when(userRepository.findByEmail("nonexistent@techcorp.com")).thenReturn(Optional.empty());

        assertThrows(UsernameNotFoundException.class, () -> {
            userService.loadUserByUsername("nonexistent@techcorp.com");
        });
    }

    @Test
    void testCreateUser_Success() {
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        User created = userService.createUser(testUser);

        assertNotNull(created);
        assertEquals("John", created.getFirstName());
        verify(passwordEncoder, times(1)).encode("password123");
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    void testUpdateUser_Success() {
        User updatedDetails = new User();
        updatedDetails.setFirstName("Jane");
        updatedDetails.setLastName("Smith");
        updatedDetails.setEmail("jane@techcorp.com");
        updatedDetails.setDepartment("HR");
        updatedDetails.setPosition("Manager");
        updatedDetails.setPassword("newpassword");

        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));
        when(passwordEncoder.encode(anyString())).thenReturn("encodedNewPassword");
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        User updated = userService.updateUser(1L, updatedDetails);

        assertEquals("Jane", testUser.getFirstName());
        assertEquals("Smith", testUser.getLastName());
        assertEquals("jane@techcorp.com", testUser.getEmail());
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    void testUpdateUser_WithoutPasswordChange() {
        User updatedDetails = new User();
        updatedDetails.setFirstName("Jane");
        updatedDetails.setEmail("jane@techcorp.com");
        updatedDetails.setPassword(null); // No password change

        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        userService.updateUser(1L, updatedDetails);

        assertEquals("Jane", testUser.getFirstName());
        assertEquals("jane@techcorp.com", testUser.getEmail());
        // Password should remain unchanged
        assertEquals("password123", testUser.getPassword());
    }

    @Test
    void testGetUserByEmail_Exists() {
        when(userRepository.findByEmail("test@techcorp.com")).thenReturn(Optional.of(testUser));

        User user = userService.getUserByEmail("test@techcorp.com");

        assertNotNull(user);
        assertEquals("test@techcorp.com", user.getEmail());
    }

    @Test
    void testGetUserByEmail_NotExists() {
        when(userRepository.findByEmail("nonexistent@techcorp.com")).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            userService.getUserByEmail("nonexistent@techcorp.com");
        });

        assertTrue(exception.getMessage().contains("User not found with email"));
    }

    @Test
    void testGetUserById_Exists() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));

        User user = userService.getUserById(1L);

        assertNotNull(user);
        assertEquals(1L, user.getId());
    }

    @Test
    void testDeleteUser() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        userService.deleteUser(1L);

        assertEquals("INACTIVE", testUser.getStatus());
        verify(userRepository, times(1)).save(testUser);
    }

    @Test
    void testGetActiveUsersCount() {
        when(userRepository.countActiveUsers()).thenReturn(10L);

        Long count = userService.getActiveUsersCount();

        assertEquals(10L, count);
    }
}